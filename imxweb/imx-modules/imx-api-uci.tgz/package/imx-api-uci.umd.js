(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('imx-qbm-dbts')) :
    typeof define === 'function' && define.amd ? define(['exports', 'imx-qbm-dbts'], factory) :
    (global = global || self, factory(global['imx-api'] = {}, global.imxQbmDbts));
}(this, (function (exports, imxQbmDbts) { 'use strict';

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    var TypedClient = /** @class */ (function () {
        function TypedClient(client, translationProvider) {
            this.OpsupportUciChangedetail = new OpsupportUciChangedetailWrapper(client, translationProvider);
            this.OpsupportUciChanges = new OpsupportUciChangesWrapper(client, translationProvider);
        }
        return TypedClient;
    }());
    var OpsupportUciChangedetail = /** @class */ (function (_super) {
        __extends(OpsupportUciChangedetail, _super);
        function OpsupportUciChangedetail() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.IsProcessed = _this.GetEntityValue('IsProcessed');
            _this.Operation = _this.GetEntityValue('Operation');
            _this.CreationDate = _this.GetEntityValue('CreationDate');
            _this.UID_QBMPendingChange = _this.GetEntityValue('UID_QBMPendingChange');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportUciChangedetail.GetEntitySchema = function () {
            var columns = {
                'IsProcessed': {
                    ColumnName: 'IsProcessed',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'Operation': {
                    ColumnName: 'Operation',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'CreationDate': {
                    ColumnName: 'CreationDate',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_QBMPendingChange': {
                    ColumnName: 'UID_QBMPendingChange',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QBMPendingChangeDetail', Columns: columns };
        };
        return OpsupportUciChangedetail;
    }(imxQbmDbts.ReadExtTypedEntity));
    /** @deprecated Use the OpsupportUciChangedetail type. */
    var OpsupportUciChangedetailInteractive = /** @class */ (function (_super) {
        __extends(OpsupportUciChangedetailInteractive, _super);
        function OpsupportUciChangedetailInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportUciChangedetailInteractive;
    }(OpsupportUciChangedetail));
    var OpsupportUciChanges = /** @class */ (function (_super) {
        __extends(OpsupportUciChanges, _super);
        function OpsupportUciChanges() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.ObjectKeyElement = _this.GetEntityValue('ObjectKeyElement');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.IsProcessed = _this.GetEntityValue('IsProcessed');
            _this.Operation = _this.GetEntityValue('Operation');
            _this.UID_UCIRoot = _this.GetEntityValue('UID_UCIRoot');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportUciChanges.GetEntitySchema = function () {
            var columns = {
                'ObjectKeyElement': {
                    ColumnName: 'ObjectKeyElement',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'IsProcessed': {
                    ColumnName: 'IsProcessed',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'Operation': {
                    ColumnName: 'Operation',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_UCIRoot': {
                    ColumnName: 'UID_UCIRoot',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QBMPendingChange', Columns: columns };
        };
        return OpsupportUciChanges;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportUciChanges type. */
    var OpsupportUciChangesInteractive = /** @class */ (function (_super) {
        __extends(OpsupportUciChangesInteractive, _super);
        function OpsupportUciChangesInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportUciChangesInteractive;
    }(OpsupportUciChanges));
    var OpsupportUciChangedetailWrapper = /** @class */ (function () {
        function OpsupportUciChangedetailWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportUciChangedetailWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/uci/changedetail/{UID_QBMPendingChange}');
        };
        OpsupportUciChangedetailWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/uci/changedetail/{UID_QBMPendingChange}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportUciChangedetail, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportUciChangedetailWrapper.prototype.Get = function (UID_QBMPendingChange, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_uci_changedetail_get(UID_QBMPendingChange, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportUciChangedetailWrapper;
    }());
    var OpsupportUciChangesWrapper = /** @class */ (function () {
        function OpsupportUciChangesWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportUciChangesWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/uci/changes');
        };
        OpsupportUciChangesWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/uci/changes');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportUciChanges, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportUciChangesWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_uci_changes_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportUciChangesWrapper;
    }());
    /** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
    var ApiClientMethodFactory = /** @class */ (function () {
        function ApiClientMethodFactory() {
        }
        ApiClientMethodFactory.prototype.opsupport_uci_changedetail_get = function (UID_QBMPendingChange, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/uci/changedetail/{UID_QBMPendingChange}',
                parameters: [
                    {
                        name: 'UID_QBMPendingChange',
                        value: UID_QBMPendingChange,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_uci_changes_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, state, root) {
            return {
                path: '/opsupport/uci/changes',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'state',
                        value: state,
                        in: 'query'
                    },
                    {
                        name: 'root',
                        value: root,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_uci_changes_post = function (UID_QBMPendingChangeDetail, inputParameterName) {
            return {
                path: '/opsupport/uci/changes/{UID_QBMPendingChangeDetail}',
                parameters: [
                    {
                        name: 'UID_QBMPendingChangeDetail',
                        value: UID_QBMPendingChangeDetail,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_uci_changes_datamodel_get = function (filter) {
            return {
                path: '/opsupport/uci/changes/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return ApiClientMethodFactory;
    }());
    /** @deprecated Use the V2Client class for a stable method interface. */
    var Client = /** @class */ (function () {
        function Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        Client.prototype.opsupport_uci_changedetail_get = function (UID_QBMPendingChange, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_uci_changedetail_get(UID_QBMPendingChange, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_uci_changes_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, state, root, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_uci_changes_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, state, root), requestOptions);
        };
        Client.prototype.opsupport_uci_changes_post = function (UID_QBMPendingChangeDetail, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_uci_changes_post(UID_QBMPendingChangeDetail, inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the uci/changes endpoint. */
        Client.prototype.opsupport_uci_changes_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_uci_changes_datamodel_get(filter), requestOptions);
        };
        return Client;
    }());
    var V2ApiClientMethodFactory = /** @class */ (function () {
        function V2ApiClientMethodFactory() {
        }
        V2ApiClientMethodFactory.prototype.opsupport_uci_changedetail_get = function (UID_QBMPendingChange, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/uci/changedetail/{UID_QBMPendingChange}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_QBMPendingChange',
                        value: UID_QBMPendingChange,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_uci_changes_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/uci/changes',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_uci_changes_post = function (UID_QBMPendingChangeDetail, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/uci/changes/{UID_QBMPendingChangeDetail}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_QBMPendingChangeDetail',
                        value: UID_QBMPendingChangeDetail,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_uci_changes_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/uci/changes/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return V2ApiClientMethodFactory;
    }());
    var V2Client = /** @class */ (function () {
        function V2Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new V2ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(V2Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        V2Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        V2Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        V2Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        V2Client.prototype.opsupport_uci_changedetail_get = function (UID_QBMPendingChange, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_uci_changedetail_get(UID_QBMPendingChange, options), requestOptions);
        };
        V2Client.prototype.opsupport_uci_changes_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_uci_changes_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_uci_changes_post = function (UID_QBMPendingChangeDetail, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_uci_changes_post(UID_QBMPendingChangeDetail, inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the uci/changes endpoint. */
        V2Client.prototype.opsupport_uci_changes_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_uci_changes_datamodel_get(options), requestOptions);
        };
        return V2Client;
    }());

    exports.ApiClientMethodFactory = ApiClientMethodFactory;
    exports.Client = Client;
    exports.OpsupportUciChangedetail = OpsupportUciChangedetail;
    exports.OpsupportUciChangedetailInteractive = OpsupportUciChangedetailInteractive;
    exports.OpsupportUciChangedetailWrapper = OpsupportUciChangedetailWrapper;
    exports.OpsupportUciChanges = OpsupportUciChanges;
    exports.OpsupportUciChangesInteractive = OpsupportUciChangesInteractive;
    exports.OpsupportUciChangesWrapper = OpsupportUciChangesWrapper;
    exports.TypedClient = TypedClient;
    exports.V2ApiClientMethodFactory = V2ApiClientMethodFactory;
    exports.V2Client = V2Client;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
