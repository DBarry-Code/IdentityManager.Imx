import { ValType, DisplayColumns, TypedEntity, WriteExtTypedEntity, TypedEntityBuilder, EntityState, InteractiveTypedEntityBuilder, TimeZoneInfo, DisplayPattern, FkCandidateBuilder, MethodDefinition } from 'imx-qbm-dbts';

var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var TypedClient = /** @class */ (function () {
    function TypedClient(client, translationProvider) {
        this.PortalAaddirectoryroleMemberships = new PortalAaddirectoryroleMembershipsWrapper(client, translationProvider);
        this.PortalAadgroupMemberships = new PortalAadgroupMembershipsWrapper(client, translationProvider);
        this.PortalAadscopedrlasgnMemberships = new PortalAadscopedrlasgnMembershipsWrapper(client, translationProvider);
        this.PortalAadscopedrlelgbMemberships = new PortalAadscopedrlelgbMembershipsWrapper(client, translationProvider);
        this.PortalAadsubskuMemberships = new PortalAadsubskuMembershipsWrapper(client, translationProvider);
        this.PortalShopConfigEntitlementsAaddeniedserviceplan = new PortalShopConfigEntitlementsAaddeniedserviceplanWrapper(client, translationProvider);
        this.PortalTargetsystemAaddirectoryrole = new PortalTargetsystemAaddirectoryroleWrapper(client, translationProvider);
        this.PortalTargetsystemAaddirectoryroleInteractive = new PortalTargetsystemAaddirectoryroleInteractiveWrapper(client, translationProvider);
        this.PortalTargetsystemAadgroup = new PortalTargetsystemAadgroupWrapper(client, translationProvider);
        this.PortalTargetsystemAadgroupChildren = new PortalTargetsystemAadgroupChildrenWrapper(client, translationProvider);
        this.PortalTargetsystemAadgroupDeniedserviceplans = new PortalTargetsystemAadgroupDeniedserviceplansWrapper(client, translationProvider);
        this.PortalTargetsystemAadgroupInteractive = new PortalTargetsystemAadgroupInteractiveWrapper(client, translationProvider);
        this.PortalTargetsystemAadgroupSubsku = new PortalTargetsystemAadgroupSubskuWrapper(client, translationProvider);
        this.PortalTargetsystemAadscopedrlasgn = new PortalTargetsystemAadscopedrlasgnWrapper(client, translationProvider);
        this.PortalTargetsystemAadscopedrlasgnInteractive = new PortalTargetsystemAadscopedrlasgnInteractiveWrapper(client, translationProvider);
        this.PortalTargetsystemAadscopedrlelgb = new PortalTargetsystemAadscopedrlelgbWrapper(client, translationProvider);
        this.PortalTargetsystemAadscopedrlelgbInteractive = new PortalTargetsystemAadscopedrlelgbInteractiveWrapper(client, translationProvider);
        this.PortalTargetsystemAadsubsku = new PortalTargetsystemAadsubskuWrapper(client, translationProvider);
        this.PortalTargetsystemAadsubskuInteractive = new PortalTargetsystemAadsubskuInteractiveWrapper(client, translationProvider);
        this.PortalTargetsystemAaduser = new PortalTargetsystemAaduserWrapper(client, translationProvider);
        this.PortalTargetsystemAaduserDeniedserviceplans = new PortalTargetsystemAaduserDeniedserviceplansWrapper(client, translationProvider);
        this.PortalTargetsystemAaduserInteractive = new PortalTargetsystemAaduserInteractiveWrapper(client, translationProvider);
        this.PortalTargetsystemAaduserSubsku = new PortalTargetsystemAaduserSubskuWrapper(client, translationProvider);
    }
    return TypedClient;
}());
var PortalAaddirectoryroleMemberships = /** @class */ (function (_super) {
    __extends(PortalAaddirectoryroleMemberships, _super);
    function PortalAaddirectoryroleMemberships() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_Person = _this.GetEntityValue('UID_Person');
        _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.IsPending = _this.GetEntityValue('IsPending');
        _this.IsPrimary = _this.GetEntityValue('IsPrimary');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.OrderState = _this.GetEntityValue('OrderState');
        _this.ValidUntil = _this.GetEntityValue('ValidUntil');
        _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
        _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalAaddirectoryroleMemberships.GetEntitySchema = function () {
        var columns = {
            'UID_Person': {
                ColumnName: 'UID_Person',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ObjectKeyAssignment': {
                ColumnName: 'ObjectKeyAssignment',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'IsPending': {
                ColumnName: 'IsPending',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsPrimary': {
                ColumnName: 'IsPrimary',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'OrderState': {
                ColumnName: 'OrderState',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ValidUntil': {
                ColumnName: 'ValidUntil',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'UID_UNSAccount': {
                ColumnName: 'UID_UNSAccount',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_UNSGroupChild': {
                ColumnName: 'UID_UNSGroupChild',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: '', Columns: columns };
    };
    return PortalAaddirectoryroleMemberships;
}(TypedEntity));
/** @deprecated Use the PortalAaddirectoryroleMemberships type. */
var PortalAaddirectoryroleMembershipsInteractive = /** @class */ (function (_super) {
    __extends(PortalAaddirectoryroleMembershipsInteractive, _super);
    function PortalAaddirectoryroleMembershipsInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalAaddirectoryroleMembershipsInteractive;
}(PortalAaddirectoryroleMemberships));
var PortalAadgroupMemberships = /** @class */ (function (_super) {
    __extends(PortalAadgroupMemberships, _super);
    function PortalAadgroupMemberships() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_Person = _this.GetEntityValue('UID_Person');
        _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.IsPending = _this.GetEntityValue('IsPending');
        _this.IsPrimary = _this.GetEntityValue('IsPrimary');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.OrderState = _this.GetEntityValue('OrderState');
        _this.ValidUntil = _this.GetEntityValue('ValidUntil');
        _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
        _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalAadgroupMemberships.GetEntitySchema = function () {
        var columns = {
            'UID_Person': {
                ColumnName: 'UID_Person',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ObjectKeyAssignment': {
                ColumnName: 'ObjectKeyAssignment',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'IsPending': {
                ColumnName: 'IsPending',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsPrimary': {
                ColumnName: 'IsPrimary',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'OrderState': {
                ColumnName: 'OrderState',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ValidUntil': {
                ColumnName: 'ValidUntil',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'UID_UNSAccount': {
                ColumnName: 'UID_UNSAccount',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_UNSGroupChild': {
                ColumnName: 'UID_UNSGroupChild',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: '', Columns: columns };
    };
    return PortalAadgroupMemberships;
}(TypedEntity));
/** @deprecated Use the PortalAadgroupMemberships type. */
var PortalAadgroupMembershipsInteractive = /** @class */ (function (_super) {
    __extends(PortalAadgroupMembershipsInteractive, _super);
    function PortalAadgroupMembershipsInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalAadgroupMembershipsInteractive;
}(PortalAadgroupMemberships));
var PortalAadscopedrlasgnMemberships = /** @class */ (function (_super) {
    __extends(PortalAadscopedrlasgnMemberships, _super);
    function PortalAadscopedrlasgnMemberships() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_Person = _this.GetEntityValue('UID_Person');
        _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.IsPending = _this.GetEntityValue('IsPending');
        _this.IsPrimary = _this.GetEntityValue('IsPrimary');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.OrderState = _this.GetEntityValue('OrderState');
        _this.ValidUntil = _this.GetEntityValue('ValidUntil');
        _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
        _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalAadscopedrlasgnMemberships.GetEntitySchema = function () {
        var columns = {
            'UID_Person': {
                ColumnName: 'UID_Person',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ObjectKeyAssignment': {
                ColumnName: 'ObjectKeyAssignment',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'IsPending': {
                ColumnName: 'IsPending',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsPrimary': {
                ColumnName: 'IsPrimary',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'OrderState': {
                ColumnName: 'OrderState',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ValidUntil': {
                ColumnName: 'ValidUntil',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'UID_UNSAccount': {
                ColumnName: 'UID_UNSAccount',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_UNSGroupChild': {
                ColumnName: 'UID_UNSGroupChild',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: '', Columns: columns };
    };
    return PortalAadscopedrlasgnMemberships;
}(TypedEntity));
/** @deprecated Use the PortalAadscopedrlasgnMemberships type. */
var PortalAadscopedrlasgnMembershipsInteractive = /** @class */ (function (_super) {
    __extends(PortalAadscopedrlasgnMembershipsInteractive, _super);
    function PortalAadscopedrlasgnMembershipsInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalAadscopedrlasgnMembershipsInteractive;
}(PortalAadscopedrlasgnMemberships));
var PortalAadscopedrlelgbMemberships = /** @class */ (function (_super) {
    __extends(PortalAadscopedrlelgbMemberships, _super);
    function PortalAadscopedrlelgbMemberships() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_Person = _this.GetEntityValue('UID_Person');
        _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.IsPending = _this.GetEntityValue('IsPending');
        _this.IsPrimary = _this.GetEntityValue('IsPrimary');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.OrderState = _this.GetEntityValue('OrderState');
        _this.ValidUntil = _this.GetEntityValue('ValidUntil');
        _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
        _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalAadscopedrlelgbMemberships.GetEntitySchema = function () {
        var columns = {
            'UID_Person': {
                ColumnName: 'UID_Person',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ObjectKeyAssignment': {
                ColumnName: 'ObjectKeyAssignment',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'IsPending': {
                ColumnName: 'IsPending',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsPrimary': {
                ColumnName: 'IsPrimary',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'OrderState': {
                ColumnName: 'OrderState',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ValidUntil': {
                ColumnName: 'ValidUntil',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'UID_UNSAccount': {
                ColumnName: 'UID_UNSAccount',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_UNSGroupChild': {
                ColumnName: 'UID_UNSGroupChild',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: '', Columns: columns };
    };
    return PortalAadscopedrlelgbMemberships;
}(TypedEntity));
/** @deprecated Use the PortalAadscopedrlelgbMemberships type. */
var PortalAadscopedrlelgbMembershipsInteractive = /** @class */ (function (_super) {
    __extends(PortalAadscopedrlelgbMembershipsInteractive, _super);
    function PortalAadscopedrlelgbMembershipsInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalAadscopedrlelgbMembershipsInteractive;
}(PortalAadscopedrlelgbMemberships));
var PortalAadsubskuMemberships = /** @class */ (function (_super) {
    __extends(PortalAadsubskuMemberships, _super);
    function PortalAadsubskuMemberships() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_Person = _this.GetEntityValue('UID_Person');
        _this.ObjectKeyAssignment = _this.GetEntityValue('ObjectKeyAssignment');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.IsPending = _this.GetEntityValue('IsPending');
        _this.IsPrimary = _this.GetEntityValue('IsPrimary');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.OrderState = _this.GetEntityValue('OrderState');
        _this.ValidUntil = _this.GetEntityValue('ValidUntil');
        _this.UID_UNSAccount = _this.GetEntityValue('UID_UNSAccount');
        _this.UID_UNSGroupChild = _this.GetEntityValue('UID_UNSGroupChild');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalAadsubskuMemberships.GetEntitySchema = function () {
        var columns = {
            'UID_Person': {
                ColumnName: 'UID_Person',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ObjectKeyAssignment': {
                ColumnName: 'ObjectKeyAssignment',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'IsPending': {
                ColumnName: 'IsPending',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'IsPrimary': {
                ColumnName: 'IsPrimary',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'OrderState': {
                ColumnName: 'OrderState',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'ValidUntil': {
                ColumnName: 'ValidUntil',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'UID_UNSAccount': {
                ColumnName: 'UID_UNSAccount',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_UNSGroupChild': {
                ColumnName: 'UID_UNSGroupChild',
                Type: ValType.String,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: '', Columns: columns };
    };
    return PortalAadsubskuMemberships;
}(TypedEntity));
/** @deprecated Use the PortalAadsubskuMemberships type. */
var PortalAadsubskuMembershipsInteractive = /** @class */ (function (_super) {
    __extends(PortalAadsubskuMembershipsInteractive, _super);
    function PortalAadsubskuMembershipsInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalAadsubskuMembershipsInteractive;
}(PortalAadsubskuMemberships));
var PortalShopConfigEntitlementsAaddeniedserviceplan = /** @class */ (function (_super) {
    __extends(PortalShopConfigEntitlementsAaddeniedserviceplan, _super);
    function PortalShopConfigEntitlementsAaddeniedserviceplan() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_ITShopOrg = _this.GetEntityValue('UID_ITShopOrg');
        _this.UID_AADDeniedServicePlan = _this.GetEntityValue('UID_AADDeniedServicePlan');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalShopConfigEntitlementsAaddeniedserviceplan.GetEntitySchema = function () {
        var columns = {
            'UID_ITShopOrg': {
                ColumnName: 'UID_ITShopOrg',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_AADDeniedServicePlan': {
                ColumnName: 'UID_AADDeniedServicePlan',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'ITShopOrgHasDeniedService', Columns: columns };
    };
    return PortalShopConfigEntitlementsAaddeniedserviceplan;
}(TypedEntity));
/** @deprecated Use the PortalShopConfigEntitlementsAaddeniedserviceplan type. */
var PortalShopConfigEntitlementsAaddeniedserviceplanInteractive = /** @class */ (function (_super) {
    __extends(PortalShopConfigEntitlementsAaddeniedserviceplanInteractive, _super);
    function PortalShopConfigEntitlementsAaddeniedserviceplanInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalShopConfigEntitlementsAaddeniedserviceplanInteractive;
}(PortalShopConfigEntitlementsAaddeniedserviceplan));
var PortalTargetsystemAaddirectoryrole = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAaddirectoryrole, _super);
    function PortalTargetsystemAaddirectoryrole() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.Requestable = _this.GetEntityValue('Requestable');
        _this.Owned = _this.GetEntityValue('Owned');
        _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemAaddirectoryrole.GetEntitySchema = function () {
        var columns = {
            'UID_AccProduct': {
                ColumnName: 'UID_AccProduct',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Requestable': {
                ColumnName: 'Requestable',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'Owned': {
                ColumnName: 'Owned',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XReadOnlyMemberships': {
                ColumnName: 'XReadOnlyMemberships',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AADDirectoryRole', Columns: columns };
    };
    return PortalTargetsystemAaddirectoryrole;
}(WriteExtTypedEntity));
/** @deprecated Use the PortalTargetsystemAaddirectoryrole type. */
var PortalTargetsystemAaddirectoryroleInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAaddirectoryroleInteractive, _super);
    function PortalTargetsystemAaddirectoryroleInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemAaddirectoryroleInteractive;
}(PortalTargetsystemAaddirectoryrole));
var PortalTargetsystemAadgroup = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadgroup, _super);
    function PortalTargetsystemAadgroup() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.HasReadOnlyMemberships = _this.GetEntityValue('HasReadOnlyMemberships');
        _this.Requestable = _this.GetEntityValue('Requestable');
        _this.Owned = _this.GetEntityValue('Owned');
        _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemAadgroup.GetEntitySchema = function () {
        var columns = {
            'UID_AccProduct': {
                ColumnName: 'UID_AccProduct',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'HasReadOnlyMemberships': {
                ColumnName: 'HasReadOnlyMemberships',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'Requestable': {
                ColumnName: 'Requestable',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'Owned': {
                ColumnName: 'Owned',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XReadOnlyMemberships': {
                ColumnName: 'XReadOnlyMemberships',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AADGroup', Columns: columns };
    };
    return PortalTargetsystemAadgroup;
}(WriteExtTypedEntity));
/** @deprecated Use the PortalTargetsystemAadgroup type. */
var PortalTargetsystemAadgroupInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadgroupInteractive, _super);
    function PortalTargetsystemAadgroupInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemAadgroupInteractive;
}(PortalTargetsystemAadgroup));
var PortalTargetsystemAadgroupChildren = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadgroupChildren, _super);
    function PortalTargetsystemAadgroupChildren() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_AADGroupContainer = _this.GetEntityValue('UID_AADGroupContainer');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.UID_AADGroupMember = _this.GetEntityValue('UID_AADGroupMember');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemAadgroupChildren.GetEntitySchema = function () {
        var columns = {
            'UID_AADGroupContainer': {
                ColumnName: 'UID_AADGroupContainer',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'UID_AADGroupMember': {
                ColumnName: 'UID_AADGroupMember',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AADGroupInGroup', Columns: columns };
    };
    return PortalTargetsystemAadgroupChildren;
}(TypedEntity));
/** @deprecated Use the PortalTargetsystemAadgroupChildren type. */
var PortalTargetsystemAadgroupChildrenInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadgroupChildrenInteractive, _super);
    function PortalTargetsystemAadgroupChildrenInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemAadgroupChildrenInteractive;
}(PortalTargetsystemAadgroupChildren));
var PortalTargetsystemAadgroupDeniedserviceplans = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadgroupDeniedserviceplans, _super);
    function PortalTargetsystemAadgroupDeniedserviceplans() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_AADGroup = _this.GetEntityValue('UID_AADGroup');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.UID_AADDeniedServicePlan = _this.GetEntityValue('UID_AADDeniedServicePlan');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemAadgroupDeniedserviceplans.GetEntitySchema = function () {
        var columns = {
            'UID_AADGroup': {
                ColumnName: 'UID_AADGroup',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'UID_AADDeniedServicePlan': {
                ColumnName: 'UID_AADDeniedServicePlan',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AADGroupHasDeniedService', Columns: columns };
    };
    return PortalTargetsystemAadgroupDeniedserviceplans;
}(TypedEntity));
/** @deprecated Use the PortalTargetsystemAadgroupDeniedserviceplans type. */
var PortalTargetsystemAadgroupDeniedserviceplansInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadgroupDeniedserviceplansInteractive, _super);
    function PortalTargetsystemAadgroupDeniedserviceplansInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemAadgroupDeniedserviceplansInteractive;
}(PortalTargetsystemAadgroupDeniedserviceplans));
var PortalTargetsystemAadgroupSubsku = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadgroupSubsku, _super);
    function PortalTargetsystemAadgroupSubsku() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_AADGroup = _this.GetEntityValue('UID_AADGroup');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.UID_AADSubSku = _this.GetEntityValue('UID_AADSubSku');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemAadgroupSubsku.GetEntitySchema = function () {
        var columns = {
            'UID_AADGroup': {
                ColumnName: 'UID_AADGroup',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'UID_AADSubSku': {
                ColumnName: 'UID_AADSubSku',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AADGroupHasSubSku', Columns: columns };
    };
    return PortalTargetsystemAadgroupSubsku;
}(TypedEntity));
/** @deprecated Use the PortalTargetsystemAadgroupSubsku type. */
var PortalTargetsystemAadgroupSubskuInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadgroupSubskuInteractive, _super);
    function PortalTargetsystemAadgroupSubskuInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemAadgroupSubskuInteractive;
}(PortalTargetsystemAadgroupSubsku));
var PortalTargetsystemAadscopedrlasgn = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadscopedrlasgn, _super);
    function PortalTargetsystemAadscopedrlasgn() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.Requestable = _this.GetEntityValue('Requestable');
        _this.Owned = _this.GetEntityValue('Owned');
        _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemAadscopedrlasgn.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Requestable': {
                ColumnName: 'Requestable',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'Owned': {
                ColumnName: 'Owned',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XReadOnlyMemberships': {
                ColumnName: 'XReadOnlyMemberships',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AADScopedRLAsgn', Columns: columns };
    };
    return PortalTargetsystemAadscopedrlasgn;
}(WriteExtTypedEntity));
/** @deprecated Use the PortalTargetsystemAadscopedrlasgn type. */
var PortalTargetsystemAadscopedrlasgnInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadscopedrlasgnInteractive, _super);
    function PortalTargetsystemAadscopedrlasgnInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemAadscopedrlasgnInteractive;
}(PortalTargetsystemAadscopedrlasgn));
var PortalTargetsystemAadscopedrlelgb = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadscopedrlelgb, _super);
    function PortalTargetsystemAadscopedrlelgb() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.Requestable = _this.GetEntityValue('Requestable');
        _this.Owned = _this.GetEntityValue('Owned');
        _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemAadscopedrlelgb.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Requestable': {
                ColumnName: 'Requestable',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'Owned': {
                ColumnName: 'Owned',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XReadOnlyMemberships': {
                ColumnName: 'XReadOnlyMemberships',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AADScopedRLElgb', Columns: columns };
    };
    return PortalTargetsystemAadscopedrlelgb;
}(WriteExtTypedEntity));
/** @deprecated Use the PortalTargetsystemAadscopedrlelgb type. */
var PortalTargetsystemAadscopedrlelgbInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadscopedrlelgbInteractive, _super);
    function PortalTargetsystemAadscopedrlelgbInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemAadscopedrlelgbInteractive;
}(PortalTargetsystemAadscopedrlelgb));
var PortalTargetsystemAadsubsku = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadsubsku, _super);
    function PortalTargetsystemAadsubsku() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_AccProduct = _this.GetEntityValue('UID_AccProduct');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.Requestable = _this.GetEntityValue('Requestable');
        _this.Owned = _this.GetEntityValue('Owned');
        _this.XReadOnlyMemberships = _this.GetEntityValue('XReadOnlyMemberships');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemAadsubsku.GetEntitySchema = function () {
        var columns = {
            'UID_AccProduct': {
                ColumnName: 'UID_AccProduct',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Requestable': {
                ColumnName: 'Requestable',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'Owned': {
                ColumnName: 'Owned',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XReadOnlyMemberships': {
                ColumnName: 'XReadOnlyMemberships',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AADSubSku', Columns: columns };
    };
    return PortalTargetsystemAadsubsku;
}(WriteExtTypedEntity));
/** @deprecated Use the PortalTargetsystemAadsubsku type. */
var PortalTargetsystemAadsubskuInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAadsubskuInteractive, _super);
    function PortalTargetsystemAadsubskuInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemAadsubskuInteractive;
}(PortalTargetsystemAadsubsku));
var PortalTargetsystemAaduser = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAaduser, _super);
    function PortalTargetsystemAaduser() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemAaduser.GetEntitySchema = function () {
        var columns = {};
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AADUser', Columns: columns };
    };
    return PortalTargetsystemAaduser;
}(TypedEntity));
/** @deprecated Use the PortalTargetsystemAaduser type. */
var PortalTargetsystemAaduserInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAaduserInteractive, _super);
    function PortalTargetsystemAaduserInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemAaduserInteractive;
}(PortalTargetsystemAaduser));
var PortalTargetsystemAaduserDeniedserviceplans = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAaduserDeniedserviceplans, _super);
    function PortalTargetsystemAaduserDeniedserviceplans() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_AADUser = _this.GetEntityValue('UID_AADUser');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.UID_AADDeniedServicePlan = _this.GetEntityValue('UID_AADDeniedServicePlan');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemAaduserDeniedserviceplans.GetEntitySchema = function () {
        var columns = {
            'UID_AADUser': {
                ColumnName: 'UID_AADUser',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'UID_AADDeniedServicePlan': {
                ColumnName: 'UID_AADDeniedServicePlan',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AADUserHasDeniedService', Columns: columns };
    };
    return PortalTargetsystemAaduserDeniedserviceplans;
}(TypedEntity));
/** @deprecated Use the PortalTargetsystemAaduserDeniedserviceplans type. */
var PortalTargetsystemAaduserDeniedserviceplansInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAaduserDeniedserviceplansInteractive, _super);
    function PortalTargetsystemAaduserDeniedserviceplansInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemAaduserDeniedserviceplansInteractive;
}(PortalTargetsystemAaduserDeniedserviceplans));
var PortalTargetsystemAaduserSubsku = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAaduserSubsku, _super);
    function PortalTargetsystemAaduserSubsku() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_AADUser = _this.GetEntityValue('UID_AADUser');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.ObjectKeyAADSubSku = _this.GetEntityValue('ObjectKeyAADSubSku');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalTargetsystemAaduserSubsku.GetEntitySchema = function () {
        var columns = {
            'UID_AADUser': {
                ColumnName: 'UID_AADUser',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'ObjectKeyAADSubSku': {
                ColumnName: 'ObjectKeyAADSubSku',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AADUserHasSubSku', Columns: columns };
    };
    return PortalTargetsystemAaduserSubsku;
}(TypedEntity));
/** @deprecated Use the PortalTargetsystemAaduserSubsku type. */
var PortalTargetsystemAaduserSubskuInteractive = /** @class */ (function (_super) {
    __extends(PortalTargetsystemAaduserSubskuInteractive, _super);
    function PortalTargetsystemAaduserSubskuInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalTargetsystemAaduserSubskuInteractive;
}(PortalTargetsystemAaduserSubsku));
var PortalAaddirectoryroleMembershipsWrapper = /** @class */ (function () {
    function PortalAaddirectoryroleMembershipsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalAaddirectoryroleMembershipsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/AADDirectoryRole/{uid}/memberships');
    };
    PortalAaddirectoryroleMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/AADDirectoryRole/{uid}/memberships');
            this.builder = new TypedEntityBuilder(PortalAaddirectoryroleMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalAaddirectoryroleMembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_AADDirectoryRole_memberships_get(uid, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalAaddirectoryroleMembershipsWrapper;
}());
var PortalAadgroupMembershipsWrapper = /** @class */ (function () {
    function PortalAadgroupMembershipsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalAadgroupMembershipsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/AADGroup/{uid}/memberships');
    };
    PortalAadgroupMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/AADGroup/{uid}/memberships');
            this.builder = new TypedEntityBuilder(PortalAadgroupMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalAadgroupMembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_AADGroup_memberships_get(uid, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalAadgroupMembershipsWrapper;
}());
var PortalAadscopedrlasgnMembershipsWrapper = /** @class */ (function () {
    function PortalAadscopedrlasgnMembershipsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalAadscopedrlasgnMembershipsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/AADScopedRLAsgn/{uid}/memberships');
    };
    PortalAadscopedrlasgnMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/AADScopedRLAsgn/{uid}/memberships');
            this.builder = new TypedEntityBuilder(PortalAadscopedrlasgnMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalAadscopedrlasgnMembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_AADScopedRLAsgn_memberships_get(uid, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalAadscopedrlasgnMembershipsWrapper;
}());
var PortalAadscopedrlelgbMembershipsWrapper = /** @class */ (function () {
    function PortalAadscopedrlelgbMembershipsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalAadscopedrlelgbMembershipsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/AADScopedRLElgb/{uid}/memberships');
    };
    PortalAadscopedrlelgbMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/AADScopedRLElgb/{uid}/memberships');
            this.builder = new TypedEntityBuilder(PortalAadscopedrlelgbMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalAadscopedrlelgbMembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_AADScopedRLElgb_memberships_get(uid, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalAadscopedrlelgbMembershipsWrapper;
}());
var PortalAadsubskuMembershipsWrapper = /** @class */ (function () {
    function PortalAadsubskuMembershipsWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalAadsubskuMembershipsWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/AADSubSku/{uid}/memberships');
    };
    PortalAadsubskuMembershipsWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/AADSubSku/{uid}/memberships');
            this.builder = new TypedEntityBuilder(PortalAadsubskuMemberships, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalAadsubskuMembershipsWrapper.prototype.Get = function (uid, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_AADSubSku_memberships_get(uid, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalAadsubskuMembershipsWrapper;
}());
var PortalShopConfigEntitlementsAaddeniedserviceplanWrapper = /** @class */ (function () {
    function PortalShopConfigEntitlementsAaddeniedserviceplanWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            {
                return _this.client.portal_shop_config_entitlements_AADDeniedServicePlan_post(entity.GetColumn('UID_ITShopOrg').GetValue(), writeData);
            }
        };
        this.deleteMethod = function (entity) {
            return _this.client.portal_shop_config_entitlements_AADDeniedServicePlan_delete(entity.GetColumn('UID_ITShopOrg').GetValue(), entity.GetColumn('UID_AADDeniedServicePlan').GetValue());
        };
    }
    PortalShopConfigEntitlementsAaddeniedserviceplanWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalShopConfigEntitlementsAaddeniedserviceplanWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan');
    };
    PortalShopConfigEntitlementsAaddeniedserviceplanWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan');
            this.builder = new TypedEntityBuilder(PortalShopConfigEntitlementsAaddeniedserviceplan, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalShopConfigEntitlementsAaddeniedserviceplanWrapper.prototype.Get = function (UID_ITShopOrg, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_AADDeniedServicePlan_get(UID_ITShopOrg, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalShopConfigEntitlementsAaddeniedserviceplanWrapper.prototype.Post = function (UID_ITShopOrg, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_AADDeniedServicePlan_post(UID_ITShopOrg, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalShopConfigEntitlementsAaddeniedserviceplanWrapper.prototype.Delete = function (UID_ITShopOrg, UID_AADDeniedServicePlan, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_AADDeniedServicePlan_delete(UID_ITShopOrg, UID_AADDeniedServicePlan, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalShopConfigEntitlementsAaddeniedserviceplanWrapper;
}());
var PortalTargetsystemAaddirectoryroleWrapper = /** @class */ (function () {
    function PortalTargetsystemAaddirectoryroleWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_aaddirectoryrole_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAaddirectoryroleWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aaddirectoryrole');
    };
    PortalTargetsystemAaddirectoryroleWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aaddirectoryrole');
            this.builder = new TypedEntityBuilder(PortalTargetsystemAaddirectoryrole, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAaddirectoryroleWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaddirectoryrole_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAaddirectoryroleWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaddirectoryrole_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAaddirectoryroleWrapper;
}());
var PortalTargetsystemAaddirectoryroleInteractiveWrapper = /** @class */ (function () {
    function PortalTargetsystemAaddirectoryroleInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_aaddirectoryrole_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAaddirectoryroleInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aaddirectoryrole/interactive');
    };
    PortalTargetsystemAaddirectoryroleInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aaddirectoryrole/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalTargetsystemAaddirectoryrole, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAaddirectoryroleInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaddirectoryrole_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAaddirectoryroleInteractiveWrapper.prototype.Get_byid = function (UID_AADDirectoryRole, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaddirectoryrole_interactive_byid_get(UID_AADDirectoryRole, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAaddirectoryroleInteractiveWrapper;
}());
var PortalTargetsystemAadgroupWrapper = /** @class */ (function () {
    function PortalTargetsystemAadgroupWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_aadgroup_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAadgroupWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aadgroup');
    };
    PortalTargetsystemAadgroupWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadgroup');
            this.builder = new TypedEntityBuilder(PortalTargetsystemAadgroup, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAadgroupWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadgroupWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAadgroupWrapper;
}());
var PortalTargetsystemAadgroupChildrenWrapper = /** @class */ (function () {
    function PortalTargetsystemAadgroupChildrenWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            {
                return _this.client.portal_targetsystem_aadgroup_children_post(entity.GetColumn('UID_AADGroupContainer').GetValue(), writeData);
            }
        };
        this.deleteMethod = function (entity) {
            return _this.client.portal_targetsystem_aadgroup_children_delete(entity.GetColumn('UID_AADGroupContainer').GetValue(), entity.GetColumn('UID_AADGroupMember').GetValue());
        };
    }
    PortalTargetsystemAadgroupChildrenWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAadgroupChildrenWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children');
    };
    PortalTargetsystemAadgroupChildrenWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children');
            this.builder = new TypedEntityBuilder(PortalTargetsystemAadgroupChildren, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAadgroupChildrenWrapper.prototype.Get = function (UID_AADGroupContainer, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_children_get(UID_AADGroupContainer, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadgroupChildrenWrapper.prototype.Post = function (UID_AADGroupContainer, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_children_post(UID_AADGroupContainer, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadgroupChildrenWrapper.prototype.Delete = function (UID_AADGroupContainer, UID_AADGroupMember, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_children_delete(UID_AADGroupContainer, UID_AADGroupMember, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAadgroupChildrenWrapper;
}());
var PortalTargetsystemAadgroupDeniedserviceplansWrapper = /** @class */ (function () {
    function PortalTargetsystemAadgroupDeniedserviceplansWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            if (entity.GetState() == EntityState.Created) {
                return _this.client.portal_targetsystem_aadgroup_deniedserviceplans_post(entity.GetColumn('UID_AADGroup').GetValue(), writeData);
            }
            return _this.client.portal_targetsystem_aadgroup_deniedserviceplans_put(entity.GetColumn('UID_AADGroup').GetValue(), writeData);
        };
        this.deleteMethod = function (entity) {
            return _this.client.portal_targetsystem_aadgroup_deniedserviceplans_delete(entity.GetColumn('UID_AADGroup').GetValue(), entity.GetColumn('UID_AADDeniedServicePlan').GetValue());
        };
    }
    PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans');
    };
    PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans');
            this.builder = new TypedEntityBuilder(PortalTargetsystemAadgroupDeniedserviceplans, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.Get = function (UID_AADGroup, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_deniedserviceplans_get(UID_AADGroup, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.Put = function (UID_AADGroup, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_deniedserviceplans_put(UID_AADGroup, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.Post = function (UID_AADGroup, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_deniedserviceplans_post(UID_AADGroup, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadgroupDeniedserviceplansWrapper.prototype.Delete = function (UID_AADGroup, UID_AADDeniedServicePlan, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_deniedserviceplans_delete(UID_AADGroup, UID_AADDeniedServicePlan, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAadgroupDeniedserviceplansWrapper;
}());
var PortalTargetsystemAadgroupInteractiveWrapper = /** @class */ (function () {
    function PortalTargetsystemAadgroupInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_aadgroup_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAadgroupInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aadgroup/interactive');
    };
    PortalTargetsystemAadgroupInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadgroup/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalTargetsystemAadgroup, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAadgroupInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadgroupInteractiveWrapper.prototype.Get_byid = function (UID_AADGroup, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_interactive_byid_get(UID_AADGroup, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAadgroupInteractiveWrapper;
}());
var PortalTargetsystemAadgroupSubskuWrapper = /** @class */ (function () {
    function PortalTargetsystemAadgroupSubskuWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            if (entity.GetState() == EntityState.Created) {
                return _this.client.portal_targetsystem_aadgroup_subsku_post(entity.GetColumn('UID_AADGroup').GetValue(), writeData);
            }
            return _this.client.portal_targetsystem_aadgroup_subsku_put(entity.GetColumn('UID_AADGroup').GetValue(), writeData);
        };
        this.deleteMethod = function (entity) {
            return _this.client.portal_targetsystem_aadgroup_subsku_delete(entity.GetColumn('UID_AADGroup').GetValue(), entity.GetColumn('UID_AADSubSku').GetValue());
        };
    }
    PortalTargetsystemAadgroupSubskuWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAadgroupSubskuWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aadgroup/{UID_AADGroup}/subsku');
    };
    PortalTargetsystemAadgroupSubskuWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadgroup/{UID_AADGroup}/subsku');
            this.builder = new TypedEntityBuilder(PortalTargetsystemAadgroupSubsku, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAadgroupSubskuWrapper.prototype.Get = function (UID_AADGroup, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_subsku_get(UID_AADGroup, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadgroupSubskuWrapper.prototype.Put = function (UID_AADGroup, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_subsku_put(UID_AADGroup, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadgroupSubskuWrapper.prototype.Post = function (UID_AADGroup, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_subsku_post(UID_AADGroup, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadgroupSubskuWrapper.prototype.Delete = function (UID_AADGroup, UID_AADSubSku, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadgroup_subsku_delete(UID_AADGroup, UID_AADSubSku, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAadgroupSubskuWrapper;
}());
var PortalTargetsystemAadscopedrlasgnWrapper = /** @class */ (function () {
    function PortalTargetsystemAadscopedrlasgnWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_aadscopedrlasgn_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAadscopedrlasgnWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aadscopedrlasgn');
    };
    PortalTargetsystemAadscopedrlasgnWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadscopedrlasgn');
            this.builder = new TypedEntityBuilder(PortalTargetsystemAadscopedrlasgn, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAadscopedrlasgnWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadscopedrlasgn_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadscopedrlasgnWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadscopedrlasgn_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAadscopedrlasgnWrapper;
}());
var PortalTargetsystemAadscopedrlasgnInteractiveWrapper = /** @class */ (function () {
    function PortalTargetsystemAadscopedrlasgnInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_aadscopedrlasgn_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAadscopedrlasgnInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aadscopedrlasgn/interactive');
    };
    PortalTargetsystemAadscopedrlasgnInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadscopedrlasgn/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalTargetsystemAadscopedrlasgn, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAadscopedrlasgnInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadscopedrlasgn_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadscopedrlasgnInteractiveWrapper.prototype.Get_byid = function (UID_AADScopedRLAsgn, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadscopedrlasgn_interactive_byid_get(UID_AADScopedRLAsgn, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAadscopedrlasgnInteractiveWrapper;
}());
var PortalTargetsystemAadscopedrlelgbWrapper = /** @class */ (function () {
    function PortalTargetsystemAadscopedrlelgbWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_aadscopedrlelgb_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAadscopedrlelgbWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aadscopedrlelgb');
    };
    PortalTargetsystemAadscopedrlelgbWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadscopedrlelgb');
            this.builder = new TypedEntityBuilder(PortalTargetsystemAadscopedrlelgb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAadscopedrlelgbWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadscopedrlelgb_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadscopedrlelgbWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadscopedrlelgb_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAadscopedrlelgbWrapper;
}());
var PortalTargetsystemAadscopedrlelgbInteractiveWrapper = /** @class */ (function () {
    function PortalTargetsystemAadscopedrlelgbInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_aadscopedrlelgb_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAadscopedrlelgbInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aadscopedrlelgb/interactive');
    };
    PortalTargetsystemAadscopedrlelgbInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadscopedrlelgb/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalTargetsystemAadscopedrlelgb, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAadscopedrlelgbInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadscopedrlelgb_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadscopedrlelgbInteractiveWrapper.prototype.Get_byid = function (UID_AADScopedRLElgb, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadscopedrlelgb_interactive_byid_get(UID_AADScopedRLElgb, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAadscopedrlelgbInteractiveWrapper;
}());
var PortalTargetsystemAadsubskuWrapper = /** @class */ (function () {
    function PortalTargetsystemAadsubskuWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_aadsubsku_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAadsubskuWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aadsubsku');
    };
    PortalTargetsystemAadsubskuWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadsubsku');
            this.builder = new TypedEntityBuilder(PortalTargetsystemAadsubsku, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAadsubskuWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadsubsku_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadsubskuWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadsubsku_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAadsubskuWrapper;
}());
var PortalTargetsystemAadsubskuInteractiveWrapper = /** @class */ (function () {
    function PortalTargetsystemAadsubskuInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_aadsubsku_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAadsubskuInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aadsubsku/interactive');
    };
    PortalTargetsystemAadsubskuInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aadsubsku/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalTargetsystemAadsubsku, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAadsubskuInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadsubsku_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAadsubskuInteractiveWrapper.prototype.Get_byid = function (UID_AADSubSku, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aadsubsku_interactive_byid_get(UID_AADSubSku, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAadsubskuInteractiveWrapper;
}());
var PortalTargetsystemAaduserWrapper = /** @class */ (function () {
    function PortalTargetsystemAaduserWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_aaduser_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAaduserWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aaduser');
    };
    PortalTargetsystemAaduserWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aaduser');
            this.builder = new TypedEntityBuilder(PortalTargetsystemAaduser, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAaduserWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAaduserWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_put(inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAaduserWrapper;
}());
var PortalTargetsystemAaduserDeniedserviceplansWrapper = /** @class */ (function () {
    function PortalTargetsystemAaduserDeniedserviceplansWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            if (entity.GetState() == EntityState.Created) {
                return _this.client.portal_targetsystem_aaduser_deniedserviceplans_post(entity.GetColumn('UID_AADUser').GetValue(), writeData);
            }
            return _this.client.portal_targetsystem_aaduser_deniedserviceplans_put(entity.GetColumn('UID_AADUser').GetValue(), writeData);
        };
        this.deleteMethod = function (entity) {
            return _this.client.portal_targetsystem_aaduser_deniedserviceplans_delete(entity.GetColumn('UID_AADUser').GetValue(), entity.GetColumn('UID_AADDeniedServicePlan').GetValue());
        };
    }
    PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans');
    };
    PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans');
            this.builder = new TypedEntityBuilder(PortalTargetsystemAaduserDeniedserviceplans, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.Get = function (UID_AADUser, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_deniedserviceplans_get(UID_AADUser, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.Put = function (UID_AADUser, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_deniedserviceplans_put(UID_AADUser, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.Post = function (UID_AADUser, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_deniedserviceplans_post(UID_AADUser, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAaduserDeniedserviceplansWrapper.prototype.Delete = function (UID_AADUser, UID_AADDeniedServicePlan, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_deniedserviceplans_delete(UID_AADUser, UID_AADDeniedServicePlan, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAaduserDeniedserviceplansWrapper;
}());
var PortalTargetsystemAaduserInteractiveWrapper = /** @class */ (function () {
    function PortalTargetsystemAaduserInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_targetsystem_aaduser_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAaduserInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aaduser/interactive');
    };
    PortalTargetsystemAaduserInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aaduser/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalTargetsystemAaduser, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAaduserInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAaduserInteractiveWrapper.prototype.Get_byid = function (UID_AADUser, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_interactive_byid_get(UID_AADUser, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAaduserInteractiveWrapper;
}());
var PortalTargetsystemAaduserSubskuWrapper = /** @class */ (function () {
    function PortalTargetsystemAaduserSubskuWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            if (entity.GetState() == EntityState.Created) {
                return _this.client.portal_targetsystem_aaduser_subsku_post(entity.GetColumn('UID_AADUser').GetValue(), writeData);
            }
            return _this.client.portal_targetsystem_aaduser_subsku_put(entity.GetColumn('UID_AADUser').GetValue(), writeData);
        };
        this.deleteMethod = function (entity) {
            return _this.client.portal_targetsystem_aaduser_subsku_delete(entity.GetColumn('UID_AADUser').GetValue(), entity.GetColumn('UID_AADUserHasSubSku').GetValue());
        };
    }
    PortalTargetsystemAaduserSubskuWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalTargetsystemAaduserSubskuWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/targetsystem/aaduser/{UID_AADUser}/subsku');
    };
    PortalTargetsystemAaduserSubskuWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/targetsystem/aaduser/{UID_AADUser}/subsku');
            this.builder = new TypedEntityBuilder(PortalTargetsystemAaduserSubsku, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalTargetsystemAaduserSubskuWrapper.prototype.Get = function (UID_AADUser, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_subsku_get(UID_AADUser, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAaduserSubskuWrapper.prototype.Put = function (UID_AADUser, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_subsku_put(UID_AADUser, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAaduserSubskuWrapper.prototype.Post = function (UID_AADUser, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_subsku_post(UID_AADUser, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalTargetsystemAaduserSubskuWrapper.prototype.Delete = function (UID_AADUser, UID_AADUserHasSubSku, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_targetsystem_aaduser_subsku_delete(UID_AADUser, UID_AADUserHasSubSku, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalTargetsystemAaduserSubskuWrapper;
}());
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
var ApiClientMethodFactory = /** @class */ (function () {
    function ApiClientMethodFactory() {
    }
    ApiClientMethodFactory.prototype.portal_AADDirectoryRole_memberships_get = function (uid) {
        return {
            path: '/portal/AADDirectoryRole/{uid}/memberships',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_AADDirectoryRole_memberships_delete = function (uid, uidaccount) {
        return {
            path: '/portal/AADDirectoryRole/{uid}/memberships/{uidaccount}',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_AADGroup_memberships_get = function (uid) {
        return {
            path: '/portal/AADGroup/{uid}/memberships',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_AADGroup_memberships_delete = function (uid, uidaccount) {
        return {
            path: '/portal/AADGroup/{uid}/memberships/{uidaccount}',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_AADScopedRLAsgn_memberships_get = function (uid) {
        return {
            path: '/portal/AADScopedRLAsgn/{uid}/memberships',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_AADScopedRLAsgn_memberships_delete = function (uid, uidaccount) {
        return {
            path: '/portal/AADScopedRLAsgn/{uid}/memberships/{uidaccount}',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_AADScopedRLElgb_memberships_get = function (uid) {
        return {
            path: '/portal/AADScopedRLElgb/{uid}/memberships',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_AADScopedRLElgb_memberships_delete = function (uid, uidaccount) {
        return {
            path: '/portal/AADScopedRLElgb/{uid}/memberships/{uidaccount}',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_AADSubSku_memberships_get = function (uid) {
        return {
            path: '/portal/AADSubSku/{uid}/memberships',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_AADSubSku_memberships_delete = function (uid, uidaccount) {
        return {
            path: '/portal/AADSubSku/{uid}/memberships/{uidaccount}',
            parameters: [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_post = function (UID_ITShopOrg, inputParameterName) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_delete = function (UID_ITShopOrg, UID_AADDeniedServicePlan) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/{UID_AADDeniedServicePlan}',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AADDeniedServicePlan',
                    value: UID_AADDeniedServicePlan,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaddirectoryrole_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
        return {
            path: '/portal/targetsystem/aaddirectoryrole',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'published',
                    value: published,
                    in: 'query'
                },
                {
                    name: 'withowner',
                    value: withowner,
                    in: 'query'
                },
                {
                    name: 'deletedintarget',
                    value: deletedintarget,
                    in: 'query'
                },
                {
                    name: 'risk',
                    value: risk,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaddirectoryrole_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aaddirectoryrole',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaddirectoryrole_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aaddirectoryrole/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaddirectoryrole_datamodel_get = function (filter) {
        return {
            path: '/portal/targetsystem/aaddirectoryrole/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaddirectoryrole_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aaddirectoryrole/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaddirectoryrole_interactive_byid_get = function (UID_AADDirectoryRole) {
        return {
            path: '/portal/targetsystem/aaddirectoryrole/interactive/{UID_AADDirectoryRole}',
            parameters: [
                {
                    name: 'UID_AADDirectoryRole',
                    value: UID_AADDirectoryRole,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
        return {
            path: '/portal/targetsystem/aadgroup',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'published',
                    value: published,
                    in: 'query'
                },
                {
                    name: 'withowner',
                    value: withowner,
                    in: 'query'
                },
                {
                    name: 'deletedintarget',
                    value: deletedintarget,
                    in: 'query'
                },
                {
                    name: 'risk',
                    value: risk,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_get = function (UID_AADGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_put = function (UID_AADGroup, inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_post = function (UID_AADGroup, inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_delete = function (UID_AADGroup, UID_AADDeniedServicePlan) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/{UID_AADDeniedServicePlan}',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AADDeniedServicePlan',
                    value: UID_AADDeniedServicePlan,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_bulk_put = function (UID_AADGroup, inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/bulk',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (UID_AADGroup, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_AADGroup, filter) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_AADGroup, xorigin, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_get = function (UID_AADGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_put = function (UID_AADGroup, inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_post = function (UID_AADGroup, inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_delete = function (UID_AADGroup, UID_AADSubSku) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/{UID_AADSubSku}',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AADSubSku',
                    value: UID_AADSubSku,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_bulk_put = function (UID_AADGroup, inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/bulk',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get = function (UID_AADGroup, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get = function (UID_AADGroup, filter) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post = function (UID_AADGroup, xorigin, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_children_get = function (UID_AADGroupContainer, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children',
            parameters: [
                {
                    name: 'UID_AADGroupContainer',
                    value: UID_AADGroupContainer,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_children_post = function (UID_AADGroupContainer, inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children',
            parameters: [
                {
                    name: 'UID_AADGroupContainer',
                    value: UID_AADGroupContainer,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_children_delete = function (UID_AADGroupContainer, UID_AADGroupMember) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children/{UID_AADGroupMember}',
            parameters: [
                {
                    name: 'UID_AADGroupContainer',
                    value: UID_AADGroupContainer,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AADGroupMember',
                    value: UID_AADGroupMember,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get = function (UID_AADGroupContainer, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates',
            parameters: [
                {
                    name: 'UID_AADGroupContainer',
                    value: UID_AADGroupContainer,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get = function (UID_AADGroupContainer, filter) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_AADGroupContainer',
                    value: UID_AADGroupContainer,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post = function (UID_AADGroupContainer, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_AADGroupContainer',
                    value: UID_AADGroupContainer,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_datamodel_get = function (filter) {
        return {
            path: '/portal/targetsystem/aadgroup/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aadgroup/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_interactive_byid_get = function (UID_AADGroup) {
        return {
            path: '/portal/targetsystem/aadgroup/interactive/{UID_AADGroup}',
            parameters: [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlasgn_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
        return {
            path: '/portal/targetsystem/aadscopedrlasgn',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'published',
                    value: published,
                    in: 'query'
                },
                {
                    name: 'withowner',
                    value: withowner,
                    in: 'query'
                },
                {
                    name: 'deletedintarget',
                    value: deletedintarget,
                    in: 'query'
                },
                {
                    name: 'risk',
                    value: risk,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlasgn_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aadscopedrlasgn',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlasgn_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aadscopedrlasgn/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlasgn_datamodel_get = function (filter) {
        return {
            path: '/portal/targetsystem/aadscopedrlasgn/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlasgn_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aadscopedrlasgn/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlasgn_interactive_byid_get = function (UID_AADScopedRLAsgn) {
        return {
            path: '/portal/targetsystem/aadscopedrlasgn/interactive/{UID_AADScopedRLAsgn}',
            parameters: [
                {
                    name: 'UID_AADScopedRLAsgn',
                    value: UID_AADScopedRLAsgn,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlelgb_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
        return {
            path: '/portal/targetsystem/aadscopedrlelgb',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'published',
                    value: published,
                    in: 'query'
                },
                {
                    name: 'withowner',
                    value: withowner,
                    in: 'query'
                },
                {
                    name: 'deletedintarget',
                    value: deletedintarget,
                    in: 'query'
                },
                {
                    name: 'risk',
                    value: risk,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlelgb_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aadscopedrlelgb',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlelgb_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aadscopedrlelgb/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlelgb_datamodel_get = function (filter) {
        return {
            path: '/portal/targetsystem/aadscopedrlelgb/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlelgb_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aadscopedrlelgb/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlelgb_interactive_byid_get = function (UID_AADScopedRLElgb) {
        return {
            path: '/portal/targetsystem/aadscopedrlelgb/interactive/{UID_AADScopedRLElgb}',
            parameters: [
                {
                    name: 'UID_AADScopedRLElgb',
                    value: UID_AADScopedRLElgb,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk) {
        return {
            path: '/portal/targetsystem/aadsubsku',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'published',
                    value: published,
                    in: 'query'
                },
                {
                    name: 'withowner',
                    value: withowner,
                    in: 'query'
                },
                {
                    name: 'deletedintarget',
                    value: deletedintarget,
                    in: 'query'
                },
                {
                    name: 'risk',
                    value: risk,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aadsubsku',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_licenceoverview_get = function (UID_AADSubSku) {
        return {
            path: '/portal/targetsystem/aadsubsku/{UID_AADSubSku}/licenceoverview',
            parameters: [
                {
                    name: 'UID_AADSubSku',
                    value: UID_AADSubSku,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aadsubsku/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_datamodel_get = function (filter) {
        return {
            path: '/portal/targetsystem/aadsubsku/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aadsubsku/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_interactive_byid_get = function (UID_AADSubSku) {
        return {
            path: '/portal/targetsystem/aadsubsku/interactive/{UID_AADSubSku}',
            parameters: [
                {
                    name: 'UID_AADSubSku',
                    value: UID_AADSubSku,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_get = function (UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk) {
        return {
            path: '/portal/targetsystem/aaduser',
            parameters: [
                {
                    name: 'UID_PersonAssociated',
                    value: UID_PersonAssociated,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'orphaned',
                    value: orphaned,
                    in: 'query'
                },
                {
                    name: 'deletedintarget',
                    value: deletedintarget,
                    in: 'query'
                },
                {
                    name: 'risk',
                    value: risk,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aaduser',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_get = function (UID_AADUser, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_put = function (UID_AADUser, inputParameterName) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_post = function (UID_AADUser, inputParameterName) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_delete = function (UID_AADUser, UID_AADDeniedServicePlan) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/{UID_AADDeniedServicePlan}',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AADDeniedServicePlan',
                    value: UID_AADDeniedServicePlan,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_bulk_put = function (UID_AADUser, inputParameterName) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/bulk',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (UID_AADUser, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_AADUser, filter) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_AADUser, xorigin, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_get = function (UID_AADUser, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_put = function (UID_AADUser, inputParameterName) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_post = function (UID_AADUser, inputParameterName) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_delete = function (UID_AADUser, UID_AADUserHasSubSku) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/{UID_AADUserHasSubSku}',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AADUserHasSubSku',
                    value: UID_AADUserHasSubSku,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_bulk_put = function (UID_AADUser, inputParameterName) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/bulk',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get = function (UID_AADUser, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get = function (UID_AADUser, filter) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post = function (UID_AADUser, xorigin, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aaduser/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_datamodel_get = function (filter) {
        return {
            path: '/portal/targetsystem/aaduser/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/targetsystem/aaduser/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_interactive_byid_get = function (UID_AADUser) {
        return {
            path: '/portal/targetsystem/aaduser/interactive/{UID_AADUser}',
            parameters: [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return ApiClientMethodFactory;
}());
/** @deprecated Use the V2Client class for a stable method interface. */
var Client = /** @class */ (function () {
    function Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    Client.prototype.portal_AADDirectoryRole_memberships_get = function (uid, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADDirectoryRole_memberships_get(uid), requestOptions);
    };
    /** Deletes an account membership. */
    Client.prototype.portal_AADDirectoryRole_memberships_delete = function (uid, uidaccount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADDirectoryRole_memberships_delete(uid, uidaccount), requestOptions);
    };
    Client.prototype.portal_AADGroup_memberships_get = function (uid, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADGroup_memberships_get(uid), requestOptions);
    };
    /** Deletes an account membership. */
    Client.prototype.portal_AADGroup_memberships_delete = function (uid, uidaccount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADGroup_memberships_delete(uid, uidaccount), requestOptions);
    };
    Client.prototype.portal_AADScopedRLAsgn_memberships_get = function (uid, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADScopedRLAsgn_memberships_get(uid), requestOptions);
    };
    /** Deletes an account membership. */
    Client.prototype.portal_AADScopedRLAsgn_memberships_delete = function (uid, uidaccount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADScopedRLAsgn_memberships_delete(uid, uidaccount), requestOptions);
    };
    Client.prototype.portal_AADScopedRLElgb_memberships_get = function (uid, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADScopedRLElgb_memberships_get(uid), requestOptions);
    };
    /** Deletes an account membership. */
    Client.prototype.portal_AADScopedRLElgb_memberships_delete = function (uid, uidaccount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADScopedRLElgb_memberships_delete(uid, uidaccount), requestOptions);
    };
    Client.prototype.portal_AADSubSku_memberships_get = function (uid, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADSubSku_memberships_get(uid), requestOptions);
    };
    /** Deletes an account membership. */
    Client.prototype.portal_AADSubSku_memberships_delete = function (uid, uidaccount, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADSubSku_memberships_delete(uid, uidaccount), requestOptions);
    };
    Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_post = function (UID_ITShopOrg, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_post(UID_ITShopOrg, inputParameterName), requestOptions);
    };
    Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_delete = function (UID_ITShopOrg, UID_AADDeniedServicePlan, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_delete(UID_ITShopOrg, UID_AADDeniedServicePlan), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADDirectoryRole. */
    Client.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADGroup. */
    Client.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
    Client.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaddirectoryrole_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaddirectoryrole_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaddirectoryrole_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaddirectoryrole_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaddirectoryrole_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaddirectoryrole_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aaddirectoryrole endpoint. */
    Client.prototype.portal_targetsystem_aaddirectoryrole_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaddirectoryrole_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaddirectoryrole_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaddirectoryrole_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaddirectoryrole_interactive_byid_get = function (UID_AADDirectoryRole, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaddirectoryrole_interactive_byid_get(UID_AADDirectoryRole), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_get = function (UID_AADGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_get(UID_AADGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_put = function (UID_AADGroup, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_put(UID_AADGroup, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_post = function (UID_AADGroup, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_post(UID_AADGroup, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_delete = function (UID_AADGroup, UID_AADDeniedServicePlan, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_delete(UID_AADGroup, UID_AADDeniedServicePlan), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_bulk_put = function (UID_AADGroup, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_bulk_put(UID_AADGroup, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (UID_AADGroup, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADGroup, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_AADGroup, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADGroup, filter), requestOptions);
    };
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_AADGroup, xorigin, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADGroup, xorigin, filter, parentkey, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_subsku_get = function (UID_AADGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_get(UID_AADGroup, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_subsku_put = function (UID_AADGroup, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_put(UID_AADGroup, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_subsku_post = function (UID_AADGroup, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_post(UID_AADGroup, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_subsku_delete = function (UID_AADGroup, UID_AADSubSku, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_delete(UID_AADGroup, UID_AADSubSku), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_subsku_bulk_put = function (UID_AADGroup, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_bulk_put(UID_AADGroup, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
    Client.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get = function (UID_AADGroup, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get(UID_AADGroup, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
    Client.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get = function (UID_AADGroup, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get(UID_AADGroup, filter), requestOptions);
    };
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
    Client.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post = function (UID_AADGroup, xorigin, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post(UID_AADGroup, xorigin, filter, parentkey, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_children_get = function (UID_AADGroupContainer, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_children_get(UID_AADGroupContainer, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_children_post = function (UID_AADGroupContainer, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_children_post(UID_AADGroupContainer, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_children_delete = function (UID_AADGroupContainer, UID_AADGroupMember, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_children_delete(UID_AADGroupContainer, UID_AADGroupMember), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADGroupMember. */
    Client.prototype.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get = function (UID_AADGroupContainer, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get(UID_AADGroupContainer, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates endpoint. */
    Client.prototype.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get = function (UID_AADGroupContainer, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get(UID_AADGroupContainer, filter), requestOptions);
    };
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates endpoint. */
    Client.prototype.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post = function (UID_AADGroupContainer, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post(UID_AADGroupContainer, filter, parentkey, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadgroup endpoint. */
    Client.prototype.portal_targetsystem_aadgroup_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadgroup_interactive_byid_get = function (UID_AADGroup, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_interactive_byid_get(UID_AADGroup), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadscopedrlasgn_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlasgn_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadscopedrlasgn_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlasgn_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadscopedrlasgn_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlasgn_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadscopedrlasgn endpoint. */
    Client.prototype.portal_targetsystem_aadscopedrlasgn_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlasgn_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadscopedrlasgn_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlasgn_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadscopedrlasgn_interactive_byid_get = function (UID_AADScopedRLAsgn, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlasgn_interactive_byid_get(UID_AADScopedRLAsgn), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadscopedrlelgb_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlelgb_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadscopedrlelgb_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlelgb_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadscopedrlelgb_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlelgb_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadscopedrlelgb endpoint. */
    Client.prototype.portal_targetsystem_aadscopedrlelgb_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlelgb_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadscopedrlelgb_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlelgb_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadscopedrlelgb_interactive_byid_get = function (UID_AADScopedRLElgb, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlelgb_interactive_byid_get(UID_AADScopedRLElgb), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadsubsku_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published, withowner, deletedintarget, risk), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadsubsku_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadsubsku_licenceoverview_get = function (UID_AADSubSku, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_licenceoverview_get(UID_AADSubSku), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadsubsku_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadsubsku endpoint. */
    Client.prototype.portal_targetsystem_aadsubsku_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadsubsku_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aadsubsku_interactive_byid_get = function (UID_AADSubSku, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_interactive_byid_get(UID_AADSubSku), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_get = function (UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_get(UID_PersonAssociated, OrderBy, StartIndex, PageSize, filter, withProperties, search, orphaned, deletedintarget, risk), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_get = function (UID_AADUser, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_get(UID_AADUser, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_put = function (UID_AADUser, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_put(UID_AADUser, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_post = function (UID_AADUser, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_post(UID_AADUser, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_delete = function (UID_AADUser, UID_AADDeniedServicePlan, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_delete(UID_AADUser, UID_AADDeniedServicePlan), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_bulk_put = function (UID_AADUser, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_bulk_put(UID_AADUser, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (UID_AADUser, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADUser, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (UID_AADUser, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADUser, filter), requestOptions);
    };
    /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (UID_AADUser, xorigin, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADUser, xorigin, filter, parentkey, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_subsku_get = function (UID_AADUser, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_get(UID_AADUser, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_subsku_put = function (UID_AADUser, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_put(UID_AADUser, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_subsku_post = function (UID_AADUser, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_post(UID_AADUser, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_subsku_delete = function (UID_AADUser, UID_AADUserHasSubSku, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_delete(UID_AADUser, UID_AADUserHasSubSku), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_subsku_bulk_put = function (UID_AADUser, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_bulk_put(UID_AADUser, inputParameterName), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property ObjectKeyAADSubSku. */
    Client.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get = function (UID_AADUser, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get(UID_AADUser, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
    Client.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get = function (UID_AADUser, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get(UID_AADUser, filter), requestOptions);
    };
    /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
    Client.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post = function (UID_AADUser, xorigin, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post(UID_AADUser, xorigin, filter, parentkey, inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aaduser endpoint. */
    Client.prototype.portal_targetsystem_aaduser_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_targetsystem_aaduser_interactive_byid_get = function (UID_AADUser, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_interactive_byid_get(UID_AADUser), requestOptions);
    };
    return Client;
}());
var V2ApiClientMethodFactory = /** @class */ (function () {
    function V2ApiClientMethodFactory() {
    }
    V2ApiClientMethodFactory.prototype.portal_AADDirectoryRole_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/AADDirectoryRole/{uid}/memberships',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_AADDirectoryRole_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/AADDirectoryRole/{uid}/memberships/{uidaccount}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_AADGroup_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/AADGroup/{uid}/memberships',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_AADGroup_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/AADGroup/{uid}/memberships/{uidaccount}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_AADScopedRLAsgn_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/AADScopedRLAsgn/{uid}/memberships',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_AADScopedRLAsgn_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/AADScopedRLAsgn/{uid}/memberships/{uidaccount}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_AADScopedRLElgb_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/AADScopedRLElgb/{uid}/memberships',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_AADScopedRLElgb_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/AADScopedRLElgb/{uid}/memberships/{uidaccount}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_AADSubSku_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/AADSubSku/{uid}/memberships',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_AADSubSku_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/AADSubSku/{uid}/memberships/{uidaccount}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'uid',
                    value: uid,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'uidaccount',
                    value: uidaccount,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** Disabled Azure Active Directory service plan */ UID_AADDeniedServicePlan, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/{UID_AADDeniedServicePlan}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AADDeniedServicePlan',
                    value: UID_AADDeniedServicePlan,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaddirectoryrole_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaddirectoryrole',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaddirectoryrole_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaddirectoryrole',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaddirectoryrole_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaddirectoryrole/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaddirectoryrole_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaddirectoryrole/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaddirectoryrole_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaddirectoryrole/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaddirectoryrole_interactive_byid_get = function (/** Primary key value UID_AADDirectoryRole */ UID_AADDirectoryRole, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaddirectoryrole/interactive/{UID_AADDirectoryRole}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADDirectoryRole',
                    value: UID_AADDirectoryRole,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_get = function (/** Unique identifier of the base object */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_put = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_post = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_delete = function (/** Unique identifier of the base object */ UID_AADGroup, /** Disabled Azure Active Directory service plan */ UID_AADDeniedServicePlan, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/{UID_AADDeniedServicePlan}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AADDeniedServicePlan',
                    value: UID_AADDeniedServicePlan,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_bulk_put = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (/** Unique identifier of the base object */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (/** Unique identifier of the base object */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_get = function (/** Unique identifier of the base object */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_put = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_post = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_delete = function (/** Unique identifier of the base object */ UID_AADGroup, /** Azure Active Directory subscription */ UID_AADSubSku, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/{UID_AADSubSku}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AADSubSku',
                    value: UID_AADSubSku,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_bulk_put = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get = function (/** Unique identifier of the base object */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get = function (/** Unique identifier of the base object */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_children_get = function (/** Unique identifier of the base object */ UID_AADGroupContainer, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroupContainer',
                    value: UID_AADGroupContainer,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_children_post = function (/** Unique identifier of the base object */ UID_AADGroupContainer, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroupContainer',
                    value: UID_AADGroupContainer,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_children_delete = function (/** Unique identifier of the base object */ UID_AADGroupContainer, /** Member group */ UID_AADGroupMember, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children/{UID_AADGroupMember}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroupContainer',
                    value: UID_AADGroupContainer,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AADGroupMember',
                    value: UID_AADGroupMember,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get = function (/** Unique identifier of the base object */ UID_AADGroupContainer, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroupContainer',
                    value: UID_AADGroupContainer,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get = function (/** Unique identifier of the base object */ UID_AADGroupContainer, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroupContainer',
                    value: UID_AADGroupContainer,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post = function (/** Unique identifier of the base object */ UID_AADGroupContainer, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroupContainer',
                    value: UID_AADGroupContainer,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadgroup_interactive_byid_get = function (/** Primary key value UID_AADGroup */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadgroup/interactive/{UID_AADGroup}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADGroup',
                    value: UID_AADGroup,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlasgn_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadscopedrlasgn',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlasgn_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadscopedrlasgn',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlasgn_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadscopedrlasgn/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlasgn_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadscopedrlasgn/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlasgn_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadscopedrlasgn/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlasgn_interactive_byid_get = function (/** Primary key value UID_AADScopedRLAsgn */ UID_AADScopedRLAsgn, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadscopedrlasgn/interactive/{UID_AADScopedRLAsgn}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADScopedRLAsgn',
                    value: UID_AADScopedRLAsgn,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlelgb_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadscopedrlelgb',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlelgb_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadscopedrlelgb',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlelgb_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadscopedrlelgb/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlelgb_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadscopedrlelgb/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlelgb_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadscopedrlelgb/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadscopedrlelgb_interactive_byid_get = function (/** Primary key value UID_AADScopedRLElgb */ UID_AADScopedRLElgb, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadscopedrlelgb/interactive/{UID_AADScopedRLElgb}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADScopedRLElgb',
                    value: UID_AADScopedRLElgb,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadsubsku',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadsubsku',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_licenceoverview_get = function (UID_AADSubSku, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadsubsku/{UID_AADSubSku}/licenceoverview',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADSubSku',
                    value: UID_AADSubSku,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadsubsku/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadsubsku/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadsubsku/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aadsubsku_interactive_byid_get = function (/** Primary key value UID_AADSubSku */ UID_AADSubSku, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aadsubsku/interactive/{UID_AADSubSku}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADSubSku',
                    value: UID_AADSubSku,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_get = function (/** Unique identifier of the base object */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_put = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_post = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_delete = function (/** Unique identifier of the base object */ UID_AADUser, /** Disabled Azure Active Directory service plan */ UID_AADDeniedServicePlan, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/{UID_AADDeniedServicePlan}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AADDeniedServicePlan',
                    value: UID_AADDeniedServicePlan,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_bulk_put = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (/** Unique identifier of the base object */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (/** Unique identifier of the base object */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_get = function (/** Unique identifier of the base object */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_put = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_post = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_delete = function (/** Unique identifier of the base object */ UID_AADUser, /** Subscription assignment */ UID_AADUserHasSubSku, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/{UID_AADUserHasSubSku}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_AADUserHasSubSku',
                    value: UID_AADUserHasSubSku,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_bulk_put = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get = function (/** Unique identifier of the base object */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get = function (/** Unique identifier of the base object */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_targetsystem_aaduser_interactive_byid_get = function (/** Primary key value UID_AADUser */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/targetsystem/aaduser/interactive/{UID_AADUser}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AADUser',
                    value: UID_AADUser,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return V2ApiClientMethodFactory;
}());
var V2Client = /** @class */ (function () {
    function V2Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new V2ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(V2Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    V2Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    V2Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    V2Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    V2Client.prototype.portal_AADDirectoryRole_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADDirectoryRole_memberships_get(uid, options), requestOptions);
    };
    /** Deletes an account membership. */
    V2Client.prototype.portal_AADDirectoryRole_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADDirectoryRole_memberships_delete(uid, uidaccount, options), requestOptions);
    };
    V2Client.prototype.portal_AADGroup_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADGroup_memberships_get(uid, options), requestOptions);
    };
    /** Deletes an account membership. */
    V2Client.prototype.portal_AADGroup_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADGroup_memberships_delete(uid, uidaccount, options), requestOptions);
    };
    V2Client.prototype.portal_AADScopedRLAsgn_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADScopedRLAsgn_memberships_get(uid, options), requestOptions);
    };
    /** Deletes an account membership. */
    V2Client.prototype.portal_AADScopedRLAsgn_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADScopedRLAsgn_memberships_delete(uid, uidaccount, options), requestOptions);
    };
    V2Client.prototype.portal_AADScopedRLElgb_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADScopedRLElgb_memberships_get(uid, options), requestOptions);
    };
    /** Deletes an account membership. */
    V2Client.prototype.portal_AADScopedRLElgb_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADScopedRLElgb_memberships_delete(uid, uidaccount, options), requestOptions);
    };
    V2Client.prototype.portal_AADSubSku_memberships_get = function (/** Unique identifier */ uid, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADSubSku_memberships_get(uid, options), requestOptions);
    };
    /** Deletes an account membership. */
    V2Client.prototype.portal_AADSubSku_memberships_delete = function (/** Unique identifier */ uid, /** UID of the account to be removed */ uidaccount, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_AADSubSku_memberships_delete(uid, uidaccount, options), requestOptions);
    };
    V2Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_get(UID_ITShopOrg, options), requestOptions);
    };
    V2Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** Disabled Azure Active Directory service plan */ UID_AADDeniedServicePlan, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_delete(UID_ITShopOrg, UID_AADDeniedServicePlan, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    V2Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDeniedServicePlan/UID_AADDeniedServicePlan/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDeniedServicePlan_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADDirectoryRole. */
    V2Client.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADDirectoryRole/UID_AADDirectoryRole/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADDirectoryRole_UID_AADDirectoryRole_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADGroup. */
    V2Client.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADGroup/UID_AADGroup/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADGroup_UID_AADGroup_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
    V2Client.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/AADSubSku/UID_AADSubSku/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_AADSubSku_UID_AADSubSku_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaddirectoryrole_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaddirectoryrole_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaddirectoryrole_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaddirectoryrole_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaddirectoryrole_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaddirectoryrole_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aaddirectoryrole endpoint. */
    V2Client.prototype.portal_targetsystem_aaddirectoryrole_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaddirectoryrole_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaddirectoryrole_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaddirectoryrole_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaddirectoryrole_interactive_byid_get = function (/** Primary key value UID_AADDirectoryRole */ UID_AADDirectoryRole, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaddirectoryrole_interactive_byid_get(UID_AADDirectoryRole, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_get = function (/** Unique identifier of the base object */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_get(UID_AADGroup, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_put = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_put(UID_AADGroup, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_post = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_post(UID_AADGroup, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_delete = function (/** Unique identifier of the base object */ UID_AADGroup, /** Disabled Azure Active Directory service plan */ UID_AADDeniedServicePlan, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_delete(UID_AADGroup, UID_AADDeniedServicePlan, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_bulk_put = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_bulk_put(UID_AADGroup, inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (/** Unique identifier of the base object */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADGroup, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (/** Unique identifier of the base object */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADGroup, options), requestOptions);
    };
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    V2Client.prototype.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADGroup, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_subsku_get = function (/** Unique identifier of the base object */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_get(UID_AADGroup, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_subsku_put = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_put(UID_AADGroup, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_subsku_post = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_post(UID_AADGroup, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_subsku_delete = function (/** Unique identifier of the base object */ UID_AADGroup, /** Azure Active Directory subscription */ UID_AADSubSku, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_delete(UID_AADGroup, UID_AADSubSku, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_subsku_bulk_put = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_bulk_put(UID_AADGroup, inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADSubSku. */
    V2Client.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get = function (/** Unique identifier of the base object */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_get(UID_AADGroup, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
    V2Client.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get = function (/** Unique identifier of the base object */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_datamodel_get(UID_AADGroup, options), requestOptions);
    };
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroup}/subsku/UID_AADSubSku/candidates endpoint. */
    V2Client.prototype.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post = function (/** Unique identifier of the base object */ UID_AADGroup, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_subsku_UID_AADSubSku_candidates_filtertree_post(UID_AADGroup, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_children_get = function (/** Unique identifier of the base object */ UID_AADGroupContainer, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_children_get(UID_AADGroupContainer, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_children_post = function (/** Unique identifier of the base object */ UID_AADGroupContainer, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_children_post(UID_AADGroupContainer, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_children_delete = function (/** Unique identifier of the base object */ UID_AADGroupContainer, /** Member group */ UID_AADGroupMember, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_children_delete(UID_AADGroupContainer, UID_AADGroupMember, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADGroupMember. */
    V2Client.prototype.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get = function (/** Unique identifier of the base object */ UID_AADGroupContainer, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_get(UID_AADGroupContainer, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates endpoint. */
    V2Client.prototype.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get = function (/** Unique identifier of the base object */ UID_AADGroupContainer, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_datamodel_get(UID_AADGroupContainer, options), requestOptions);
    };
    /** Returns filter tree information for the targetsystem/aadgroup/{UID_AADGroupContainer}/children/UID_AADGroupMember/candidates endpoint. */
    V2Client.prototype.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post = function (/** Unique identifier of the base object */ UID_AADGroupContainer, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_children_UID_AADGroupMember_candidates_filtertree_post(UID_AADGroupContainer, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadgroup endpoint. */
    V2Client.prototype.portal_targetsystem_aadgroup_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadgroup_interactive_byid_get = function (/** Primary key value UID_AADGroup */ UID_AADGroup, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadgroup_interactive_byid_get(UID_AADGroup, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadscopedrlasgn_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlasgn_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadscopedrlasgn_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlasgn_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadscopedrlasgn_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlasgn_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadscopedrlasgn endpoint. */
    V2Client.prototype.portal_targetsystem_aadscopedrlasgn_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlasgn_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadscopedrlasgn_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlasgn_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadscopedrlasgn_interactive_byid_get = function (/** Primary key value UID_AADScopedRLAsgn */ UID_AADScopedRLAsgn, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlasgn_interactive_byid_get(UID_AADScopedRLAsgn, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadscopedrlelgb_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlelgb_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadscopedrlelgb_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlelgb_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadscopedrlelgb_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlelgb_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadscopedrlelgb endpoint. */
    V2Client.prototype.portal_targetsystem_aadscopedrlelgb_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlelgb_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadscopedrlelgb_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlelgb_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadscopedrlelgb_interactive_byid_get = function (/** Primary key value UID_AADScopedRLElgb */ UID_AADScopedRLElgb, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadscopedrlelgb_interactive_byid_get(UID_AADScopedRLElgb, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadsubsku_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadsubsku_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadsubsku_licenceoverview_get = function (UID_AADSubSku, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_licenceoverview_get(UID_AADSubSku, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadsubsku_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aadsubsku endpoint. */
    V2Client.prototype.portal_targetsystem_aadsubsku_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadsubsku_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aadsubsku_interactive_byid_get = function (/** Primary key value UID_AADSubSku */ UID_AADSubSku, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aadsubsku_interactive_byid_get(UID_AADSubSku, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_get = function (/** Unique identifier of the base object */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_get(UID_AADUser, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_put = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_put(UID_AADUser, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_post = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_post(UID_AADUser, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_delete = function (/** Unique identifier of the base object */ UID_AADUser, /** Disabled Azure Active Directory service plan */ UID_AADDeniedServicePlan, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_delete(UID_AADUser, UID_AADDeniedServicePlan, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_bulk_put = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_bulk_put(UID_AADUser, inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_AADDeniedServicePlan. */
    V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get = function (/** Unique identifier of the base object */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_get(UID_AADUser, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get = function (/** Unique identifier of the base object */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_datamodel_get(UID_AADUser, options), requestOptions);
    };
    /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/deniedserviceplans/UID_AADDeniedServicePlan/candidates endpoint. */
    V2Client.prototype.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_deniedserviceplans_UID_AADDeniedServicePlan_candidates_filtertree_post(UID_AADUser, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_subsku_get = function (/** Unique identifier of the base object */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_get(UID_AADUser, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_subsku_put = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_put(UID_AADUser, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_subsku_post = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_post(UID_AADUser, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_subsku_delete = function (/** Unique identifier of the base object */ UID_AADUser, /** Subscription assignment */ UID_AADUserHasSubSku, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_delete(UID_AADUser, UID_AADUserHasSubSku, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_subsku_bulk_put = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_bulk_put(UID_AADUser, inputParameterName, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property ObjectKeyAADSubSku. */
    V2Client.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get = function (/** Unique identifier of the base object */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_get(UID_AADUser, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
    V2Client.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get = function (/** Unique identifier of the base object */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_datamodel_get(UID_AADUser, options), requestOptions);
    };
    /** Returns filter tree information for the targetsystem/aaduser/{UID_AADUser}/subsku/ObjectKeyAADSubSku/AADSubSku/candidates endpoint. */
    V2Client.prototype.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post = function (/** Unique identifier of the base object */ UID_AADUser, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_subsku_ObjectKeyAADSubSku_AADSubSku_candidates_filtertree_post(UID_AADUser, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the targetsystem/aaduser endpoint. */
    V2Client.prototype.portal_targetsystem_aaduser_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_targetsystem_aaduser_interactive_byid_get = function (/** Primary key value UID_AADUser */ UID_AADUser, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_targetsystem_aaduser_interactive_byid_get(UID_AADUser, options), requestOptions);
    };
    return V2Client;
}());

export { ApiClientMethodFactory, Client, PortalAaddirectoryroleMemberships, PortalAaddirectoryroleMembershipsInteractive, PortalAaddirectoryroleMembershipsWrapper, PortalAadgroupMemberships, PortalAadgroupMembershipsInteractive, PortalAadgroupMembershipsWrapper, PortalAadscopedrlasgnMemberships, PortalAadscopedrlasgnMembershipsInteractive, PortalAadscopedrlasgnMembershipsWrapper, PortalAadscopedrlelgbMemberships, PortalAadscopedrlelgbMembershipsInteractive, PortalAadscopedrlelgbMembershipsWrapper, PortalAadsubskuMemberships, PortalAadsubskuMembershipsInteractive, PortalAadsubskuMembershipsWrapper, PortalShopConfigEntitlementsAaddeniedserviceplan, PortalShopConfigEntitlementsAaddeniedserviceplanInteractive, PortalShopConfigEntitlementsAaddeniedserviceplanWrapper, PortalTargetsystemAaddirectoryrole, PortalTargetsystemAaddirectoryroleInteractive, PortalTargetsystemAaddirectoryroleInteractiveWrapper, PortalTargetsystemAaddirectoryroleWrapper, PortalTargetsystemAadgroup, PortalTargetsystemAadgroupChildren, PortalTargetsystemAadgroupChildrenInteractive, PortalTargetsystemAadgroupChildrenWrapper, PortalTargetsystemAadgroupDeniedserviceplans, PortalTargetsystemAadgroupDeniedserviceplansInteractive, PortalTargetsystemAadgroupDeniedserviceplansWrapper, PortalTargetsystemAadgroupInteractive, PortalTargetsystemAadgroupInteractiveWrapper, PortalTargetsystemAadgroupSubsku, PortalTargetsystemAadgroupSubskuInteractive, PortalTargetsystemAadgroupSubskuWrapper, PortalTargetsystemAadgroupWrapper, PortalTargetsystemAadscopedrlasgn, PortalTargetsystemAadscopedrlasgnInteractive, PortalTargetsystemAadscopedrlasgnInteractiveWrapper, PortalTargetsystemAadscopedrlasgnWrapper, PortalTargetsystemAadscopedrlelgb, PortalTargetsystemAadscopedrlelgbInteractive, PortalTargetsystemAadscopedrlelgbInteractiveWrapper, PortalTargetsystemAadscopedrlelgbWrapper, PortalTargetsystemAadsubsku, PortalTargetsystemAadsubskuInteractive, PortalTargetsystemAadsubskuInteractiveWrapper, PortalTargetsystemAadsubskuWrapper, PortalTargetsystemAaduser, PortalTargetsystemAaduserDeniedserviceplans, PortalTargetsystemAaduserDeniedserviceplansInteractive, PortalTargetsystemAaduserDeniedserviceplansWrapper, PortalTargetsystemAaduserInteractive, PortalTargetsystemAaduserInteractiveWrapper, PortalTargetsystemAaduserSubsku, PortalTargetsystemAaduserSubskuInteractive, PortalTargetsystemAaduserSubskuWrapper, PortalTargetsystemAaduserWrapper, TypedClient, V2ApiClientMethodFactory, V2Client };
