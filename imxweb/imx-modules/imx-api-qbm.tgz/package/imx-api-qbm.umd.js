(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('imx-qbm-dbts')) :
    typeof define === 'function' && define.amd ? define(['exports', 'imx-qbm-dbts'], factory) :
    (global = global || self, factory(global['imx-api'] = {}, global.imxQbmDbts));
}(this, (function (exports, imxQbmDbts) { 'use strict';

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    (function (AuthPropType) {
        AuthPropType[AuthPropType["Info"] = 0] = "Info";
        AuthPropType[AuthPropType["Edit"] = 1] = "Edit";
        AuthPropType[AuthPropType["Password"] = 2] = "Password";
        AuthPropType[AuthPropType["Hidden"] = 3] = "Hidden";
        AuthPropType[AuthPropType["Checkbox"] = 4] = "Checkbox";
        AuthPropType[AuthPropType["OAuth2Code"] = 5] = "OAuth2Code";
        AuthPropType[AuthPropType["NewPassword"] = 6] = "NewPassword";
    })(exports.AuthPropType || (exports.AuthPropType = {}));
    (function (AuthType) {
        AuthType[AuthType["Default"] = 0] = "Default";
        AuthType[AuthType["AllManualModules"] = 1] = "AllManualModules";
        AuthType[AuthType["FixedCredentials"] = 2] = "FixedCredentials";
    })(exports.AuthType || (exports.AuthType = {}));
    (function (ChangeType) {
        ChangeType[ChangeType["Insert"] = 0] = "Insert";
        ChangeType[ChangeType["Update"] = 1] = "Update";
        ChangeType[ChangeType["Delete"] = 2] = "Delete";
    })(exports.ChangeType || (exports.ChangeType = {}));
    (function (ConfigSettingType) {
        ConfigSettingType[ConfigSettingType["None"] = 0] = "None";
        ConfigSettingType[ConfigSettingType["Sql"] = 1] = "Sql";
        ConfigSettingType[ConfigSettingType["Int"] = 2] = "Int";
        ConfigSettingType[ConfigSettingType["PositiveInt"] = 3] = "PositiveInt";
        ConfigSettingType[ConfigSettingType["Double"] = 4] = "Double";
        ConfigSettingType[ConfigSettingType["RiskIndex"] = 5] = "RiskIndex";
        ConfigSettingType[ConfigSettingType["PositiveDouble"] = 6] = "PositiveDouble";
        ConfigSettingType[ConfigSettingType["LimitedValues"] = 7] = "LimitedValues";
    })(exports.ConfigSettingType || (exports.ConfigSettingType = {}));
    (function (ReactivateJobMode) {
        ReactivateJobMode[ReactivateJobMode["Reactivate"] = 0] = "Reactivate";
        ReactivateJobMode[ReactivateJobMode["ContinueSuccess"] = 1] = "ContinueSuccess";
        ReactivateJobMode[ReactivateJobMode["ContinueError"] = 2] = "ContinueError";
    })(exports.ReactivateJobMode || (exports.ReactivateJobMode = {}));
    (function (UpdaterState) {
        UpdaterState[UpdaterState["UpdatesAvailable"] = 0] = "UpdatesAvailable";
        UpdaterState[UpdaterState["NoUpdatesAvailable"] = 1] = "NoUpdatesAvailable";
        UpdaterState[UpdaterState["AlreadyRunning"] = 2] = "AlreadyRunning";
        UpdaterState[UpdaterState["Disabled"] = 3] = "Disabled";
    })(exports.UpdaterState || (exports.UpdaterState = {}));
    var TypedClient = /** @class */ (function () {
        function TypedClient(client, translationProvider) {
            this.ImxMultilanguageUicultures = new ImxMultilanguageUiculturesWrapper(client, translationProvider);
            this.ImxSysteminfoThirdparty = new ImxSysteminfoThirdpartyWrapper(client, translationProvider);
            this.OpsupportCandidatesDialogtimezone = new OpsupportCandidatesDialogtimezoneWrapper(client, translationProvider);
            this.OpsupportJobservers = new OpsupportJobserversWrapper(client, translationProvider);
            this.OpsupportJournal = new OpsupportJournalWrapper(client, translationProvider);
            this.OpsupportQueueDbqueue = new OpsupportQueueDbqueueWrapper(client, translationProvider);
            this.OpsupportQueueFrozenjobs = new OpsupportQueueFrozenjobsWrapper(client, translationProvider);
            this.OpsupportQueueFrozenjobsbyqueue = new OpsupportQueueFrozenjobsbyqueueWrapper(client, translationProvider);
            this.OpsupportQueueJobaffects = new OpsupportQueueJobaffectsWrapper(client, translationProvider);
            this.OpsupportQueueJobchains = new OpsupportQueueJobchainsWrapper(client, translationProvider);
            this.OpsupportQueueJobhistory = new OpsupportQueueJobhistoryWrapper(client, translationProvider);
            this.OpsupportQueueJobperformance = new OpsupportQueueJobperformanceWrapper(client, translationProvider);
            this.OpsupportQueueJobs = new OpsupportQueueJobsWrapper(client, translationProvider);
            this.OpsupportQueueOverview = new OpsupportQueueOverviewWrapper(client, translationProvider);
            this.OpsupportQueueTree = new OpsupportQueueTreeWrapper(client, translationProvider);
            this.OpsupportSearchIndexedtables = new OpsupportSearchIndexedtablesWrapper(client, translationProvider);
            this.OpsupportSystemoverview = new OpsupportSystemoverviewWrapper(client, translationProvider);
            this.OpsupportWebapplications = new OpsupportWebapplicationsWrapper(client, translationProvider);
        }
        return TypedClient;
    }());
    var ImxMultilanguageUicultures = /** @class */ (function (_super) {
        __extends(ImxMultilanguageUicultures, _super);
        function ImxMultilanguageUicultures() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.Ident_DialogCulture = _this.GetEntityValue('Ident_DialogCulture');
            _this.NativeName = _this.GetEntityValue('NativeName');
            _this.Iso2Name = _this.GetEntityValue('Iso2Name');
            _this.Iso3Name = _this.GetEntityValue('Iso3Name');
            _this.DisplayName = _this.GetEntityValue('DisplayName');
            _this.IsForFrontend = _this.GetEntityValue('IsForFrontend');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        ImxMultilanguageUicultures.GetEntitySchema = function () {
            var columns = {
                'Ident_DialogCulture': {
                    ColumnName: 'Ident_DialogCulture',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'NativeName': {
                    ColumnName: 'NativeName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Iso2Name': {
                    ColumnName: 'Iso2Name',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Iso3Name': {
                    ColumnName: 'Iso3Name',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DisplayName': {
                    ColumnName: 'DisplayName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsForFrontend': {
                    ColumnName: 'IsForFrontend',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QBMCulture', Columns: columns };
        };
        return ImxMultilanguageUicultures;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the ImxMultilanguageUicultures type. */
    var ImxMultilanguageUiculturesInteractive = /** @class */ (function (_super) {
        __extends(ImxMultilanguageUiculturesInteractive, _super);
        function ImxMultilanguageUiculturesInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return ImxMultilanguageUiculturesInteractive;
    }(ImxMultilanguageUicultures));
    var ImxSysteminfoThirdparty = /** @class */ (function (_super) {
        __extends(ImxSysteminfoThirdparty, _super);
        function ImxSysteminfoThirdparty() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.ComponentName = _this.GetEntityValue('ComponentName');
            _this.CopyRight = _this.GetEntityValue('CopyRight');
            _this.EmailOrURl = _this.GetEntityValue('EmailOrURl');
            _this.LicenceName = _this.GetEntityValue('LicenceName');
            _this.LicenceText = _this.GetEntityValue('LicenceText');
            _this.UID_QBMV3rdPartyLicence = _this.GetEntityValue('UID_QBMV3rdPartyLicence');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        ImxSysteminfoThirdparty.GetEntitySchema = function () {
            var columns = {
                'ComponentName': {
                    ColumnName: 'ComponentName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'CopyRight': {
                    ColumnName: 'CopyRight',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'EmailOrURl': {
                    ColumnName: 'EmailOrURl',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'LicenceName': {
                    ColumnName: 'LicenceName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'LicenceText': {
                    ColumnName: 'LicenceText',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'UID_QBMV3rdPartyLicence': {
                    ColumnName: 'UID_QBMV3rdPartyLicence',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QBMV3rdPartyLicence', Columns: columns };
        };
        return ImxSysteminfoThirdparty;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the ImxSysteminfoThirdparty type. */
    var ImxSysteminfoThirdpartyInteractive = /** @class */ (function (_super) {
        __extends(ImxSysteminfoThirdpartyInteractive, _super);
        function ImxSysteminfoThirdpartyInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return ImxSysteminfoThirdpartyInteractive;
    }(ImxSysteminfoThirdparty));
    var OpsupportCandidatesDialogtimezone = /** @class */ (function (_super) {
        __extends(OpsupportCandidatesDialogtimezone, _super);
        function OpsupportCandidatesDialogtimezone() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_DialogTimeZone = _this.GetEntityValue('UID_DialogTimeZone');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportCandidatesDialogtimezone.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_DialogTimeZone': {
                    ColumnName: 'UID_DialogTimeZone',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DialogTimeZone', Columns: columns };
        };
        return OpsupportCandidatesDialogtimezone;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportCandidatesDialogtimezone type. */
    var OpsupportCandidatesDialogtimezoneInteractive = /** @class */ (function (_super) {
        __extends(OpsupportCandidatesDialogtimezoneInteractive, _super);
        function OpsupportCandidatesDialogtimezoneInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportCandidatesDialogtimezoneInteractive;
    }(OpsupportCandidatesDialogtimezone));
    var OpsupportJobservers = /** @class */ (function (_super) {
        __extends(OpsupportJobservers, _super);
        function OpsupportJobservers() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.Ident_Server = _this.GetEntityValue('Ident_Server');
            _this.IsInSoftwareUpdate = _this.GetEntityValue('IsInSoftwareUpdate');
            _this.IsJobServiceDisabled = _this.GetEntityValue('IsJobServiceDisabled');
            _this.IsNoAutoupdate = _this.GetEntityValue('IsNoAutoupdate');
            _this.IsJobServiceSuspended = _this.GetEntityValue('IsJobServiceSuspended');
            _this.SuspendReason = _this.GetEntityValue('SuspendReason');
            _this.QueueName = _this.GetEntityValue('QueueName');
            _this.IPV6 = _this.GetEntityValue('IPV6');
            _this.IPV4 = _this.GetEntityValue('IPV4');
            _this.FQDN = _this.GetEntityValue('FQDN');
            _this.PhysicalServerName = _this.GetEntityValue('PhysicalServerName');
            _this.LastJobFetchTime = _this.GetEntityValue('LastJobFetchTime');
            _this.ServerTags = _this.GetEntityValue('ServerTags');
            _this.ServerWebUrl = _this.GetEntityValue('ServerWebUrl');
            _this.Connection = _this.GetEntityValue('Connection');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportJobservers.GetEntitySchema = function () {
            var columns = {
                'Ident_Server': {
                    ColumnName: 'Ident_Server',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsInSoftwareUpdate': {
                    ColumnName: 'IsInSoftwareUpdate',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsJobServiceDisabled': {
                    ColumnName: 'IsJobServiceDisabled',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsNoAutoupdate': {
                    ColumnName: 'IsNoAutoupdate',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsJobServiceSuspended': {
                    ColumnName: 'IsJobServiceSuspended',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'SuspendReason': {
                    ColumnName: 'SuspendReason',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'QueueName': {
                    ColumnName: 'QueueName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IPV6': {
                    ColumnName: 'IPV6',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IPV4': {
                    ColumnName: 'IPV4',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'FQDN': {
                    ColumnName: 'FQDN',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'PhysicalServerName': {
                    ColumnName: 'PhysicalServerName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'LastJobFetchTime': {
                    ColumnName: 'LastJobFetchTime',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'ServerTags': {
                    ColumnName: 'ServerTags',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ServerWebUrl': {
                    ColumnName: 'ServerWebUrl',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Connection': {
                    ColumnName: 'Connection',
                    Type: imxQbmDbts.ValType.Long,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QBMServer', Columns: columns };
        };
        return OpsupportJobservers;
    }(imxQbmDbts.ReadExtTypedEntity));
    /** @deprecated Use the OpsupportJobservers type. */
    var OpsupportJobserversInteractive = /** @class */ (function (_super) {
        __extends(OpsupportJobserversInteractive, _super);
        function OpsupportJobserversInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportJobserversInteractive;
    }(OpsupportJobservers));
    var OpsupportJournal = /** @class */ (function (_super) {
        __extends(OpsupportJournal, _super);
        function OpsupportJournal() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.MessageString = _this.GetEntityValue('MessageString');
            _this.MessageType = _this.GetEntityValue('MessageType');
            _this.MessageDate = _this.GetEntityValue('MessageDate');
            _this.ApplicationName = _this.GetEntityValue('ApplicationName');
            _this.LogonUser = _this.GetEntityValue('LogonUser');
            _this.HostName = _this.GetEntityValue('HostName');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportJournal.GetEntitySchema = function () {
            var columns = {
                'MessageString': {
                    ColumnName: 'MessageString',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'MessageType': {
                    ColumnName: 'MessageType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'MessageDate': {
                    ColumnName: 'MessageDate',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'ApplicationName': {
                    ColumnName: 'ApplicationName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'LogonUser': {
                    ColumnName: 'LogonUser',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'HostName': {
                    ColumnName: 'HostName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DialogJournal', Columns: columns };
        };
        return OpsupportJournal;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportJournal type. */
    var OpsupportJournalInteractive = /** @class */ (function (_super) {
        __extends(OpsupportJournalInteractive, _super);
        function OpsupportJournalInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportJournalInteractive;
    }(OpsupportJournal));
    var OpsupportQueueDbqueue = /** @class */ (function (_super) {
        __extends(OpsupportQueueDbqueue, _super);
        function OpsupportQueueDbqueue() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Task = _this.GetEntityValue('UID_Task');
            _this.CountProcessing = _this.GetEntityValue('CountProcessing');
            _this.CountWaiting = _this.GetEntityValue('CountWaiting');
            _this.SortOrder = _this.GetEntityValue('SortOrder');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportQueueDbqueue.GetEntitySchema = function () {
            var columns = {
                'UID_Task': {
                    ColumnName: 'UID_Task',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'CountProcessing': {
                    ColumnName: 'CountProcessing',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountWaiting': {
                    ColumnName: 'CountWaiting',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'SortOrder': {
                    ColumnName: 'SortOrder',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return OpsupportQueueDbqueue;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportQueueDbqueue type. */
    var OpsupportQueueDbqueueInteractive = /** @class */ (function (_super) {
        __extends(OpsupportQueueDbqueueInteractive, _super);
        function OpsupportQueueDbqueueInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportQueueDbqueueInteractive;
    }(OpsupportQueueDbqueue));
    var OpsupportQueueFrozenjobs = /** @class */ (function (_super) {
        __extends(OpsupportQueueFrozenjobs, _super);
        function OpsupportQueueFrozenjobs() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.BasisObjectKey = _this.GetEntityValue('BasisObjectKey');
            _this.ComponentAssembly = _this.GetEntityValue('ComponentAssembly');
            _this.ComponentClass = _this.GetEntityValue('ComponentClass');
            _this.DeferOnError = _this.GetEntityValue('DeferOnError');
            _this.ErrorMessages = _this.GetEntityValue('ErrorMessages');
            _this.ErrorNotify = _this.GetEntityValue('ErrorNotify');
            _this.ExecutionType = _this.GetEntityValue('ExecutionType');
            _this.GenProcID = _this.GetEntityValue('GenProcID');
            _this.IgnoreErrors = _this.GetEntityValue('IgnoreErrors');
            _this.IsForHistory = _this.GetEntityValue('IsForHistory');
            _this.IsNoDBQueueDefer = _this.GetEntityValue('IsNoDBQueueDefer');
            _this.IsRootJob = _this.GetEntityValue('IsRootJob');
            _this.IsSplitOnly = _this.GetEntityValue('IsSplitOnly');
            _this.IsToFreezeOnError = _this.GetEntityValue('IsToFreezeOnError');
            _this.JobChainName = _this.GetEntityValue('JobChainName');
            _this.LimitationCount = _this.GetEntityValue('LimitationCount');
            _this.LimitationWarning = _this.GetEntityValue('LimitationWarning');
            _this.LogMode = _this.GetEntityValue('LogMode');
            _this.MaxInstance = _this.GetEntityValue('MaxInstance');
            _this.MinutesToDefer = _this.GetEntityValue('MinutesToDefer');
            _this.NotifyAddress = _this.GetEntityValue('NotifyAddress');
            _this.NotifyAddressSuccess = _this.GetEntityValue('NotifyAddressSuccess');
            _this.NotifyBody = _this.GetEntityValue('NotifyBody');
            _this.NotifyBodySuccess = _this.GetEntityValue('NotifyBodySuccess');
            _this.NotifySender = _this.GetEntityValue('NotifySender');
            _this.NotifySenderSuccess = _this.GetEntityValue('NotifySenderSuccess');
            _this.NotifySubject = _this.GetEntityValue('NotifySubject');
            _this.NotifySubjectSuccess = _this.GetEntityValue('NotifySubjectSuccess');
            _this.ParamIN = _this.GetEntityValue('ParamIN');
            _this.Priority = _this.GetEntityValue('Priority');
            _this.ProcessTracking = _this.GetEntityValue('ProcessTracking');
            _this.Queue = _this.GetEntityValue('Queue');
            _this.Ready2EXE = _this.GetEntityValue('Ready2EXE');
            _this.Retries = _this.GetEntityValue('Retries');
            _this.StartAt = _this.GetEntityValue('StartAt');
            _this.SuccessNotify = _this.GetEntityValue('SuccessNotify');
            _this.TaskName = _this.GetEntityValue('TaskName');
            _this.UID_Job = _this.GetEntityValue('UID_Job');
            _this.UID_JobError = _this.GetEntityValue('UID_JobError');
            _this.UID_JobOrigin = _this.GetEntityValue('UID_JobOrigin');
            _this.UID_JobSameServer = _this.GetEntityValue('UID_JobSameServer');
            _this.UID_JobSuccess = _this.GetEntityValue('UID_JobSuccess');
            _this.UID_Tree = _this.GetEntityValue('UID_Tree');
            _this.WasError = _this.GetEntityValue('WasError');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.XDateUpdated = _this.GetEntityValue('XDateUpdated');
            _this.XTouched = _this.GetEntityValue('XTouched');
            _this.XUserInserted = _this.GetEntityValue('XUserInserted');
            _this.XUserUpdated = _this.GetEntityValue('XUserUpdated');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportQueueFrozenjobs.GetEntitySchema = function () {
            var columns = {
                'BasisObjectKey': {
                    ColumnName: 'BasisObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ComponentAssembly': {
                    ColumnName: 'ComponentAssembly',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ComponentClass': {
                    ColumnName: 'ComponentClass',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DeferOnError': {
                    ColumnName: 'DeferOnError',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'ErrorMessages': {
                    ColumnName: 'ErrorMessages',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'ErrorNotify': {
                    ColumnName: 'ErrorNotify',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'ExecutionType': {
                    ColumnName: 'ExecutionType',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'GenProcID': {
                    ColumnName: 'GenProcID',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IgnoreErrors': {
                    ColumnName: 'IgnoreErrors',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsForHistory': {
                    ColumnName: 'IsForHistory',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsNoDBQueueDefer': {
                    ColumnName: 'IsNoDBQueueDefer',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsRootJob': {
                    ColumnName: 'IsRootJob',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsSplitOnly': {
                    ColumnName: 'IsSplitOnly',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsToFreezeOnError': {
                    ColumnName: 'IsToFreezeOnError',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'JobChainName': {
                    ColumnName: 'JobChainName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'LimitationCount': {
                    ColumnName: 'LimitationCount',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'LimitationWarning': {
                    ColumnName: 'LimitationWarning',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'LogMode': {
                    ColumnName: 'LogMode',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'MaxInstance': {
                    ColumnName: 'MaxInstance',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'MinutesToDefer': {
                    ColumnName: 'MinutesToDefer',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'NotifyAddress': {
                    ColumnName: 'NotifyAddress',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'NotifyAddressSuccess': {
                    ColumnName: 'NotifyAddressSuccess',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'NotifyBody': {
                    ColumnName: 'NotifyBody',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'NotifyBodySuccess': {
                    ColumnName: 'NotifyBodySuccess',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'NotifySender': {
                    ColumnName: 'NotifySender',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'NotifySenderSuccess': {
                    ColumnName: 'NotifySenderSuccess',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'NotifySubject': {
                    ColumnName: 'NotifySubject',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'NotifySubjectSuccess': {
                    ColumnName: 'NotifySubjectSuccess',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'ParamIN': {
                    ColumnName: 'ParamIN',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'Priority': {
                    ColumnName: 'Priority',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'ProcessTracking': {
                    ColumnName: 'ProcessTracking',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Queue': {
                    ColumnName: 'Queue',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Ready2EXE': {
                    ColumnName: 'Ready2EXE',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Retries': {
                    ColumnName: 'Retries',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'StartAt': {
                    ColumnName: 'StartAt',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'SuccessNotify': {
                    ColumnName: 'SuccessNotify',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'TaskName': {
                    ColumnName: 'TaskName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Job': {
                    ColumnName: 'UID_Job',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_JobError': {
                    ColumnName: 'UID_JobError',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_JobOrigin': {
                    ColumnName: 'UID_JobOrigin',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_JobSameServer': {
                    ColumnName: 'UID_JobSameServer',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_JobSuccess': {
                    ColumnName: 'UID_JobSuccess',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Tree': {
                    ColumnName: 'UID_Tree',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'WasError': {
                    ColumnName: 'WasError',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XDateUpdated': {
                    ColumnName: 'XDateUpdated',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XTouched': {
                    ColumnName: 'XTouched',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XUserInserted': {
                    ColumnName: 'XUserInserted',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XUserUpdated': {
                    ColumnName: 'XUserUpdated',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'JobQueue', Columns: columns };
        };
        return OpsupportQueueFrozenjobs;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportQueueFrozenjobs type. */
    var OpsupportQueueFrozenjobsInteractive = /** @class */ (function (_super) {
        __extends(OpsupportQueueFrozenjobsInteractive, _super);
        function OpsupportQueueFrozenjobsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportQueueFrozenjobsInteractive;
    }(OpsupportQueueFrozenjobs));
    var OpsupportQueueFrozenjobsbyqueue = /** @class */ (function (_super) {
        __extends(OpsupportQueueFrozenjobsbyqueue, _super);
        function OpsupportQueueFrozenjobsbyqueue() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.QueueName = _this.GetEntityValue('QueueName');
            _this.Count = _this.GetEntityValue('Count');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportQueueFrozenjobsbyqueue.GetEntitySchema = function () {
            var columns = {
                'QueueName': {
                    ColumnName: 'QueueName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Count': {
                    ColumnName: 'Count',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return OpsupportQueueFrozenjobsbyqueue;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportQueueFrozenjobsbyqueue type. */
    var OpsupportQueueFrozenjobsbyqueueInteractive = /** @class */ (function (_super) {
        __extends(OpsupportQueueFrozenjobsbyqueueInteractive, _super);
        function OpsupportQueueFrozenjobsbyqueueInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportQueueFrozenjobsbyqueueInteractive;
    }(OpsupportQueueFrozenjobsbyqueue));
    var OpsupportQueueJobaffects = /** @class */ (function (_super) {
        __extends(OpsupportQueueJobaffects, _super);
        function OpsupportQueueJobaffects() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Job = _this.GetEntityValue('UID_Job');
            _this.ObjectKeyAffected = _this.GetEntityValue('ObjectKeyAffected');
            _this.ObjectTypeDisplay = _this.GetEntityValue('ObjectTypeDisplay');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportQueueJobaffects.GetEntitySchema = function () {
            var columns = {
                'UID_Job': {
                    ColumnName: 'UID_Job',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectKeyAffected': {
                    ColumnName: 'ObjectKeyAffected',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ObjectTypeDisplay': {
                    ColumnName: 'ObjectTypeDisplay',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QBMElementAffectedByJob', Columns: columns };
        };
        return OpsupportQueueJobaffects;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportQueueJobaffects type. */
    var OpsupportQueueJobaffectsInteractive = /** @class */ (function (_super) {
        __extends(OpsupportQueueJobaffectsInteractive, _super);
        function OpsupportQueueJobaffectsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportQueueJobaffectsInteractive;
    }(OpsupportQueueJobaffects));
    var OpsupportQueueJobchains = /** @class */ (function (_super) {
        __extends(OpsupportQueueJobchains, _super);
        function OpsupportQueueJobchains() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.JobChainName = _this.GetEntityValue('JobChainName');
            _this.Count = _this.GetEntityValue('Count');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportQueueJobchains.GetEntitySchema = function () {
            var columns = {
                'JobChainName': {
                    ColumnName: 'JobChainName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Count': {
                    ColumnName: 'Count',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return OpsupportQueueJobchains;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportQueueJobchains type. */
    var OpsupportQueueJobchainsInteractive = /** @class */ (function (_super) {
        __extends(OpsupportQueueJobchainsInteractive, _super);
        function OpsupportQueueJobchainsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportQueueJobchainsInteractive;
    }(OpsupportQueueJobchains));
    var OpsupportQueueJobhistory = /** @class */ (function (_super) {
        __extends(OpsupportQueueJobhistory, _super);
        function OpsupportQueueJobhistory() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.JobChainName = _this.GetEntityValue('JobChainName');
            _this.UID_JobOrigin = _this.GetEntityValue('UID_JobOrigin');
            _this.TaskName = _this.GetEntityValue('TaskName');
            _this.WasError = _this.GetEntityValue('WasError');
            _this.UID_Tree = _this.GetEntityValue('UID_Tree');
            _this.UID_Job = _this.GetEntityValue('UID_Job');
            _this.Queue = _this.GetEntityValue('Queue');
            _this.ErrorMessages = _this.GetEntityValue('ErrorMessages');
            _this.IsRootJob = _this.GetEntityValue('IsRootJob');
            _this.UID_JobSuccess = _this.GetEntityValue('UID_JobSuccess');
            _this.UID_JobError = _this.GetEntityValue('UID_JobError');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.GenProcID = _this.GetEntityValue('GenProcID');
            _this.JobChainDescription = _this.GetEntityValue('JobChainDescription');
            _this.JobName = _this.GetEntityValue('JobName');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportQueueJobhistory.GetEntitySchema = function () {
            var columns = {
                'JobChainName': {
                    ColumnName: 'JobChainName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_JobOrigin': {
                    ColumnName: 'UID_JobOrigin',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'TaskName': {
                    ColumnName: 'TaskName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'WasError': {
                    ColumnName: 'WasError',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'UID_Tree': {
                    ColumnName: 'UID_Tree',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Job': {
                    ColumnName: 'UID_Job',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Queue': {
                    ColumnName: 'Queue',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ErrorMessages': {
                    ColumnName: 'ErrorMessages',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'IsRootJob': {
                    ColumnName: 'IsRootJob',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'UID_JobSuccess': {
                    ColumnName: 'UID_JobSuccess',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_JobError': {
                    ColumnName: 'UID_JobError',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'GenProcID': {
                    ColumnName: 'GenProcID',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'JobChainDescription': {
                    ColumnName: 'JobChainDescription',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'JobName': {
                    ColumnName: 'JobName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'JobHistory', Columns: columns };
        };
        return OpsupportQueueJobhistory;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportQueueJobhistory type. */
    var OpsupportQueueJobhistoryInteractive = /** @class */ (function (_super) {
        __extends(OpsupportQueueJobhistoryInteractive, _super);
        function OpsupportQueueJobhistoryInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportQueueJobhistoryInteractive;
    }(OpsupportQueueJobhistory));
    var OpsupportQueueJobperformance = /** @class */ (function (_super) {
        __extends(OpsupportQueueJobperformance, _super);
        function OpsupportQueueJobperformance() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.Queue = _this.GetEntityValue('Queue');
            _this.ComponentClass = _this.GetEntityValue('ComponentClass');
            _this.TaskName = _this.GetEntityValue('TaskName');
            _this.CountPerMinute = _this.GetEntityValue('CountPerMinute');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportQueueJobperformance.GetEntitySchema = function () {
            var columns = {
                'Queue': {
                    ColumnName: 'Queue',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ComponentClass': {
                    ColumnName: 'ComponentClass',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'TaskName': {
                    ColumnName: 'TaskName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'CountPerMinute': {
                    ColumnName: 'CountPerMinute',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'JobPerformance', Columns: columns };
        };
        return OpsupportQueueJobperformance;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportQueueJobperformance type. */
    var OpsupportQueueJobperformanceInteractive = /** @class */ (function (_super) {
        __extends(OpsupportQueueJobperformanceInteractive, _super);
        function OpsupportQueueJobperformanceInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportQueueJobperformanceInteractive;
    }(OpsupportQueueJobperformance));
    var OpsupportQueueJobs = /** @class */ (function (_super) {
        __extends(OpsupportQueueJobs, _super);
        function OpsupportQueueJobs() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.JobChainName = _this.GetEntityValue('JobChainName');
            _this.UID_JobOrigin = _this.GetEntityValue('UID_JobOrigin');
            _this.Ready2EXE = _this.GetEntityValue('Ready2EXE');
            _this.TaskName = _this.GetEntityValue('TaskName');
            _this.UID_Tree = _this.GetEntityValue('UID_Tree');
            _this.UID_Job = _this.GetEntityValue('UID_Job');
            _this.Queue = _this.GetEntityValue('Queue');
            _this.Retries = _this.GetEntityValue('Retries');
            _this.IsRootJob = _this.GetEntityValue('IsRootJob');
            _this.UID_JobSuccess = _this.GetEntityValue('UID_JobSuccess');
            _this.UID_JobError = _this.GetEntityValue('UID_JobError');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.GenProcID = _this.GetEntityValue('GenProcID');
            _this.JobChainDescription = _this.GetEntityValue('JobChainDescription');
            _this.JobName = _this.GetEntityValue('JobName');
            _this.CombinedStatus = _this.GetEntityValue('CombinedStatus');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportQueueJobs.GetEntitySchema = function () {
            var columns = {
                'JobChainName': {
                    ColumnName: 'JobChainName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_JobOrigin': {
                    ColumnName: 'UID_JobOrigin',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Ready2EXE': {
                    ColumnName: 'Ready2EXE',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'TaskName': {
                    ColumnName: 'TaskName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Tree': {
                    ColumnName: 'UID_Tree',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Job': {
                    ColumnName: 'UID_Job',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Queue': {
                    ColumnName: 'Queue',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Retries': {
                    ColumnName: 'Retries',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsRootJob': {
                    ColumnName: 'IsRootJob',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'UID_JobSuccess': {
                    ColumnName: 'UID_JobSuccess',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_JobError': {
                    ColumnName: 'UID_JobError',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'GenProcID': {
                    ColumnName: 'GenProcID',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'JobChainDescription': {
                    ColumnName: 'JobChainDescription',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'JobName': {
                    ColumnName: 'JobName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'CombinedStatus': {
                    ColumnName: 'CombinedStatus',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'JobQueue', Columns: columns };
        };
        return OpsupportQueueJobs;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportQueueJobs type. */
    var OpsupportQueueJobsInteractive = /** @class */ (function (_super) {
        __extends(OpsupportQueueJobsInteractive, _super);
        function OpsupportQueueJobsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportQueueJobsInteractive;
    }(OpsupportQueueJobs));
    var OpsupportQueueOverview = /** @class */ (function (_super) {
        __extends(OpsupportQueueOverview, _super);
        function OpsupportQueueOverview() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.CountDelete = _this.GetEntityValue('CountDelete');
            _this.CountFalse = _this.GetEntityValue('CountFalse');
            _this.CountFinished = _this.GetEntityValue('CountFinished');
            _this.CountFrozen = _this.GetEntityValue('CountFrozen');
            _this.CountHistory = _this.GetEntityValue('CountHistory');
            _this.CountLoaded = _this.GetEntityValue('CountLoaded');
            _this.CountMissing = _this.GetEntityValue('CountMissing');
            _this.CountOverlimt = _this.GetEntityValue('CountOverlimt');
            _this.CountProcessing = _this.GetEntityValue('CountProcessing');
            _this.CountTrue = _this.GetEntityValue('CountTrue');
            _this.IsInitQueueRunning = _this.GetEntityValue('IsInitQueueRunning');
            _this.IsInvalid = _this.GetEntityValue('IsInvalid');
            _this.QueueName = _this.GetEntityValue('QueueName');
            _this.UID_QBMJobqueueOverview = _this.GetEntityValue('UID_QBMJobqueueOverview');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportQueueOverview.GetEntitySchema = function () {
            var columns = {
                'CountDelete': {
                    ColumnName: 'CountDelete',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountFalse': {
                    ColumnName: 'CountFalse',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountFinished': {
                    ColumnName: 'CountFinished',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountFrozen': {
                    ColumnName: 'CountFrozen',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountHistory': {
                    ColumnName: 'CountHistory',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountLoaded': {
                    ColumnName: 'CountLoaded',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountMissing': {
                    ColumnName: 'CountMissing',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountOverlimt': {
                    ColumnName: 'CountOverlimt',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountProcessing': {
                    ColumnName: 'CountProcessing',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountTrue': {
                    ColumnName: 'CountTrue',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'IsInitQueueRunning': {
                    ColumnName: 'IsInitQueueRunning',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsInvalid': {
                    ColumnName: 'IsInvalid',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'QueueName': {
                    ColumnName: 'QueueName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_QBMJobqueueOverview': {
                    ColumnName: 'UID_QBMJobqueueOverview',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QBMJobqueueOverview', Columns: columns };
        };
        return OpsupportQueueOverview;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportQueueOverview type. */
    var OpsupportQueueOverviewInteractive = /** @class */ (function (_super) {
        __extends(OpsupportQueueOverviewInteractive, _super);
        function OpsupportQueueOverviewInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportQueueOverviewInteractive;
    }(OpsupportQueueOverview));
    var OpsupportQueueTree = /** @class */ (function (_super) {
        __extends(OpsupportQueueTree, _super);
        function OpsupportQueueTree() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Job = _this.GetEntityValue('UID_Job');
            _this.BasisObjectKey = _this.GetEntityValue('BasisObjectKey');
            _this.DeferOnError = _this.GetEntityValue('DeferOnError');
            _this.ErrorMessages = _this.GetEntityValue('ErrorMessages');
            _this.GenProcID = _this.GetEntityValue('GenProcID');
            _this.IsRootJob = _this.GetEntityValue('IsRootJob');
            _this.JobChainName = _this.GetEntityValue('JobChainName');
            _this.LimitationCount = _this.GetEntityValue('LimitationCount');
            _this.Retries = _this.GetEntityValue('Retries');
            _this.Queue = _this.GetEntityValue('Queue');
            _this.Ready2EXE = _this.GetEntityValue('Ready2EXE');
            _this.TaskName = _this.GetEntityValue('TaskName');
            _this.UID_JobError = _this.GetEntityValue('UID_JobError');
            _this.UID_JobOrigin = _this.GetEntityValue('UID_JobOrigin');
            _this.UID_JobSameServer = _this.GetEntityValue('UID_JobSameServer');
            _this.UID_JobSuccess = _this.GetEntityValue('UID_JobSuccess');
            _this.UID_Tree = _this.GetEntityValue('UID_Tree');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.XDateUpdated = _this.GetEntityValue('XDateUpdated');
            _this.XUserInserted = _this.GetEntityValue('XUserInserted');
            _this.XUserUpdated = _this.GetEntityValue('XUserUpdated');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportQueueTree.GetEntitySchema = function () {
            var columns = {
                'UID_Job': {
                    ColumnName: 'UID_Job',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'BasisObjectKey': {
                    ColumnName: 'BasisObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DeferOnError': {
                    ColumnName: 'DeferOnError',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'ErrorMessages': {
                    ColumnName: 'ErrorMessages',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
                'GenProcID': {
                    ColumnName: 'GenProcID',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsRootJob': {
                    ColumnName: 'IsRootJob',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'JobChainName': {
                    ColumnName: 'JobChainName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'LimitationCount': {
                    ColumnName: 'LimitationCount',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'Retries': {
                    ColumnName: 'Retries',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'Queue': {
                    ColumnName: 'Queue',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Ready2EXE': {
                    ColumnName: 'Ready2EXE',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'TaskName': {
                    ColumnName: 'TaskName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_JobError': {
                    ColumnName: 'UID_JobError',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_JobOrigin': {
                    ColumnName: 'UID_JobOrigin',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_JobSameServer': {
                    ColumnName: 'UID_JobSameServer',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_JobSuccess': {
                    ColumnName: 'UID_JobSuccess',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Tree': {
                    ColumnName: 'UID_Tree',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XDateUpdated': {
                    ColumnName: 'XDateUpdated',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'XUserInserted': {
                    ColumnName: 'XUserInserted',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XUserUpdated': {
                    ColumnName: 'XUserUpdated',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: '', Columns: columns };
        };
        return OpsupportQueueTree;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportQueueTree type. */
    var OpsupportQueueTreeInteractive = /** @class */ (function (_super) {
        __extends(OpsupportQueueTreeInteractive, _super);
        function OpsupportQueueTreeInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportQueueTreeInteractive;
    }(OpsupportQueueTree));
    var OpsupportSearchIndexedtables = /** @class */ (function (_super) {
        __extends(OpsupportSearchIndexedtables, _super);
        function OpsupportSearchIndexedtables() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.TableName = _this.GetEntityValue('TableName');
            _this.DisplayName = _this.GetEntityValue('DisplayName');
            _this.DisplayNameSingular = _this.GetEntityValue('DisplayNameSingular');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportSearchIndexedtables.GetEntitySchema = function () {
            var columns = {
                'TableName': {
                    ColumnName: 'TableName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DisplayName': {
                    ColumnName: 'DisplayName',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'DisplayNameSingular': {
                    ColumnName: 'DisplayNameSingular',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'DialogTable', Columns: columns };
        };
        return OpsupportSearchIndexedtables;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportSearchIndexedtables type. */
    var OpsupportSearchIndexedtablesInteractive = /** @class */ (function (_super) {
        __extends(OpsupportSearchIndexedtablesInteractive, _super);
        function OpsupportSearchIndexedtablesInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportSearchIndexedtablesInteractive;
    }(OpsupportSearchIndexedtables));
    var OpsupportSystemoverview = /** @class */ (function (_super) {
        __extends(OpsupportSystemoverview, _super);
        function OpsupportSystemoverview() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.Category = _this.GetEntityValue('Category');
            _this.Element = _this.GetEntityValue('Element');
            _this.QualityOfValue = _this.GetEntityValue('QualityOfValue');
            _this.RecommendedValue = _this.GetEntityValue('RecommendedValue');
            _this.SortOrder = _this.GetEntityValue('SortOrder');
            _this.SubElement = _this.GetEntityValue('SubElement');
            _this.UID_QBMVSystemOverview = _this.GetEntityValue('UID_QBMVSystemOverview');
            _this.Value = _this.GetEntityValue('Value');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportSystemoverview.GetEntitySchema = function () {
            var columns = {
                'Category': {
                    ColumnName: 'Category',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Element': {
                    ColumnName: 'Element',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'QualityOfValue': {
                    ColumnName: 'QualityOfValue',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'RecommendedValue': {
                    ColumnName: 'RecommendedValue',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'SortOrder': {
                    ColumnName: 'SortOrder',
                    Type: imxQbmDbts.ValType.Long,
                    IsReadOnly: true,
                },
                'SubElement': {
                    ColumnName: 'SubElement',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_QBMVSystemOverview': {
                    ColumnName: 'UID_QBMVSystemOverview',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Value': {
                    ColumnName: 'Value',
                    Type: imxQbmDbts.ValType.Text,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QBMVSystemOverview', Columns: columns };
        };
        return OpsupportSystemoverview;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportSystemoverview type. */
    var OpsupportSystemoverviewInteractive = /** @class */ (function (_super) {
        __extends(OpsupportSystemoverviewInteractive, _super);
        function OpsupportSystemoverviewInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportSystemoverviewInteractive;
    }(OpsupportSystemoverview));
    var OpsupportWebapplications = /** @class */ (function (_super) {
        __extends(OpsupportWebapplications, _super);
        function OpsupportWebapplications() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.BaseURL = _this.GetEntityValue('BaseURL');
            _this.AutoUpdateLevel = _this.GetEntityValue('AutoUpdateLevel');
            _this.UID_DialogProduct = _this.GetEntityValue('UID_DialogProduct');
            _this.IsDebug = _this.GetEntityValue('IsDebug');
            _this.IsPrivate = _this.GetEntityValue('IsPrivate');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        OpsupportWebapplications.GetEntitySchema = function () {
            var columns = {
                'BaseURL': {
                    ColumnName: 'BaseURL',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'AutoUpdateLevel': {
                    ColumnName: 'AutoUpdateLevel',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'UID_DialogProduct': {
                    ColumnName: 'UID_DialogProduct',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'IsDebug': {
                    ColumnName: 'IsDebug',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsPrivate': {
                    ColumnName: 'IsPrivate',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'QBMWebApplication', Columns: columns };
        };
        return OpsupportWebapplications;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the OpsupportWebapplications type. */
    var OpsupportWebapplicationsInteractive = /** @class */ (function (_super) {
        __extends(OpsupportWebapplicationsInteractive, _super);
        function OpsupportWebapplicationsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return OpsupportWebapplicationsInteractive;
    }(OpsupportWebapplications));
    var ImxMultilanguageUiculturesWrapper = /** @class */ (function () {
        function ImxMultilanguageUiculturesWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        ImxMultilanguageUiculturesWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('imx/multilanguage/uicultures');
        };
        ImxMultilanguageUiculturesWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('imx/multilanguage/uicultures');
                this.builder = new imxQbmDbts.TypedEntityBuilder(ImxMultilanguageUicultures, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        ImxMultilanguageUiculturesWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.imx_multilanguage_uicultures_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return ImxMultilanguageUiculturesWrapper;
    }());
    var ImxSysteminfoThirdpartyWrapper = /** @class */ (function () {
        function ImxSysteminfoThirdpartyWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        ImxSysteminfoThirdpartyWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('imx/systeminfo/thirdparty');
        };
        ImxSysteminfoThirdpartyWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('imx/systeminfo/thirdparty');
                this.builder = new imxQbmDbts.TypedEntityBuilder(ImxSysteminfoThirdparty, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        ImxSysteminfoThirdpartyWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.imx_systeminfo_thirdparty_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return ImxSysteminfoThirdpartyWrapper;
    }());
    var OpsupportCandidatesDialogtimezoneWrapper = /** @class */ (function () {
        function OpsupportCandidatesDialogtimezoneWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportCandidatesDialogtimezoneWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/candidates/DialogTimeZone');
        };
        OpsupportCandidatesDialogtimezoneWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/candidates/DialogTimeZone');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportCandidatesDialogtimezone, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportCandidatesDialogtimezoneWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_candidates_DialogTimeZone_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportCandidatesDialogtimezoneWrapper;
    }());
    var OpsupportJobserversWrapper = /** @class */ (function () {
        function OpsupportJobserversWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.opsupport_jobservers_put(writeData);
            };
        }
        /** Returns the runtime schema for this method. */
        OpsupportJobserversWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/jobservers');
        };
        OpsupportJobserversWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/jobservers');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportJobservers, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportJobserversWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_jobservers_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        OpsupportJobserversWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_jobservers_put(inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportJobserversWrapper;
    }());
    var OpsupportJournalWrapper = /** @class */ (function () {
        function OpsupportJournalWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportJournalWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/journal');
        };
        OpsupportJournalWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/journal');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportJournal, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportJournalWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_journal_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportJournalWrapper;
    }());
    var OpsupportQueueDbqueueWrapper = /** @class */ (function () {
        function OpsupportQueueDbqueueWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportQueueDbqueueWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/queue/dbqueue');
        };
        OpsupportQueueDbqueueWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/dbqueue');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportQueueDbqueue, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportQueueDbqueueWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_queue_dbqueue_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportQueueDbqueueWrapper;
    }());
    var OpsupportQueueFrozenjobsWrapper = /** @class */ (function () {
        function OpsupportQueueFrozenjobsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportQueueFrozenjobsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/queue/frozenjobs');
        };
        OpsupportQueueFrozenjobsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/frozenjobs');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportQueueFrozenjobs, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportQueueFrozenjobsWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_queue_frozenjobs_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportQueueFrozenjobsWrapper;
    }());
    var OpsupportQueueFrozenjobsbyqueueWrapper = /** @class */ (function () {
        function OpsupportQueueFrozenjobsbyqueueWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportQueueFrozenjobsbyqueueWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/queue/frozenjobsbyqueue');
        };
        OpsupportQueueFrozenjobsbyqueueWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/frozenjobsbyqueue');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportQueueFrozenjobsbyqueue, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportQueueFrozenjobsbyqueueWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_queue_frozenjobsbyqueue_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportQueueFrozenjobsbyqueueWrapper;
    }());
    var OpsupportQueueJobaffectsWrapper = /** @class */ (function () {
        function OpsupportQueueJobaffectsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportQueueJobaffectsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/queue/jobaffects/{UID_Job}');
        };
        OpsupportQueueJobaffectsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/jobaffects/{UID_Job}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportQueueJobaffects, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportQueueJobaffectsWrapper.prototype.Get = function (UID_Job, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_queue_jobaffects_get(UID_Job, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportQueueJobaffectsWrapper;
    }());
    var OpsupportQueueJobchainsWrapper = /** @class */ (function () {
        function OpsupportQueueJobchainsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportQueueJobchainsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/queue/jobchains');
        };
        OpsupportQueueJobchainsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/jobchains');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportQueueJobchains, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportQueueJobchainsWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_queue_jobchains_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportQueueJobchainsWrapper;
    }());
    var OpsupportQueueJobhistoryWrapper = /** @class */ (function () {
        function OpsupportQueueJobhistoryWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportQueueJobhistoryWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/queue/jobhistory');
        };
        OpsupportQueueJobhistoryWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/jobhistory');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportQueueJobhistory, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportQueueJobhistoryWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_queue_jobhistory_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportQueueJobhistoryWrapper;
    }());
    var OpsupportQueueJobperformanceWrapper = /** @class */ (function () {
        function OpsupportQueueJobperformanceWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportQueueJobperformanceWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/queue/jobperformance');
        };
        OpsupportQueueJobperformanceWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/jobperformance');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportQueueJobperformance, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportQueueJobperformanceWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_queue_jobperformance_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportQueueJobperformanceWrapper;
    }());
    var OpsupportQueueJobsWrapper = /** @class */ (function () {
        function OpsupportQueueJobsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportQueueJobsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/queue/jobs');
        };
        OpsupportQueueJobsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/jobs');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportQueueJobs, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportQueueJobsWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_queue_jobs_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportQueueJobsWrapper;
    }());
    var OpsupportQueueOverviewWrapper = /** @class */ (function () {
        function OpsupportQueueOverviewWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportQueueOverviewWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/queue/overview');
        };
        OpsupportQueueOverviewWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/overview');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportQueueOverview, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportQueueOverviewWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_queue_overview_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportQueueOverviewWrapper;
    }());
    var OpsupportQueueTreeWrapper = /** @class */ (function () {
        function OpsupportQueueTreeWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportQueueTreeWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/queue/tree');
        };
        OpsupportQueueTreeWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/queue/tree');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportQueueTree, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportQueueTreeWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_queue_tree_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportQueueTreeWrapper;
    }());
    var OpsupportSearchIndexedtablesWrapper = /** @class */ (function () {
        function OpsupportSearchIndexedtablesWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportSearchIndexedtablesWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/search/indexedtables');
        };
        OpsupportSearchIndexedtablesWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/search/indexedtables');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportSearchIndexedtables, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportSearchIndexedtablesWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_search_indexedtables_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportSearchIndexedtablesWrapper;
    }());
    var OpsupportSystemoverviewWrapper = /** @class */ (function () {
        function OpsupportSystemoverviewWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportSystemoverviewWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/systemoverview');
        };
        OpsupportSystemoverviewWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/systemoverview');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportSystemoverview, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportSystemoverviewWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_systemoverview_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportSystemoverviewWrapper;
    }());
    var OpsupportWebapplicationsWrapper = /** @class */ (function () {
        function OpsupportWebapplicationsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        OpsupportWebapplicationsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('opsupport/webapplications');
        };
        OpsupportWebapplicationsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('opsupport/webapplications');
                this.builder = new imxQbmDbts.TypedEntityBuilder(OpsupportWebapplications, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        OpsupportWebapplicationsWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.opsupport_webapplications_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return OpsupportWebapplicationsWrapper;
    }());
    /** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
    var ApiClientMethodFactory = /** @class */ (function () {
        function ApiClientMethodFactory() {
        }
        ApiClientMethodFactory.prototype.admin_apiconfig_get = function (appId) {
            return {
                path: '/admin/apiconfig/{appId}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_apiconfig_post = function (appId, global, inputParameterName) {
            return {
                path: '/admin/apiconfig/{appId}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'global',
                        value: global,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_apiconfigsingle_get = function (appId, path) {
            return {
                path: '/admin/apiconfig/{appId}/{path}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'path',
                        value: path,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_apiconfigsingle_post = function (appId, path) {
            return {
                path: '/admin/apiconfig/{appId}/{path}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'path',
                        value: path,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_apiconfig_convert_post = function (appId) {
            return {
                path: '/admin/apiconfig/convert/{appId}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_apiconfig_revert_post = function (appId, global) {
            return {
                path: '/admin/apiconfig/revert/{appId}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'global',
                        value: global,
                        in: 'query'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_apiconfig_values_get = function (appId, path) {
            return {
                path: '/admin/apiconfig/values/{appId}/{path}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'path',
                        value: path,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_cache_get = function (appId) {
            return {
                path: '/admin/cache/{appId}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_cache_post = function (appId, flush, disable) {
            return {
                path: '/admin/cache/{appId}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'flush',
                        value: flush,
                        in: 'query'
                    },
                    {
                        name: 'disable',
                        value: disable,
                        in: 'query'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_cachebyid_get = function (appId, cacheid) {
            return {
                path: '/admin/cache/{appId}/{cacheid}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'cacheid',
                        value: cacheid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_cachebyid_post = function (appId, cacheid, flush, disable) {
            return {
                path: '/admin/cache/{appId}/{cacheid}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'cacheid',
                        value: cacheid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'flush',
                        value: flush,
                        in: 'query'
                    },
                    {
                        name: 'disable',
                        value: disable,
                        in: 'query'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_config_get = function () {
            return {
                path: '/admin/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_config_post = function (inputParameterName) {
            return {
                path: '/admin/config',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_packages_get = function () {
            return {
                path: '/admin/packages',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_performance_get = function () {
            return {
                path: '/admin/performance',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_projects_get = function () {
            return {
                path: '/admin/projects',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_status_get = function () {
            return {
                path: '/admin/status',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_systeminfo_log_get = function (dir, file) {
            return {
                path: '/admin/systeminfo/log/{dir}/{file}',
                parameters: [
                    {
                        name: 'dir',
                        value: dir,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'file',
                        value: file,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_systeminfo_log_live_get = function () {
            return {
                path: '/admin/systeminfo/log/live',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_systeminfo_log_session_get = function () {
            return {
                path: '/admin/systeminfo/log/session',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_systeminfo_logs_get = function () {
            return {
                path: '/admin/systeminfo/logs',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_systeminfo_plugins_get = function () {
            return {
                path: '/admin/systeminfo/plugins',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_systeminfo_software_status_get = function () {
            return {
                path: '/admin/systeminfo/software/status',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.admin_systeminfo_software_update_post = function () {
            return {
                path: '/admin/systeminfo/software/update',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_activeverbs_get = function (appId) {
            return {
                path: '/imx/activeverbs/{appId}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_applications_get = function () {
            return {
                path: '/imx/applications',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_config_get = function () {
            return {
                path: '/imx/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_entityschema_get = function () {
            return {
                path: '/imx/entityschema',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_help_context_get = function (helpcontextid, language) {
            return {
                path: '/imx/help/context/{helpcontextid}/{language}',
                parameters: [
                    {
                        name: 'helpcontextid',
                        value: helpcontextid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'language',
                        value: language,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_login_post = function (appId, noxsrf, inputParameterName) {
            return {
                path: '/imx/login/{appId}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'noxsrf',
                        value: noxsrf,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_logout_post = function (appId) {
            return {
                path: '/imx/logout/{appId}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_metadata_table_get = function (tableName, cultureName) {
            return {
                path: '/imx/metadata/table/{tableName}',
                parameters: [
                    {
                        name: 'tableName',
                        value: tableName,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'cultureName',
                        value: cultureName,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_modelcss_get = function () {
            return {
                path: '/imx/modelcss',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_modelimage_get = function (key, size) {
            return {
                path: '/imx/modelimage/{key}',
                parameters: [
                    {
                        name: 'key',
                        value: key,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'size',
                        value: size,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_multilanguage_getcaptions_get = function (cultureName) {
            return {
                path: '/imx/multilanguage/getcaptions',
                parameters: [
                    {
                        name: 'cultureName',
                        value: cultureName,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_multilanguage_translations_get = function (cultureName, appId) {
            return {
                path: '/imx/multilanguage/translations/{appId}',
                parameters: [
                    {
                        name: 'cultureName',
                        value: cultureName,
                        in: 'query'
                    },
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_multilanguage_uicultures_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/imx/multilanguage/uicultures',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_oauth_get = function (authentifier, appId, redirecturi) {
            return {
                path: '/imx/oauth/{appId}/{authentifier}',
                parameters: [
                    {
                        name: 'authentifier',
                        value: authentifier,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'redirecturi',
                        value: redirecturi,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_ping_get = function () {
            return {
                path: '/imx/ping',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_sessions_get = function (appId) {
            return {
                path: '/imx/sessions/{appId}',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_sessions_info_get = function (appId) {
            return {
                path: '/imx/sessions/{appId}/info',
                parameters: [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_system_get = function () {
            return {
                path: '/imx/system',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_systeminfo_thirdparty_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/imx/systeminfo/thirdparty',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.imx_themes_get = function () {
            return {
                path: '/imx/themes',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_assignment_get = function (tableName, uid) {
            return {
                path: '/opsupport/assignment/{tableName}/{uid}',
                parameters: [
                    {
                        name: 'tableName',
                        value: tableName,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_candidates_DialogTimeZone_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/candidates/DialogTimeZone',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_candidates_DialogTimeZone_datamodel_get = function (filter) {
            return {
                path: '/opsupport/candidates/DialogTimeZone/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_candidates_DialogTimeZone_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/opsupport/candidates/DialogTimeZone/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_changeoperations_process_get = function (backto, processid) {
            return {
                path: '/opsupport/changeoperations/process/{processid}',
                parameters: [
                    {
                        name: 'backto',
                        value: backto,
                        in: 'query'
                    },
                    {
                        name: 'processid',
                        value: processid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_changeoperations_time_get = function (backto, backfrom, types) {
            return {
                path: '/opsupport/changeoperations/time',
                parameters: [
                    {
                        name: 'backto',
                        value: backto,
                        in: 'query'
                    },
                    {
                        name: 'backfrom',
                        value: backfrom,
                        in: 'query'
                    },
                    {
                        name: 'types',
                        value: types,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_changeoperations_user_get = function (backto, username) {
            return {
                path: '/opsupport/changeoperations/user/{username}',
                parameters: [
                    {
                        name: 'backto',
                        value: backto,
                        in: 'query'
                    },
                    {
                        name: 'username',
                        value: username,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_config_get = function () {
            return {
                path: '/opsupport/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_dbobject_get = function (tableName, uid) {
            return {
                path: '/opsupport/dbobject/{tableName}/{uid}',
                parameters: [
                    {
                        name: 'tableName',
                        value: tableName,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_history_get = function (table, uid) {
            return {
                path: '/opsupport/history/{table}/{uid}',
                parameters: [
                    {
                        name: 'table',
                        value: table,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_history_comparison_get = function (table, uid, CompareDate) {
            return {
                path: '/opsupport/history/{table}/{uid}/comparison',
                parameters: [
                    {
                        name: 'table',
                        value: table,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'CompareDate',
                        value: CompareDate,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_hyperview_get = function (table, uid, node) {
            return {
                path: '/opsupport/hyperview/{table}/{uid}',
                parameters: [
                    {
                        name: 'table',
                        value: table,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'node',
                        value: node,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_jobserver_get = function (server) {
            return {
                path: '/opsupport/jobserver/{server}',
                parameters: [
                    {
                        name: 'server',
                        value: server,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_jobservers_get = function (withconnection, nofetchjob, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey) {
            return {
                path: '/opsupport/jobservers',
                parameters: [
                    {
                        name: 'withconnection',
                        value: withconnection,
                        in: 'query'
                    },
                    {
                        name: 'nofetchjob',
                        value: nofetchjob,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'ParentKey',
                        value: ParentKey,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_jobservers_put = function (inputParameterName) {
            return {
                path: '/opsupport/jobservers',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_jobservers_check_post = function (uidserver) {
            return {
                path: '/opsupport/jobservers/{uidserver}/check',
                parameters: [
                    {
                        name: 'uidserver',
                        value: uidserver,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_jobservers_bulk_put = function (inputParameterName) {
            return {
                path: '/opsupport/jobservers/bulk',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_jobservers_datamodel_get = function (filter) {
            return {
                path: '/opsupport/jobservers/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_journal_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, messagetype) {
            return {
                path: '/opsupport/journal',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'messagetype',
                        value: messagetype,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_journal_datamodel_get = function (filter) {
            return {
                path: '/opsupport/journal/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_journal_stat_get = function () {
            return {
                path: '/opsupport/journal/stat',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_profile_get = function () {
            return {
                path: '/opsupport/profile',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_profile_post = function (inputParameterName) {
            return {
                path: '/opsupport/profile',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_profile_delete = function () {
            return {
                path: '/opsupport/profile',
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_profile_person_get = function () {
            return {
                path: '/opsupport/profile/person',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_projectconfig_get = function () {
            return {
                path: '/opsupport/projectconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_dbqueue_get = function () {
            return {
                path: '/opsupport/queue/dbqueue',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_frozenjobs_get = function (queue, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/queue/frozenjobs',
                parameters: [
                    {
                        name: 'queue',
                        value: queue,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_frozenjobsbyqueue_get = function () {
            return {
                path: '/opsupport/queue/frozenjobsbyqueue',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_jobaffects_get = function (UID_Job, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/queue/jobaffects/{UID_Job}',
                parameters: [
                    {
                        name: 'UID_Job',
                        value: UID_Job,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_jobchains_get = function () {
            return {
                path: '/opsupport/queue/jobchains',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_jobhistory_get = function (genprocid, OrderBy, StartIndex, PageSize, filter, withProperties, search, queue) {
            return {
                path: '/opsupport/queue/jobhistory',
                parameters: [
                    {
                        name: 'genprocid',
                        value: genprocid,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'queue',
                        value: queue,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_jobhistory_datamodel_get = function (filter) {
            return {
                path: '/opsupport/queue/jobhistory/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_jobperformance_get = function (queue, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/queue/jobperformance',
                parameters: [
                    {
                        name: 'queue',
                        value: queue,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_jobperformancequeues_get = function () {
            return {
                path: '/opsupport/queue/jobperformancequeues',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_jobs_get = function (genprocid, OrderBy, StartIndex, PageSize, filter, withProperties, search, state, queue) {
            return {
                path: '/opsupport/queue/jobs',
                parameters: [
                    {
                        name: 'genprocid',
                        value: genprocid,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'state',
                        value: state,
                        in: 'query'
                    },
                    {
                        name: 'queue',
                        value: queue,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_jobs_datamodel_get = function (filter) {
            return {
                path: '/opsupport/queue/jobs/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_object_get = function (table, uid) {
            return {
                path: '/opsupport/queue/object/{table}/{uid}',
                parameters: [
                    {
                        name: 'table',
                        value: table,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_overview_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/queue/overview',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_overview_stream_get = function () {
            return {
                path: '/opsupport/queue/overview/stream',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_reactivatejob_post = function (inputParameterName) {
            return {
                path: '/opsupport/queue/reactivatejob',
                parameters: [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_queue_tree_get = function (uidtree) {
            return {
                path: '/opsupport/queue/tree',
                parameters: [
                    {
                        name: 'uidtree',
                        value: uidtree,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_search_get = function (term, tables) {
            return {
                path: '/opsupport/search',
                parameters: [
                    {
                        name: 'term',
                        value: term,
                        in: 'query'
                    },
                    {
                        name: 'tables',
                        value: tables,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_search_indexedtables_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/search/indexedtables',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_streamconfig_get = function () {
            return {
                path: '/opsupport/streamconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_systemoverview_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/systemoverview',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_systemstatus_get = function () {
            return {
                path: '/opsupport/systemstatus',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_systemstatus_post = function (IsDbSchedulerDisabled, IsJobServiceDisabled, inputParameterName) {
            return {
                path: '/opsupport/systemstatus',
                parameters: [
                    {
                        name: 'IsDbSchedulerDisabled',
                        value: IsDbSchedulerDisabled,
                        in: 'query'
                    },
                    {
                        name: 'IsJobServiceDisabled',
                        value: IsJobServiceDisabled,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_usergroups_get = function () {
            return {
                path: '/opsupport/usergroups',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.opsupport_webapplications_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/opsupport/webapplications',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_get = function (filter) {
            return {
                path: '/scim/v2',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2__search_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/.search/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2__search_post = function () {
            return {
                path: '/scim/v2/.search/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_AccProduct_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/AccProduct/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_AccProduct_post = function () {
            return {
                path: '/scim/v2/AccProduct/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_AccProductby_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/AccProduct/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_AccProductby_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/AccProduct/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_AccProductby_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/AccProduct/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_AccProductby_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/AccProduct/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Bulk_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/Bulk/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Bulk_post = function () {
            return {
                path: '/scim/v2/Bulk/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Department_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/Department/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Department_post = function () {
            return {
                path: '/scim/v2/Department/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Departmentby_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Department/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Departmentby_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Department/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Departmentby_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Department/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Departmentby_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Department/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Locality_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/Locality/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Locality_post = function () {
            return {
                path: '/scim/v2/Locality/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Localityby_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Locality/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Localityby_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Locality/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Localityby_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Locality/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Localityby_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Locality/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Me_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/Me/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Me_post = function () {
            return {
                path: '/scim/v2/Me/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Person_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/Person/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Person_post = function () {
            return {
                path: '/scim/v2/Person/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Personby_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Person/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Personby_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Person/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Personby_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Person/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Personby_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Person/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Profitcenter_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/Profitcenter/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Profitcenter_post = function () {
            return {
                path: '/scim/v2/Profitcenter/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Profitcenterby_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Profitcenter/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Profitcenterby_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Profitcenter/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Profitcenterby_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Profitcenter/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Profitcenterby_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/Profitcenter/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_ResourceTypes_get = function () {
            return {
                path: '/scim/v2/ResourceTypes',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_Schemas_get = function () {
            return {
                path: '/scim/v2/Schemas',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_ServiceProviderConfig_get = function () {
            return {
                path: '/scim/v2/ServiceProviderConfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsAccount_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/UnsAccount/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsAccount_post = function () {
            return {
                path: '/scim/v2/UnsAccount/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsAccountby_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsAccount/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsAccountby_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsAccount/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsAccountby_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsAccount/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsAccountby_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsAccount/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsAccountB_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/UnsAccountB/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsAccountB_post = function () {
            return {
                path: '/scim/v2/UnsAccountB/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsAccountBby_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsAccountB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsAccountBby_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsAccountB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsAccountBby_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsAccountB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsAccountBby_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsAccountB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsContainerB_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/UnsContainerB/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsContainerB_post = function () {
            return {
                path: '/scim/v2/UnsContainerB/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsContainerBby_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsContainerB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsContainerBby_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsContainerB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsContainerBby_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsContainerB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsContainerBby_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsContainerB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroup_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/UnsGroup/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroup_post = function () {
            return {
                path: '/scim/v2/UnsGroup/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupby_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroup/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupby_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroup/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupby_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroup/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupby_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroup/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/UnsGroupB/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB_post = function () {
            return {
                path: '/scim/v2/UnsGroupB/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupBby_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupBby_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupBby_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupBby_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB1_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/UnsGroupB1/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB1_post = function () {
            return {
                path: '/scim/v2/UnsGroupB1/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB1by_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB1/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB1by_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB1/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB1by_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB1/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB1by_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB1/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB2_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/UnsGroupB2/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB2_post = function () {
            return {
                path: '/scim/v2/UnsGroupB2/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB2by_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB2/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB2by_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB2/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB2by_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB2/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB2by_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB2/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB3_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/UnsGroupB3/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB3_post = function () {
            return {
                path: '/scim/v2/UnsGroupB3/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB3by_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB3/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB3by_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB3/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB3by_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB3/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsGroupB3by_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsGroupB3/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsRootB_get = function (count, startIndex, attributes, filter) {
            return {
                path: '/scim/v2/UnsRootB/',
                parameters: [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsRootB_post = function () {
            return {
                path: '/scim/v2/UnsRootB/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsRootBby_id_get = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsRootB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsRootBby_id_delete = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsRootB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsRootBby_id_put = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsRootB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.scim_v2_UnsRootBby_id_patch = function (attributes, excludedAttributes, uid) {
            return {
                path: '/scim/v2/UnsRootB/{uid}',
                parameters: [
                    {
                        name: 'attributes',
                        value: attributes,
                        in: 'query'
                    },
                    {
                        name: 'excludedAttributes',
                        value: excludedAttributes,
                        in: 'query'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return ApiClientMethodFactory;
    }());
    /** @deprecated Use the V2Client class for a stable method interface. */
    var Client = /** @class */ (function () {
        function Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        /** Returns the currently active configuration for the specified project. */
        Client.prototype.admin_apiconfig_get = function (appId, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_get(appId), requestOptions);
        };
        /** Updates the configuration with the supplied values. */
        Client.prototype.admin_apiconfig_post = function (appId, global, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_post(appId, global, inputParameterName), requestOptions);
        };
        /** Returns the currently active configuration value for the specified path. */
        Client.prototype.admin_apiconfigsingle_get = function (appId, path, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfigsingle_get(appId, path), requestOptions);
        };
        /** Adds a new configuration key on the specified path. */
        Client.prototype.admin_apiconfigsingle_post = function (appId, path, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfigsingle_post(appId, path), requestOptions);
        };
        Client.prototype.admin_apiconfig_convert_post = function (appId, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_convert_post(appId), requestOptions);
        };
        /** Reverts all global or local customizations */
        Client.prototype.admin_apiconfig_revert_post = function (appId, global, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_revert_post(appId, global), requestOptions);
        };
        /** Returns valid values for the configuration setting identified by specified path. */
        Client.prototype.admin_apiconfig_values_get = function (appId, path, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_values_get(appId, path), requestOptions);
        };
        /** Returns cache data for the specified project. */
        Client.prototype.admin_cache_get = function (appId, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_cache_get(appId), requestOptions);
        };
        /** Returns cache data for the specified project. */
        Client.prototype.admin_cache_post = function (appId, flush, disable, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_cache_post(appId, flush, disable), requestOptions);
        };
        /** Manages the specified cache for the specified project. */
        Client.prototype.admin_cachebyid_get = function (appId, cacheid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_cachebyid_get(appId, cacheid), requestOptions);
        };
        /** Manages the specified cache for the specified project. */
        Client.prototype.admin_cachebyid_post = function (appId, cacheid, flush, disable, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_cachebyid_post(appId, cacheid, flush, disable), requestOptions);
        };
        Client.prototype.admin_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_config_get(), requestOptions);
        };
        Client.prototype.admin_config_post = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_config_post(inputParameterName), requestOptions);
        };
        Client.prototype.admin_packages_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_packages_get(), requestOptions);
        };
        /** Returns the most recently recorded performance data. */
        Client.prototype.admin_performance_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_performance_get(), requestOptions);
        };
        Client.prototype.admin_projects_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_projects_get(), requestOptions);
        };
        Client.prototype.admin_status_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_status_get(), requestOptions);
        };
        Client.prototype.admin_systeminfo_log_get = function (dir, file, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_log_get(dir, file), requestOptions);
        };
        Client.prototype.admin_systeminfo_log_live_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_log_live_get(), requestOptions);
        };
        Client.prototype.admin_systeminfo_log_session_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_log_session_get(), requestOptions);
        };
        Client.prototype.admin_systeminfo_logs_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_logs_get(), requestOptions);
        };
        Client.prototype.admin_systeminfo_plugins_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_plugins_get(), requestOptions);
        };
        Client.prototype.admin_systeminfo_software_status_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_software_status_get(), requestOptions);
        };
        /** Starts the software update process */
        Client.prototype.admin_systeminfo_software_update_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_software_update_post(), requestOptions);
        };
        /** Returns the set of currently active endpoints, and a flag indicating whether an endpoint is active for the current user. */
        Client.prototype.imx_activeverbs_get = function (appId, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_activeverbs_get(appId), requestOptions);
        };
        Client.prototype.imx_applications_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_applications_get(), requestOptions);
        };
        Client.prototype.imx_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_config_get(), requestOptions);
        };
        Client.prototype.imx_entityschema_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_entityschema_get(), requestOptions);
        };
        Client.prototype.imx_help_context_get = function (helpcontextid, language, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_help_context_get(helpcontextid, language), requestOptions);
        };
        Client.prototype.imx_login_post = function (appId, noxsrf, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_login_post(appId, noxsrf, inputParameterName), requestOptions);
        };
        Client.prototype.imx_logout_post = function (appId, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_logout_post(appId), requestOptions);
        };
        /** Returns metadata for a specific database table. */
        Client.prototype.imx_metadata_table_get = function (tableName, cultureName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_metadata_table_get(tableName, cultureName), requestOptions);
        };
        /** Returns the model-generated stylesheet. */
        Client.prototype.imx_modelcss_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_modelcss_get(), requestOptions);
        };
        /** Returns an image stored from data model. */
        Client.prototype.imx_modelimage_get = function (key, size, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_modelimage_get(key, size), requestOptions);
        };
        /** Returns web UI translations for a specific culture. */
        Client.prototype.imx_multilanguage_getcaptions_get = function (cultureName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_multilanguage_getcaptions_get(cultureName), requestOptions);
        };
        /** Returns translations for the data model for an API project. */
        Client.prototype.imx_multilanguage_translations_get = function (cultureName, appId, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_multilanguage_translations_get(cultureName, appId), requestOptions);
        };
        /** Returns all cultures that are available to frontends. */
        Client.prototype.imx_multilanguage_uicultures_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_multilanguage_uicultures_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.imx_oauth_get = function (authentifier, appId, redirecturi, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_oauth_get(authentifier, appId, redirecturi), requestOptions);
        };
        /** Returns an object indicating whether this API server was able to start up and establish a database connection. */
        Client.prototype.imx_ping_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_ping_get(), requestOptions);
        };
        Client.prototype.imx_sessions_get = function (appId, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_sessions_get(appId), requestOptions);
        };
        Client.prototype.imx_sessions_info_get = function (appId, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_sessions_info_get(appId), requestOptions);
        };
        Client.prototype.imx_system_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_system_get(), requestOptions);
        };
        /** Returns a list of all third party components. */
        Client.prototype.imx_systeminfo_thirdparty_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_systeminfo_thirdparty_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.imx_themes_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_themes_get(), requestOptions);
        };
        /** Returns the objects that are part of assignment, specified by the assignment's 'table name and the uid. */
        Client.prototype.opsupport_assignment_get = function (tableName, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_assignment_get(tableName, uid), requestOptions);
        };
        /** Returns a list of candidate objects from the table DialogTimeZone. */
        Client.prototype.opsupport_candidates_DialogTimeZone_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_candidates_DialogTimeZone_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns data model information about query options for the candidates/DialogTimeZone endpoint. */
        Client.prototype.opsupport_candidates_DialogTimeZone_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_candidates_DialogTimeZone_datamodel_get(filter), requestOptions);
        };
        /** Returns filter tree information for the candidates/DialogTimeZone endpoint. */
        Client.prototype.opsupport_candidates_DialogTimeZone_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_candidates_DialogTimeZone_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns change operations by process ID */
        Client.prototype.opsupport_changeoperations_process_get = function (backto, processid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_changeoperations_process_get(backto, processid), requestOptions);
        };
        /** Returns change operations by change type and/or by time frame. */
        Client.prototype.opsupport_changeoperations_time_get = function (backto, backfrom, types, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_changeoperations_time_get(backto, backfrom, types), requestOptions);
        };
        /** Returns change operations by user */
        Client.prototype.opsupport_changeoperations_user_get = function (backto, username, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_changeoperations_user_get(backto, username), requestOptions);
        };
        Client.prototype.opsupport_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_config_get(), requestOptions);
        };
        /** Returns basic information about an object specified by the table name and the uid. */
        Client.prototype.opsupport_dbobject_get = function (tableName, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_dbobject_get(tableName, uid), requestOptions);
        };
        Client.prototype.opsupport_history_get = function (table, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_history_get(table, uid), requestOptions);
        };
        Client.prototype.opsupport_history_comparison_get = function (table, uid, CompareDate, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_history_comparison_get(table, uid, CompareDate), requestOptions);
        };
        /** Returns the HyperView shape information for the specified object */
        Client.prototype.opsupport_hyperview_get = function (table, uid, node, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_hyperview_get(table, uid, node), requestOptions);
        };
        Client.prototype.opsupport_jobserver_get = function (server, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_jobserver_get(server), requestOptions);
        };
        Client.prototype.opsupport_jobservers_get = function (withconnection, nofetchjob, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_jobservers_get(withconnection, nofetchjob, OrderBy, StartIndex, PageSize, filter, withProperties, search, ParentKey), requestOptions);
        };
        Client.prototype.opsupport_jobservers_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_jobservers_put(inputParameterName), requestOptions);
        };
        /** Runs a connection check for the specified server. */
        Client.prototype.opsupport_jobservers_check_post = function (uidserver, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_jobservers_check_post(uidserver), requestOptions);
        };
        Client.prototype.opsupport_jobservers_bulk_put = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_jobservers_bulk_put(inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the jobservers endpoint. */
        Client.prototype.opsupport_jobservers_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_jobservers_datamodel_get(filter), requestOptions);
        };
        /** Returns entries in the journal, returning the newest entries first. */
        Client.prototype.opsupport_journal_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, messagetype, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_journal_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, messagetype), requestOptions);
        };
        /** Returns data model information about query options for the journal endpoint. */
        Client.prototype.opsupport_journal_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_journal_datamodel_get(filter), requestOptions);
        };
        Client.prototype.opsupport_journal_stat_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_journal_stat_get(), requestOptions);
        };
        /** Delete currentuser profile settings */
        Client.prototype.opsupport_profile_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_profile_get(), requestOptions);
        };
        /** Updates the user profile with the specified settings. Null values will not delete existing values. */
        Client.prototype.opsupport_profile_post = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_profile_post(inputParameterName), requestOptions);
        };
        /** Delete currentuser profile settings */
        Client.prototype.opsupport_profile_delete = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_profile_delete(), requestOptions);
        };
        /** Returns profile infromation for the current user. */
        Client.prototype.opsupport_profile_person_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_profile_person_get(), requestOptions);
        };
        Client.prototype.opsupport_projectconfig_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_projectconfig_get(), requestOptions);
        };
        /** Returns the contents of the database queue. */
        Client.prototype.opsupport_queue_dbqueue_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_dbqueue_get(), requestOptions);
        };
        Client.prototype.opsupport_queue_frozenjobs_get = function (queue, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_frozenjobs_get(queue, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_queue_frozenjobsbyqueue_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_frozenjobsbyqueue_get(), requestOptions);
        };
        Client.prototype.opsupport_queue_jobaffects_get = function (UID_Job, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobaffects_get(UID_Job, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_queue_jobchains_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobchains_get(), requestOptions);
        };
        Client.prototype.opsupport_queue_jobhistory_get = function (genprocid, OrderBy, StartIndex, PageSize, filter, withProperties, search, queue, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobhistory_get(genprocid, OrderBy, StartIndex, PageSize, filter, withProperties, search, queue), requestOptions);
        };
        /** Returns data model information about query options for the queue/jobhistory endpoint. */
        Client.prototype.opsupport_queue_jobhistory_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobhistory_datamodel_get(filter), requestOptions);
        };
        Client.prototype.opsupport_queue_jobperformance_get = function (queue, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobperformance_get(queue, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_queue_jobperformancequeues_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobperformancequeues_get(), requestOptions);
        };
        Client.prototype.opsupport_queue_jobs_get = function (genprocid, OrderBy, StartIndex, PageSize, filter, withProperties, search, state, queue, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobs_get(genprocid, OrderBy, StartIndex, PageSize, filter, withProperties, search, state, queue), requestOptions);
        };
        /** Returns data model information about query options for the queue/jobs endpoint. */
        Client.prototype.opsupport_queue_jobs_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobs_datamodel_get(filter), requestOptions);
        };
        Client.prototype.opsupport_queue_object_get = function (table, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_object_get(table, uid), requestOptions);
        };
        Client.prototype.opsupport_queue_overview_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_overview_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_queue_overview_stream_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_overview_stream_get(), requestOptions);
        };
        /** Reactivates a process where one of the process steps is in the FROZEN or OVERLIMIT state. */
        Client.prototype.opsupport_queue_reactivatejob_post = function (inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_reactivatejob_post(inputParameterName), requestOptions);
        };
        Client.prototype.opsupport_queue_tree_get = function (uidtree, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_tree_get(uidtree), requestOptions);
        };
        Client.prototype.opsupport_search_get = function (term, tables, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_search_get(term, tables), requestOptions);
        };
        /** Returns the list of tables that are included in the search index. */
        Client.prototype.opsupport_search_indexedtables_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_search_indexedtables_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_streamconfig_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_streamconfig_get(), requestOptions);
        };
        Client.prototype.opsupport_systemoverview_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_systemoverview_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.opsupport_systemstatus_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_systemstatus_get(), requestOptions);
        };
        Client.prototype.opsupport_systemstatus_post = function (IsDbSchedulerDisabled, IsJobServiceDisabled, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_systemstatus_post(IsDbSchedulerDisabled, IsJobServiceDisabled, inputParameterName), requestOptions);
        };
        /** Returns the list of permissions groups that the current user is assigned to. */
        Client.prototype.opsupport_usergroups_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_usergroups_get(), requestOptions);
        };
        Client.prototype.opsupport_webapplications_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_webapplications_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.scim_v2_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_get(filter), requestOptions);
        };
        Client.prototype.scim_v2__search_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2__search_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2__search_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2__search_post(), requestOptions);
        };
        Client.prototype.scim_v2_AccProduct_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_AccProduct_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_AccProduct_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_AccProduct_post(), requestOptions);
        };
        Client.prototype.scim_v2_AccProductby_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_AccProductby_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_AccProductby_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_AccProductby_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_AccProductby_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_AccProductby_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_AccProductby_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_AccProductby_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Bulk_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Bulk_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_Bulk_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Bulk_post(), requestOptions);
        };
        Client.prototype.scim_v2_Department_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Department_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_Department_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Department_post(), requestOptions);
        };
        Client.prototype.scim_v2_Departmentby_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Departmentby_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Departmentby_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Departmentby_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Departmentby_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Departmentby_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Departmentby_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Departmentby_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Locality_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Locality_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_Locality_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Locality_post(), requestOptions);
        };
        Client.prototype.scim_v2_Localityby_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Localityby_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Localityby_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Localityby_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Localityby_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Localityby_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Localityby_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Localityby_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Me_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Me_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_Me_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Me_post(), requestOptions);
        };
        Client.prototype.scim_v2_Person_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Person_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_Person_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Person_post(), requestOptions);
        };
        Client.prototype.scim_v2_Personby_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Personby_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Personby_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Personby_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Personby_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Personby_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Personby_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Personby_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Profitcenter_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Profitcenter_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_Profitcenter_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Profitcenter_post(), requestOptions);
        };
        Client.prototype.scim_v2_Profitcenterby_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Profitcenterby_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Profitcenterby_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Profitcenterby_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Profitcenterby_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Profitcenterby_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_Profitcenterby_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Profitcenterby_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_ResourceTypes_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_ResourceTypes_get(), requestOptions);
        };
        Client.prototype.scim_v2_Schemas_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Schemas_get(), requestOptions);
        };
        Client.prototype.scim_v2_ServiceProviderConfig_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_ServiceProviderConfig_get(), requestOptions);
        };
        Client.prototype.scim_v2_UnsAccount_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccount_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_UnsAccount_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccount_post(), requestOptions);
        };
        Client.prototype.scim_v2_UnsAccountby_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountby_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsAccountby_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountby_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsAccountby_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountby_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsAccountby_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountby_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsAccountB_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountB_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_UnsAccountB_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountB_post(), requestOptions);
        };
        Client.prototype.scim_v2_UnsAccountBby_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountBby_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsAccountBby_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountBby_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsAccountBby_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountBby_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsAccountBby_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountBby_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsContainerB_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsContainerB_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_UnsContainerB_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsContainerB_post(), requestOptions);
        };
        Client.prototype.scim_v2_UnsContainerBby_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsContainerBby_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsContainerBby_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsContainerBby_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsContainerBby_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsContainerBby_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsContainerBby_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsContainerBby_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroup_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroup_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroup_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroup_post(), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupby_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupby_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupby_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupby_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupby_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupby_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupby_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupby_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB_post(), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupBby_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupBby_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupBby_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupBby_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupBby_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupBby_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupBby_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupBby_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB1_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB1_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB1_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB1_post(), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB1by_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB1by_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB1by_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB1by_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB1by_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB1by_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB1by_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB1by_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB2_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB2_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB2_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB2_post(), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB2by_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB2by_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB2by_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB2by_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB2by_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB2by_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB2by_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB2by_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB3_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB3_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB3_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB3_post(), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB3by_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB3by_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB3by_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB3by_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB3by_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB3by_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsGroupB3by_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB3by_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsRootB_get = function (count, startIndex, attributes, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsRootB_get(count, startIndex, attributes, filter), requestOptions);
        };
        Client.prototype.scim_v2_UnsRootB_post = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsRootB_post(), requestOptions);
        };
        Client.prototype.scim_v2_UnsRootBby_id_get = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsRootBby_id_get(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsRootBby_id_delete = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsRootBby_id_delete(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsRootBby_id_put = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsRootBby_id_put(attributes, excludedAttributes, uid), requestOptions);
        };
        Client.prototype.scim_v2_UnsRootBby_id_patch = function (attributes, excludedAttributes, uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsRootBby_id_patch(attributes, excludedAttributes, uid), requestOptions);
        };
        return Client;
    }());
    var V2ApiClientMethodFactory = /** @class */ (function () {
        function V2ApiClientMethodFactory() {
        }
        V2ApiClientMethodFactory.prototype.admin_apiconfig_get = function (/** API project identifier */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/apiconfig/{appId}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_apiconfig_post = function (/** API project identifier */ appId, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/apiconfig/{appId}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_apiconfigsingle_get = function (/** API project identifier */ appId, /** Configuration key identifier */ path, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/apiconfig/{appId}/{path}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'path',
                        value: path,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_apiconfigsingle_post = function (/** API project identifier */ appId, /** Configuration key identifier */ path, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/apiconfig/{appId}/{path}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'path',
                        value: path,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_apiconfig_convert_post = function (/** API project identifier */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/apiconfig/convert/{appId}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_apiconfig_revert_post = function (/** API project identifier */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/apiconfig/revert/{appId}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_apiconfig_values_get = function (/** API project identifier */ appId, /** Configuration key identifier */ path, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/apiconfig/values/{appId}/{path}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'path',
                        value: path,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_cache_get = function (/** API project identifier */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/cache/{appId}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_cache_post = function (/** API project identifier */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/cache/{appId}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_cachebyid_get = function (/** API project identifier */ appId, /** Cache identifier */ cacheid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/cache/{appId}/{cacheid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'cacheid',
                        value: cacheid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_cachebyid_post = function (/** API project identifier */ appId, /** Cache identifier */ cacheid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/cache/{appId}/{cacheid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'cacheid',
                        value: cacheid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_config_get = function (options, requestOptions) {
            return {
                path: '/admin/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_config_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/config',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_packages_get = function (options, requestOptions) {
            return {
                path: '/admin/packages',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_performance_get = function (options, requestOptions) {
            return {
                path: '/admin/performance',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_projects_get = function (options, requestOptions) {
            return {
                path: '/admin/projects',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_status_get = function (options, requestOptions) {
            return {
                path: '/admin/status',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_systeminfo_log_get = function (dir, file, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/admin/systeminfo/log/{dir}/{file}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'dir',
                        value: dir,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'file',
                        value: file,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_systeminfo_log_live_get = function (options, requestOptions) {
            return {
                path: '/admin/systeminfo/log/live',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_systeminfo_log_session_get = function (options, requestOptions) {
            return {
                path: '/admin/systeminfo/log/session',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_systeminfo_logs_get = function (options, requestOptions) {
            return {
                path: '/admin/systeminfo/logs',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_systeminfo_plugins_get = function (options, requestOptions) {
            return {
                path: '/admin/systeminfo/plugins',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_systeminfo_software_status_get = function (options, requestOptions) {
            return {
                path: '/admin/systeminfo/software/status',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.admin_systeminfo_software_update_post = function (options, requestOptions) {
            return {
                path: '/admin/systeminfo/software/update',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_activeverbs_get = function (/** Name of the application */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/activeverbs/{appId}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_applications_get = function (options, requestOptions) {
            return {
                path: '/imx/applications',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_config_get = function (options, requestOptions) {
            return {
                path: '/imx/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_entityschema_get = function (options, requestOptions) {
            return {
                path: '/imx/entityschema',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_help_context_get = function (/** Get help links for a help context */ helpcontextid, /** Language to use */ language, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/help/context/{helpcontextid}/{language}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'helpcontextid',
                        value: helpcontextid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'language',
                        value: language,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_login_post = function (/** Name of the application */ appId, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/login/{appId}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_logout_post = function (/** Name of the application */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/logout/{appId}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_metadata_table_get = function (/** Name of the database table */ tableName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/metadata/table/{tableName}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'tableName',
                        value: tableName,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_modelcss_get = function (options, requestOptions) {
            return {
                path: '/imx/modelcss',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_modelimage_get = function (key, size, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/modelimage/{key}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'key',
                        value: key,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'size',
                        value: size,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_multilanguage_getcaptions_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/multilanguage/getcaptions',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_multilanguage_translations_get = function (/** Name of the application */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/multilanguage/translations/{appId}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_multilanguage_uicultures_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/multilanguage/uicultures',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_oauth_get = function (/** Name of the authentifier module */ authentifier, /** Name of the application */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/oauth/{appId}/{authentifier}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'authentifier',
                        value: authentifier,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_ping_get = function (options, requestOptions) {
            return {
                path: '/imx/ping',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_sessions_get = function (/** Name of the application */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/sessions/{appId}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_sessions_info_get = function (/** Name of the application */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/sessions/{appId}/info',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'appId',
                        value: appId,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_system_get = function (options, requestOptions) {
            return {
                path: '/imx/system',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_systeminfo_thirdparty_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/imx/systeminfo/thirdparty',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.imx_themes_get = function (options, requestOptions) {
            return {
                path: '/imx/themes',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_assignment_get = function (/** Object table name */ tableName, /** Object primary keys, split by comma */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/assignment/{tableName}/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'tableName',
                        value: tableName,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_candidates_DialogTimeZone_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/candidates/DialogTimeZone',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_candidates_DialogTimeZone_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/candidates/DialogTimeZone/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_candidates_DialogTimeZone_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/candidates/DialogTimeZone/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_changeoperations_process_get = function (/** Process identifier */ processid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/changeoperations/process/{processid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'processid',
                        value: processid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_changeoperations_time_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/changeoperations/time',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_changeoperations_user_get = function (/** User name */ username, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/changeoperations/user/{username}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'username',
                        value: username,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_config_get = function (options, requestOptions) {
            return {
                path: '/opsupport/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_dbobject_get = function (/** Object table name */ tableName, /** Object primary keys, split by comma */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/dbobject/{tableName}/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'tableName',
                        value: tableName,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_history_get = function (/** Object type */ table, /** Object GUID */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/history/{table}/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'table',
                        value: table,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_history_comparison_get = function (/** Object type */ table, /** Object GUID */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/history/{table}/{uid}/comparison',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'table',
                        value: table,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_hyperview_get = function (/** Table name of the object */ table, /** Comma-seperated primary keys of the object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/hyperview/{table}/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'table',
                        value: table,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_jobserver_get = function (/** Server name */ server, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/jobserver/{server}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'server',
                        value: server,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_jobservers_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/jobservers',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_jobservers_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/jobservers',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_jobservers_check_post = function (/** Unique server identifier */ uidserver, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/jobservers/{uidserver}/check',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidserver',
                        value: uidserver,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_jobservers_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/jobservers/bulk',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_jobservers_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/jobservers/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_journal_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/journal',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_journal_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/journal/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_journal_stat_get = function (options, requestOptions) {
            return {
                path: '/opsupport/journal/stat',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_profile_get = function (options, requestOptions) {
            return {
                path: '/opsupport/profile',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_profile_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/profile',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_profile_delete = function (options, requestOptions) {
            return {
                path: '/opsupport/profile',
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_profile_person_get = function (options, requestOptions) {
            return {
                path: '/opsupport/profile/person',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_projectconfig_get = function (options, requestOptions) {
            return {
                path: '/opsupport/projectconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_dbqueue_get = function (options, requestOptions) {
            return {
                path: '/opsupport/queue/dbqueue',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_frozenjobs_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/queue/frozenjobs',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_frozenjobsbyqueue_get = function (options, requestOptions) {
            return {
                path: '/opsupport/queue/frozenjobsbyqueue',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_jobaffects_get = function (UID_Job, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/queue/jobaffects/{UID_Job}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Job',
                        value: UID_Job,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_jobchains_get = function (options, requestOptions) {
            return {
                path: '/opsupport/queue/jobchains',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_jobhistory_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/queue/jobhistory',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_jobhistory_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/queue/jobhistory/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_jobperformance_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/queue/jobperformance',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_jobperformancequeues_get = function (options, requestOptions) {
            return {
                path: '/opsupport/queue/jobperformancequeues',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_jobs_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/queue/jobs',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_jobs_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/queue/jobs/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_object_get = function (/** Table name of the object */ table, /** Primary key of the object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/queue/object/{table}/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'table',
                        value: table,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_overview_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/queue/overview',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_overview_stream_get = function (options, requestOptions) {
            return {
                path: '/opsupport/queue/overview/stream',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_reactivatejob_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/queue/reactivatejob',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_queue_tree_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/queue/tree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_search_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/search',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_search_indexedtables_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/search/indexedtables',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_streamconfig_get = function (options, requestOptions) {
            return {
                path: '/opsupport/streamconfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_systemoverview_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/systemoverview',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_systemstatus_get = function (options, requestOptions) {
            return {
                path: '/opsupport/systemstatus',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_systemstatus_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/systemstatus',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_usergroups_get = function (options, requestOptions) {
            return {
                path: '/opsupport/usergroups',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.opsupport_webapplications_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/opsupport/webapplications',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_get = function (/** meta resource filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2__search_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/.search/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2__search_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/.search/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_AccProduct_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/AccProduct/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_AccProduct_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/AccProduct/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_AccProductby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/AccProduct/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_AccProductby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/AccProduct/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_AccProductby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/AccProduct/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_AccProductby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/AccProduct/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Bulk_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Bulk/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Bulk_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/Bulk/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Department_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Department/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Department_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/Department/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Departmentby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Department/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Departmentby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Department/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Departmentby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Department/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Departmentby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Department/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Locality_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Locality/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Locality_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/Locality/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Localityby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Locality/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Localityby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Locality/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Localityby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Locality/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Localityby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Locality/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Me_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Me/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Me_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/Me/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Person_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Person/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Person_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/Person/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Personby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Person/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Personby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Person/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Personby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Person/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Personby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Person/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Profitcenter_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Profitcenter/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Profitcenter_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/Profitcenter/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Profitcenterby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Profitcenter/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Profitcenterby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Profitcenter/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Profitcenterby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Profitcenter/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Profitcenterby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/Profitcenter/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_ResourceTypes_get = function (options, requestOptions) {
            return {
                path: '/scim/v2/ResourceTypes',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_Schemas_get = function (options, requestOptions) {
            return {
                path: '/scim/v2/Schemas',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_ServiceProviderConfig_get = function (options, requestOptions) {
            return {
                path: '/scim/v2/ServiceProviderConfig',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsAccount_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsAccount/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsAccount_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/UnsAccount/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsAccountby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsAccount/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsAccountby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsAccount/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsAccountby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsAccount/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsAccountby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsAccount/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsAccountB_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsAccountB/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsAccountB_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/UnsAccountB/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsAccountBby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsAccountB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsAccountBby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsAccountB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsAccountBby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsAccountB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsAccountBby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsAccountB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsContainerB_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsContainerB/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsContainerB_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/UnsContainerB/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsContainerBby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsContainerB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsContainerBby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsContainerB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsContainerBby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsContainerB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsContainerBby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsContainerB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroup_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroup/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroup_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/UnsGroup/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroup/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroup/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroup/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroup/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/UnsGroupB/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupBby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupBby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupBby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupBby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB1_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB1/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB1_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/UnsGroupB1/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB1by_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB1/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB1by_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB1/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB1by_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB1/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB1by_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB1/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB2_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB2/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB2_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/UnsGroupB2/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB2by_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB2/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB2by_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB2/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB2by_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB2/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB2by_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB2/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB3_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB3/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB3_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/UnsGroupB3/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB3by_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB3/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB3by_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB3/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB3by_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB3/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsGroupB3by_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsGroupB3/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsRootB_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsRootB/',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'count',
                        value: count,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'startIndex',
                        value: startIndex,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'attributes',
                        value: attributes,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsRootB_post = function (options, requestOptions) {
            return {
                path: '/scim/v2/UnsRootB/',
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsRootBby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsRootB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsRootBby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsRootB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsRootBby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsRootB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.scim_v2_UnsRootBby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/scim/v2/UnsRootB/{uid}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'PATCH',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return V2ApiClientMethodFactory;
    }());
    var V2Client = /** @class */ (function () {
        function V2Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new V2ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(V2Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        V2Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        V2Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        V2Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        /** Returns the currently active configuration for the specified project. */
        V2Client.prototype.admin_apiconfig_get = function (/** API project identifier */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_get(appId, options), requestOptions);
        };
        /** Updates the configuration with the supplied values. */
        V2Client.prototype.admin_apiconfig_post = function (/** API project identifier */ appId, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_post(appId, inputParameterName, options), requestOptions);
        };
        /** Returns the currently active configuration value for the specified path. */
        V2Client.prototype.admin_apiconfigsingle_get = function (/** API project identifier */ appId, /** Configuration key identifier */ path, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfigsingle_get(appId, path, options), requestOptions);
        };
        /** Adds a new configuration key on the specified path. */
        V2Client.prototype.admin_apiconfigsingle_post = function (/** API project identifier */ appId, /** Configuration key identifier */ path, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfigsingle_post(appId, path, options), requestOptions);
        };
        V2Client.prototype.admin_apiconfig_convert_post = function (/** API project identifier */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_convert_post(appId, options), requestOptions);
        };
        /** Reverts all global or local customizations */
        V2Client.prototype.admin_apiconfig_revert_post = function (/** API project identifier */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_revert_post(appId, options), requestOptions);
        };
        /** Returns valid values for the configuration setting identified by specified path. */
        V2Client.prototype.admin_apiconfig_values_get = function (/** API project identifier */ appId, /** Configuration key identifier */ path, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_apiconfig_values_get(appId, path, options), requestOptions);
        };
        /** Returns cache data for the specified project. */
        V2Client.prototype.admin_cache_get = function (/** API project identifier */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_cache_get(appId, options), requestOptions);
        };
        /** Returns cache data for the specified project. */
        V2Client.prototype.admin_cache_post = function (/** API project identifier */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_cache_post(appId, options), requestOptions);
        };
        /** Manages the specified cache for the specified project. */
        V2Client.prototype.admin_cachebyid_get = function (/** API project identifier */ appId, /** Cache identifier */ cacheid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_cachebyid_get(appId, cacheid, options), requestOptions);
        };
        /** Manages the specified cache for the specified project. */
        V2Client.prototype.admin_cachebyid_post = function (/** API project identifier */ appId, /** Cache identifier */ cacheid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_cachebyid_post(appId, cacheid, options), requestOptions);
        };
        V2Client.prototype.admin_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_config_get(options), requestOptions);
        };
        V2Client.prototype.admin_config_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_config_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.admin_packages_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_packages_get(options), requestOptions);
        };
        /** Returns the most recently recorded performance data. */
        V2Client.prototype.admin_performance_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_performance_get(options), requestOptions);
        };
        V2Client.prototype.admin_projects_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_projects_get(options), requestOptions);
        };
        V2Client.prototype.admin_status_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_status_get(options), requestOptions);
        };
        V2Client.prototype.admin_systeminfo_log_get = function (dir, file, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_log_get(dir, file, options), requestOptions);
        };
        V2Client.prototype.admin_systeminfo_log_live_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_log_live_get(options), requestOptions);
        };
        V2Client.prototype.admin_systeminfo_log_session_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_log_session_get(options), requestOptions);
        };
        V2Client.prototype.admin_systeminfo_logs_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_logs_get(options), requestOptions);
        };
        V2Client.prototype.admin_systeminfo_plugins_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_plugins_get(options), requestOptions);
        };
        V2Client.prototype.admin_systeminfo_software_status_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_software_status_get(options), requestOptions);
        };
        /** Starts the software update process */
        V2Client.prototype.admin_systeminfo_software_update_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.admin_systeminfo_software_update_post(options), requestOptions);
        };
        /** Returns the set of currently active endpoints, and a flag indicating whether an endpoint is active for the current user. */
        V2Client.prototype.imx_activeverbs_get = function (/** Name of the application */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_activeverbs_get(appId, options), requestOptions);
        };
        V2Client.prototype.imx_applications_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_applications_get(options), requestOptions);
        };
        V2Client.prototype.imx_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_config_get(options), requestOptions);
        };
        V2Client.prototype.imx_entityschema_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_entityschema_get(options), requestOptions);
        };
        V2Client.prototype.imx_help_context_get = function (/** Get help links for a help context */ helpcontextid, /** Language to use */ language, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_help_context_get(helpcontextid, language, options), requestOptions);
        };
        V2Client.prototype.imx_login_post = function (/** Name of the application */ appId, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_login_post(appId, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.imx_logout_post = function (/** Name of the application */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_logout_post(appId, options), requestOptions);
        };
        /** Returns metadata for a specific database table. */
        V2Client.prototype.imx_metadata_table_get = function (/** Name of the database table */ tableName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_metadata_table_get(tableName, options), requestOptions);
        };
        /** Returns the model-generated stylesheet. */
        V2Client.prototype.imx_modelcss_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_modelcss_get(options), requestOptions);
        };
        /** Returns an image stored from data model. */
        V2Client.prototype.imx_modelimage_get = function (key, size, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_modelimage_get(key, size, options), requestOptions);
        };
        /** Returns web UI translations for a specific culture. */
        V2Client.prototype.imx_multilanguage_getcaptions_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_multilanguage_getcaptions_get(options), requestOptions);
        };
        /** Returns translations for the data model for an API project. */
        V2Client.prototype.imx_multilanguage_translations_get = function (/** Name of the application */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_multilanguage_translations_get(appId, options), requestOptions);
        };
        /** Returns all cultures that are available to frontends. */
        V2Client.prototype.imx_multilanguage_uicultures_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_multilanguage_uicultures_get(options), requestOptions);
        };
        V2Client.prototype.imx_oauth_get = function (/** Name of the authentifier module */ authentifier, /** Name of the application */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_oauth_get(authentifier, appId, options), requestOptions);
        };
        /** Returns an object indicating whether this API server was able to start up and establish a database connection. */
        V2Client.prototype.imx_ping_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_ping_get(options), requestOptions);
        };
        V2Client.prototype.imx_sessions_get = function (/** Name of the application */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_sessions_get(appId, options), requestOptions);
        };
        V2Client.prototype.imx_sessions_info_get = function (/** Name of the application */ appId, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_sessions_info_get(appId, options), requestOptions);
        };
        V2Client.prototype.imx_system_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_system_get(options), requestOptions);
        };
        /** Returns a list of all third party components. */
        V2Client.prototype.imx_systeminfo_thirdparty_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_systeminfo_thirdparty_get(options), requestOptions);
        };
        V2Client.prototype.imx_themes_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.imx_themes_get(options), requestOptions);
        };
        /** Returns the objects that are part of assignment, specified by the assignment's 'table name and the uid. */
        V2Client.prototype.opsupport_assignment_get = function (/** Object table name */ tableName, /** Object primary keys, split by comma */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_assignment_get(tableName, uid, options), requestOptions);
        };
        /** Returns a list of candidate objects from the table DialogTimeZone. */
        V2Client.prototype.opsupport_candidates_DialogTimeZone_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_candidates_DialogTimeZone_get(options), requestOptions);
        };
        /** Returns data model information about query options for the candidates/DialogTimeZone endpoint. */
        V2Client.prototype.opsupport_candidates_DialogTimeZone_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_candidates_DialogTimeZone_datamodel_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/DialogTimeZone endpoint. */
        V2Client.prototype.opsupport_candidates_DialogTimeZone_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_candidates_DialogTimeZone_filtertree_post(inputParameterName, options), requestOptions);
        };
        /** Returns change operations by process ID */
        V2Client.prototype.opsupport_changeoperations_process_get = function (/** Process identifier */ processid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_changeoperations_process_get(processid, options), requestOptions);
        };
        /** Returns change operations by change type and/or by time frame. */
        V2Client.prototype.opsupport_changeoperations_time_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_changeoperations_time_get(options), requestOptions);
        };
        /** Returns change operations by user */
        V2Client.prototype.opsupport_changeoperations_user_get = function (/** User name */ username, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_changeoperations_user_get(username, options), requestOptions);
        };
        V2Client.prototype.opsupport_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_config_get(options), requestOptions);
        };
        /** Returns basic information about an object specified by the table name and the uid. */
        V2Client.prototype.opsupport_dbobject_get = function (/** Object table name */ tableName, /** Object primary keys, split by comma */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_dbobject_get(tableName, uid, options), requestOptions);
        };
        V2Client.prototype.opsupport_history_get = function (/** Object type */ table, /** Object GUID */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_history_get(table, uid, options), requestOptions);
        };
        V2Client.prototype.opsupport_history_comparison_get = function (/** Object type */ table, /** Object GUID */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_history_comparison_get(table, uid, options), requestOptions);
        };
        /** Returns the HyperView shape information for the specified object */
        V2Client.prototype.opsupport_hyperview_get = function (/** Table name of the object */ table, /** Comma-seperated primary keys of the object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_hyperview_get(table, uid, options), requestOptions);
        };
        V2Client.prototype.opsupport_jobserver_get = function (/** Server name */ server, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_jobserver_get(server, options), requestOptions);
        };
        V2Client.prototype.opsupport_jobservers_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_jobservers_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_jobservers_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_jobservers_put(inputParameterName, options), requestOptions);
        };
        /** Runs a connection check for the specified server. */
        V2Client.prototype.opsupport_jobservers_check_post = function (/** Unique server identifier */ uidserver, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_jobservers_check_post(uidserver, options), requestOptions);
        };
        V2Client.prototype.opsupport_jobservers_bulk_put = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_jobservers_bulk_put(inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the jobservers endpoint. */
        V2Client.prototype.opsupport_jobservers_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_jobservers_datamodel_get(options), requestOptions);
        };
        /** Returns entries in the journal, returning the newest entries first. */
        V2Client.prototype.opsupport_journal_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_journal_get(options), requestOptions);
        };
        /** Returns data model information about query options for the journal endpoint. */
        V2Client.prototype.opsupport_journal_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_journal_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_journal_stat_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_journal_stat_get(options), requestOptions);
        };
        /** Delete currentuser profile settings */
        V2Client.prototype.opsupport_profile_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_profile_get(options), requestOptions);
        };
        /** Updates the user profile with the specified settings. Null values will not delete existing values. */
        V2Client.prototype.opsupport_profile_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_profile_post(inputParameterName, options), requestOptions);
        };
        /** Delete currentuser profile settings */
        V2Client.prototype.opsupport_profile_delete = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_profile_delete(options), requestOptions);
        };
        /** Returns profile infromation for the current user. */
        V2Client.prototype.opsupport_profile_person_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_profile_person_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_projectconfig_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_projectconfig_get(options), requestOptions);
        };
        /** Returns the contents of the database queue. */
        V2Client.prototype.opsupport_queue_dbqueue_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_dbqueue_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_queue_frozenjobs_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_frozenjobs_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_queue_frozenjobsbyqueue_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_frozenjobsbyqueue_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_queue_jobaffects_get = function (UID_Job, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobaffects_get(UID_Job, options), requestOptions);
        };
        V2Client.prototype.opsupport_queue_jobchains_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobchains_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_queue_jobhistory_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobhistory_get(options), requestOptions);
        };
        /** Returns data model information about query options for the queue/jobhistory endpoint. */
        V2Client.prototype.opsupport_queue_jobhistory_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobhistory_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_queue_jobperformance_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobperformance_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_queue_jobperformancequeues_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobperformancequeues_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_queue_jobs_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobs_get(options), requestOptions);
        };
        /** Returns data model information about query options for the queue/jobs endpoint. */
        V2Client.prototype.opsupport_queue_jobs_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_jobs_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_queue_object_get = function (/** Table name of the object */ table, /** Primary key of the object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_object_get(table, uid, options), requestOptions);
        };
        V2Client.prototype.opsupport_queue_overview_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_overview_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_queue_overview_stream_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_overview_stream_get(options), requestOptions);
        };
        /** Reactivates a process where one of the process steps is in the FROZEN or OVERLIMIT state. */
        V2Client.prototype.opsupport_queue_reactivatejob_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_reactivatejob_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.opsupport_queue_tree_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_queue_tree_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_search_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_search_get(options), requestOptions);
        };
        /** Returns the list of tables that are included in the search index. */
        V2Client.prototype.opsupport_search_indexedtables_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_search_indexedtables_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_streamconfig_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_streamconfig_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_systemoverview_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_systemoverview_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_systemstatus_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_systemstatus_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_systemstatus_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_systemstatus_post(inputParameterName, options), requestOptions);
        };
        /** Returns the list of permissions groups that the current user is assigned to. */
        V2Client.prototype.opsupport_usergroups_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_usergroups_get(options), requestOptions);
        };
        V2Client.prototype.opsupport_webapplications_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.opsupport_webapplications_get(options), requestOptions);
        };
        V2Client.prototype.scim_v2_get = function (/** meta resource filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_get(filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2__search_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2__search_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2__search_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2__search_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_AccProduct_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_AccProduct_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_AccProduct_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_AccProduct_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_AccProductby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_AccProductby_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_AccProductby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_AccProductby_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_AccProductby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_AccProductby_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_AccProductby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_AccProductby_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Bulk_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Bulk_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Bulk_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Bulk_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_Department_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Department_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Department_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Department_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_Departmentby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Departmentby_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Departmentby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Departmentby_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Departmentby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Departmentby_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Departmentby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Departmentby_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Locality_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Locality_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Locality_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Locality_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_Localityby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Localityby_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Localityby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Localityby_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Localityby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Localityby_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Localityby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Localityby_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Me_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Me_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Me_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Me_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_Person_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Person_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Person_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Person_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_Personby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Personby_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Personby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Personby_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Personby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Personby_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Personby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Personby_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Profitcenter_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Profitcenter_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Profitcenter_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Profitcenter_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_Profitcenterby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Profitcenterby_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Profitcenterby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Profitcenterby_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Profitcenterby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Profitcenterby_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_Profitcenterby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Profitcenterby_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_ResourceTypes_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_ResourceTypes_get(options), requestOptions);
        };
        V2Client.prototype.scim_v2_Schemas_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_Schemas_get(options), requestOptions);
        };
        V2Client.prototype.scim_v2_ServiceProviderConfig_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_ServiceProviderConfig_get(options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsAccount_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccount_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsAccount_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccount_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsAccountby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountby_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsAccountby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountby_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsAccountby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountby_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsAccountby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountby_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsAccountB_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountB_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsAccountB_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountB_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsAccountBby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountBby_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsAccountBby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountBby_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsAccountBby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountBby_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsAccountBby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsAccountBby_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsContainerB_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsContainerB_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsContainerB_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsContainerB_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsContainerBby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsContainerBby_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsContainerBby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsContainerBby_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsContainerBby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsContainerBby_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsContainerBby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsContainerBby_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroup_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroup_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroup_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroup_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupby_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupby_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupby_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupby_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupBby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupBby_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupBby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupBby_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupBby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupBby_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupBby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupBby_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB1_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB1_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB1_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB1_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB1by_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB1by_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB1by_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB1by_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB1by_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB1by_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB1by_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB1by_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB2_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB2_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB2_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB2_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB2by_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB2by_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB2by_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB2by_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB2by_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB2by_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB2by_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB2by_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB3_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB3_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB3_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB3_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB3by_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB3by_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB3by_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB3by_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB3by_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB3by_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsGroupB3by_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsGroupB3by_id_patch(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsRootB_get = function (/** amount of requested elements per page */ count, /** index of first element (1-based) */ startIndex, /** requested properties */ attributes, /** element filter */ filter, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsRootB_get(count, startIndex, attributes, filter, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsRootB_post = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsRootB_post(options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsRootBby_id_get = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsRootBby_id_get(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsRootBby_id_delete = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsRootBby_id_delete(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsRootBby_id_put = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsRootBby_id_put(uid, options), requestOptions);
        };
        V2Client.prototype.scim_v2_UnsRootBby_id_patch = function (/** unique id of the requested object */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.scim_v2_UnsRootBby_id_patch(uid, options), requestOptions);
        };
        return V2Client;
    }());

    exports.ApiClientMethodFactory = ApiClientMethodFactory;
    exports.Client = Client;
    exports.ImxMultilanguageUicultures = ImxMultilanguageUicultures;
    exports.ImxMultilanguageUiculturesInteractive = ImxMultilanguageUiculturesInteractive;
    exports.ImxMultilanguageUiculturesWrapper = ImxMultilanguageUiculturesWrapper;
    exports.ImxSysteminfoThirdparty = ImxSysteminfoThirdparty;
    exports.ImxSysteminfoThirdpartyInteractive = ImxSysteminfoThirdpartyInteractive;
    exports.ImxSysteminfoThirdpartyWrapper = ImxSysteminfoThirdpartyWrapper;
    exports.OpsupportCandidatesDialogtimezone = OpsupportCandidatesDialogtimezone;
    exports.OpsupportCandidatesDialogtimezoneInteractive = OpsupportCandidatesDialogtimezoneInteractive;
    exports.OpsupportCandidatesDialogtimezoneWrapper = OpsupportCandidatesDialogtimezoneWrapper;
    exports.OpsupportJobservers = OpsupportJobservers;
    exports.OpsupportJobserversInteractive = OpsupportJobserversInteractive;
    exports.OpsupportJobserversWrapper = OpsupportJobserversWrapper;
    exports.OpsupportJournal = OpsupportJournal;
    exports.OpsupportJournalInteractive = OpsupportJournalInteractive;
    exports.OpsupportJournalWrapper = OpsupportJournalWrapper;
    exports.OpsupportQueueDbqueue = OpsupportQueueDbqueue;
    exports.OpsupportQueueDbqueueInteractive = OpsupportQueueDbqueueInteractive;
    exports.OpsupportQueueDbqueueWrapper = OpsupportQueueDbqueueWrapper;
    exports.OpsupportQueueFrozenjobs = OpsupportQueueFrozenjobs;
    exports.OpsupportQueueFrozenjobsInteractive = OpsupportQueueFrozenjobsInteractive;
    exports.OpsupportQueueFrozenjobsWrapper = OpsupportQueueFrozenjobsWrapper;
    exports.OpsupportQueueFrozenjobsbyqueue = OpsupportQueueFrozenjobsbyqueue;
    exports.OpsupportQueueFrozenjobsbyqueueInteractive = OpsupportQueueFrozenjobsbyqueueInteractive;
    exports.OpsupportQueueFrozenjobsbyqueueWrapper = OpsupportQueueFrozenjobsbyqueueWrapper;
    exports.OpsupportQueueJobaffects = OpsupportQueueJobaffects;
    exports.OpsupportQueueJobaffectsInteractive = OpsupportQueueJobaffectsInteractive;
    exports.OpsupportQueueJobaffectsWrapper = OpsupportQueueJobaffectsWrapper;
    exports.OpsupportQueueJobchains = OpsupportQueueJobchains;
    exports.OpsupportQueueJobchainsInteractive = OpsupportQueueJobchainsInteractive;
    exports.OpsupportQueueJobchainsWrapper = OpsupportQueueJobchainsWrapper;
    exports.OpsupportQueueJobhistory = OpsupportQueueJobhistory;
    exports.OpsupportQueueJobhistoryInteractive = OpsupportQueueJobhistoryInteractive;
    exports.OpsupportQueueJobhistoryWrapper = OpsupportQueueJobhistoryWrapper;
    exports.OpsupportQueueJobperformance = OpsupportQueueJobperformance;
    exports.OpsupportQueueJobperformanceInteractive = OpsupportQueueJobperformanceInteractive;
    exports.OpsupportQueueJobperformanceWrapper = OpsupportQueueJobperformanceWrapper;
    exports.OpsupportQueueJobs = OpsupportQueueJobs;
    exports.OpsupportQueueJobsInteractive = OpsupportQueueJobsInteractive;
    exports.OpsupportQueueJobsWrapper = OpsupportQueueJobsWrapper;
    exports.OpsupportQueueOverview = OpsupportQueueOverview;
    exports.OpsupportQueueOverviewInteractive = OpsupportQueueOverviewInteractive;
    exports.OpsupportQueueOverviewWrapper = OpsupportQueueOverviewWrapper;
    exports.OpsupportQueueTree = OpsupportQueueTree;
    exports.OpsupportQueueTreeInteractive = OpsupportQueueTreeInteractive;
    exports.OpsupportQueueTreeWrapper = OpsupportQueueTreeWrapper;
    exports.OpsupportSearchIndexedtables = OpsupportSearchIndexedtables;
    exports.OpsupportSearchIndexedtablesInteractive = OpsupportSearchIndexedtablesInteractive;
    exports.OpsupportSearchIndexedtablesWrapper = OpsupportSearchIndexedtablesWrapper;
    exports.OpsupportSystemoverview = OpsupportSystemoverview;
    exports.OpsupportSystemoverviewInteractive = OpsupportSystemoverviewInteractive;
    exports.OpsupportSystemoverviewWrapper = OpsupportSystemoverviewWrapper;
    exports.OpsupportWebapplications = OpsupportWebapplications;
    exports.OpsupportWebapplicationsInteractive = OpsupportWebapplicationsInteractive;
    exports.OpsupportWebapplicationsWrapper = OpsupportWebapplicationsWrapper;
    exports.TypedClient = TypedClient;
    exports.V2ApiClientMethodFactory = V2ApiClientMethodFactory;
    exports.V2Client = V2Client;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
