import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntitySchema, FilterData, FkProviderItem, InteractiveEntityData, InteractiveEntityWriteData, IReadValue, MethodDescriptor, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface HelpdeskConfig {
    /** Specify which file types are allowed for ticket attachments. Enter the the file types in the following format: .<file extension> */
    AttachmentFileTypes?: string[];
    /** Specify the maximum size of ticket attachments. */
    AttachmentMaxSize: number;
}
export interface StoredDirectoryInfo {
    Name?: string;
    Directories?: StoredSubDirectoryInfo[];
    Files?: StoredFileInfo[];
}
export interface StoredFileInfo {
    Name?: string;
    Size: number;
    LastUpdated: Date;
}
export interface StoredSubDirectoryInfo {
    Name?: string;
}
export declare class TypedClient {
    readonly PortalCalls: PortalCallsWrapper;
    readonly PortalCallsHistory: PortalCallsHistoryWrapper;
    readonly PortalCallsInteractive: PortalCallsInteractiveWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalCalls extends TypedEntity {
    readonly UID_PersonInTrouble: IReadValue<string>;
    readonly CallNumber: IReadValue<number>;
    readonly ActionHotline: IReadValue<string>;
    readonly UID_TroubleSeverity: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_PersonInTrouble' | 'CallNumber' | 'ActionHotline' | 'UID_TroubleSeverity'>;
}
/** @deprecated Use the PortalCalls type. */
export declare class PortalCallsInteractive extends PortalCalls {
}
export declare class PortalCallsHistory extends TypedEntity {
    readonly UID_TroubleTicket: IReadValue<string>;
    readonly UID_TroubleCallState: IReadValue<string>;
    readonly TroubleHistoryDate: IReadValue<Date>;
    readonly ObjectKeyPerson: IReadValue<string>;
    readonly ObjectKeySupporter: IReadValue<string>;
    readonly ActionHotline: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_TroubleTicket' | 'UID_TroubleCallState' | 'TroubleHistoryDate' | 'ObjectKeyPerson' | 'ObjectKeySupporter' | 'ActionHotline'>;
}
/** @deprecated Use the PortalCallsHistory type. */
export declare class PortalCallsHistoryInteractive extends PortalCallsHistory {
}
export declare class PortalCallsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_calls_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCalls, unknown>>;
}
export declare class PortalCallsHistoryWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_TroubleTicket: string, parametersOptional?: portal_calls_history_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCallsHistory, unknown>>;
}
export declare class PortalCallsInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalCalls, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCalls, unknown>>;
    Get_byid(UID_TroubleTicket: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCalls, unknown>>;
    Get(parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCalls, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_calls_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, scope: string, callstate: string): MethodDescriptor<EntityCollectionData>;
    portal_calls_attachments_directory_get(CallId: string): MethodDescriptor<StoredDirectoryInfo>;
    portal_calls_attachments_directory_bypath_get(CallId: string, path: string): MethodDescriptor<StoredDirectoryInfo>;
    portal_calls_attachments_directory_bypath_delete(CallId: string, path: string): MethodDescriptor<void>;
    portal_calls_attachments_directory_bypath_post(CallId: string, path: string): MethodDescriptor<void>;
    portal_calls_attachments_file_get(CallId: string, path: string): MethodDescriptor<void>;
    portal_calls_attachments_file_delete(CallId: string, path: string): MethodDescriptor<void>;
    portal_calls_attachments_file_post(CallId: string, path: string, inputParameterName: Blob): MethodDescriptor<void>;
    portal_calls_history_get(UID_TroubleTicket: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_calls_configuration_get(): MethodDescriptor<HelpdeskConfig>;
    portal_calls_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_calls_interactive_get(): MethodDescriptor<InteractiveEntityData>;
    portal_calls_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_calls_interactive_byid_get(UID_TroubleTicket: string): MethodDescriptor<InteractiveEntityData>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_calls_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, scope: string, callstate: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of all files in the root directory. */
    portal_calls_attachments_directory_get(CallId: string, requestOptions?: ApiRequestOptions): Promise<StoredDirectoryInfo>;
    /** Returns a list of all files in the specified directory. */
    portal_calls_attachments_directory_bypath_get(CallId: string, path: string, requestOptions?: ApiRequestOptions): Promise<StoredDirectoryInfo>;
    /** Provides access to call attachments */
    portal_calls_attachments_directory_bypath_delete(CallId: string, path: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Provides access to call attachments */
    portal_calls_attachments_directory_bypath_post(CallId: string, path: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Downloads the specified file. */
    portal_calls_attachments_file_get(CallId: string, path: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Deletes the specified file. */
    portal_calls_attachments_file_delete(CallId: string, path: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Uploads a new file. */
    portal_calls_attachments_file_post(CallId: string, path: string, inputParameterName: Blob, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_calls_history_get(UID_TroubleTicket: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_calls_configuration_get(requestOptions?: ApiRequestOptions): Promise<HelpdeskConfig>;
    /** Returns data model information about query options for the calls endpoint. */
    portal_calls_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_calls_interactive_get(requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_calls_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_calls_interactive_byid_get(UID_TroubleTicket: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
}
export interface portal_calls_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_MainTroubleTicket) */ ParentKey?: string;
    /** Call filter */ scope?: string;
    /** Filter by call state */ callstate?: string;
}
export interface portal_calls_history_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_calls_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export declare class V2ApiClientMethodFactory {
    portal_calls_get(options?: portal_calls_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_calls_attachments_directory_get(/** Unique call identifier */ CallId: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<StoredDirectoryInfo>;
    portal_calls_attachments_directory_bypath_get(/** Unique call identifier */ CallId: string, /** Path to a directory or a file */ path: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<StoredDirectoryInfo>;
    portal_calls_attachments_directory_bypath_delete(/** Unique call identifier */ CallId: string, /** Path to a directory or a file */ path: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_calls_attachments_directory_bypath_post(/** Unique call identifier */ CallId: string, /** Path to a directory or a file */ path: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_calls_attachments_file_get(/** Unique call identifier */ CallId: string, /** Path of the file */ path: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_calls_attachments_file_delete(/** Unique call identifier */ CallId: string, /** Path of the file */ path: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_calls_attachments_file_post(/** Unique call identifier */ CallId: string, /** Path of the file */ path: string, inputParameterName: Blob, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_calls_history_get(UID_TroubleTicket: string, options?: portal_calls_history_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_calls_configuration_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<HelpdeskConfig>;
    portal_calls_datamodel_get(options?: portal_calls_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_calls_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_calls_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_calls_interactive_byid_get(/** Primary key value UID_TroubleTicket */ UID_TroubleTicket: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_calls_get(options?: portal_calls_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of all files in the root directory. */
    portal_calls_attachments_directory_get(/** Unique call identifier */ CallId: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<StoredDirectoryInfo>;
    /** Returns a list of all files in the specified directory. */
    portal_calls_attachments_directory_bypath_get(/** Unique call identifier */ CallId: string, /** Path to a directory or a file */ path: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<StoredDirectoryInfo>;
    /** Provides access to call attachments */
    portal_calls_attachments_directory_bypath_delete(/** Unique call identifier */ CallId: string, /** Path to a directory or a file */ path: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Provides access to call attachments */
    portal_calls_attachments_directory_bypath_post(/** Unique call identifier */ CallId: string, /** Path to a directory or a file */ path: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Downloads the specified file. */
    portal_calls_attachments_file_get(/** Unique call identifier */ CallId: string, /** Path of the file */ path: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Deletes the specified file. */
    portal_calls_attachments_file_delete(/** Unique call identifier */ CallId: string, /** Path of the file */ path: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Uploads a new file. */
    portal_calls_attachments_file_post(/** Unique call identifier */ CallId: string, /** Path of the file */ path: string, inputParameterName: Blob, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_calls_history_get(UID_TroubleTicket: string, options?: portal_calls_history_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_calls_configuration_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<HelpdeskConfig>;
    /** Returns data model information about query options for the calls endpoint. */
    portal_calls_datamodel_get(options?: portal_calls_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_calls_interactive_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_calls_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_calls_interactive_byid_get(/** Primary key value UID_TroubleTicket */ UID_TroubleTicket: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
}
