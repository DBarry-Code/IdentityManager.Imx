import { DisplayColumns, WriteExtTypedEntity, ValType, TypedEntity, TypedEntityBuilder, InteractiveTypedEntityBuilder, EntityState, TimeZoneInfo, DisplayPattern, FkCandidateBuilder, MethodDefinition } from 'imx-qbm-dbts';

var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var TypedClient = /** @class */ (function () {
    function TypedClient(client, translationProvider) {
        this.PortalResourcesApplicationServiceitem = new PortalResourcesApplicationServiceitemWrapper(client, translationProvider);
        this.PortalResourcesApplicationServiceitemInteractive = new PortalResourcesApplicationServiceitemInteractiveWrapper(client, translationProvider);
        this.PortalResourcesApplicationsMembership = new PortalResourcesApplicationsMembershipWrapper(client, translationProvider);
        this.PortalRespApplication = new PortalRespApplicationWrapper(client, translationProvider);
        this.PortalRespApplicationInteractive = new PortalRespApplicationInteractiveWrapper(client, translationProvider);
        this.PortalShopConfigEntitlementsApplication = new PortalShopConfigEntitlementsApplicationWrapper(client, translationProvider);
    }
    return TypedClient;
}());
var PortalResourcesApplicationServiceitem = /** @class */ (function (_super) {
    __extends(PortalResourcesApplicationServiceitem, _super);
    function PortalResourcesApplicationServiceitem() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /** Returns the static compile time schema for this type. */
    PortalResourcesApplicationServiceitem.GetEntitySchema = function () {
        var columns = {};
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'AccProduct', Columns: columns };
    };
    return PortalResourcesApplicationServiceitem;
}(WriteExtTypedEntity));
/** @deprecated Use the PortalResourcesApplicationServiceitem type. */
var PortalResourcesApplicationServiceitemInteractive = /** @class */ (function (_super) {
    __extends(PortalResourcesApplicationServiceitemInteractive, _super);
    function PortalResourcesApplicationServiceitemInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalResourcesApplicationServiceitemInteractive;
}(PortalResourcesApplicationServiceitem));
var PortalResourcesApplicationsMembership = /** @class */ (function (_super) {
    __extends(PortalResourcesApplicationsMembership, _super);
    function PortalResourcesApplicationsMembership() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_Application = _this.GetEntityValue('UID_Application');
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.XOrigin = _this.GetEntityValue('XOrigin');
        _this.XDateInserted = _this.GetEntityValue('XDateInserted');
        _this.XIsInEffect = _this.GetEntityValue('XIsInEffect');
        _this.XMarkedForDeletion = _this.GetEntityValue('XMarkedForDeletion');
        _this.UID_Person = _this.GetEntityValue('UID_Person');
        _this.UID_PersonWantsOrg = _this.GetEntityValue('UID_PersonWantsOrg');
        _this.OrderState = _this.GetEntityValue('OrderState');
        _this.IsRequestCancellable = _this.GetEntityValue('IsRequestCancellable');
        _this.ValidUntil = _this.GetEntityValue('ValidUntil');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalResourcesApplicationsMembership.GetEntitySchema = function () {
        var columns = {
            'UID_Application': {
                ColumnName: 'UID_Application',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'XOrigin': {
                ColumnName: 'XOrigin',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'XDateInserted': {
                ColumnName: 'XDateInserted',
                Type: ValType.Date,
                IsReadOnly: true,
            },
            'XIsInEffect': {
                ColumnName: 'XIsInEffect',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'XMarkedForDeletion': {
                ColumnName: 'XMarkedForDeletion',
                Type: ValType.Int,
                IsReadOnly: true,
            },
            'UID_Person': {
                ColumnName: 'UID_Person',
                Type: ValType.String,
                IsReadOnly: false,
            },
            'UID_PersonWantsOrg': {
                ColumnName: 'UID_PersonWantsOrg',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'OrderState': {
                ColumnName: 'OrderState',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'IsRequestCancellable': {
                ColumnName: 'IsRequestCancellable',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
            'ValidUntil': {
                ColumnName: 'ValidUntil',
                Type: ValType.Date,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'PersonHasApp', Columns: columns };
    };
    return PortalResourcesApplicationsMembership;
}(TypedEntity));
/** @deprecated Use the PortalResourcesApplicationsMembership type. */
var PortalResourcesApplicationsMembershipInteractive = /** @class */ (function (_super) {
    __extends(PortalResourcesApplicationsMembershipInteractive, _super);
    function PortalResourcesApplicationsMembershipInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalResourcesApplicationsMembershipInteractive;
}(PortalResourcesApplicationsMembership));
var PortalRespApplication = /** @class */ (function (_super) {
    __extends(PortalRespApplication, _super);
    function PortalRespApplication() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.XObjectKey = _this.GetEntityValue('XObjectKey');
        _this.Requestable = _this.GetEntityValue('Requestable');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalRespApplication.GetEntitySchema = function () {
        var columns = {
            'XObjectKey': {
                ColumnName: 'XObjectKey',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'Requestable': {
                ColumnName: 'Requestable',
                Type: ValType.Bool,
                IsReadOnly: true,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'Application', Columns: columns };
    };
    return PortalRespApplication;
}(TypedEntity));
/** @deprecated Use the PortalRespApplication type. */
var PortalRespApplicationInteractive = /** @class */ (function (_super) {
    __extends(PortalRespApplicationInteractive, _super);
    function PortalRespApplicationInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalRespApplicationInteractive;
}(PortalRespApplication));
var PortalShopConfigEntitlementsApplication = /** @class */ (function (_super) {
    __extends(PortalShopConfigEntitlementsApplication, _super);
    function PortalShopConfigEntitlementsApplication() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.UID_ITShopOrg = _this.GetEntityValue('UID_ITShopOrg');
        _this.UID_Application = _this.GetEntityValue('UID_Application');
        return _this;
    }
    /** Returns the static compile time schema for this type. */
    PortalShopConfigEntitlementsApplication.GetEntitySchema = function () {
        var columns = {
            'UID_ITShopOrg': {
                ColumnName: 'UID_ITShopOrg',
                Type: ValType.String,
                IsReadOnly: true,
            },
            'UID_Application': {
                ColumnName: 'UID_Application',
                Type: ValType.String,
                IsReadOnly: false,
            },
        };
        columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
        columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
        return { TypeName: 'ITShopOrgHasApp', Columns: columns };
    };
    return PortalShopConfigEntitlementsApplication;
}(TypedEntity));
/** @deprecated Use the PortalShopConfigEntitlementsApplication type. */
var PortalShopConfigEntitlementsApplicationInteractive = /** @class */ (function (_super) {
    __extends(PortalShopConfigEntitlementsApplicationInteractive, _super);
    function PortalShopConfigEntitlementsApplicationInteractive() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return PortalShopConfigEntitlementsApplicationInteractive;
}(PortalShopConfigEntitlementsApplication));
var PortalResourcesApplicationServiceitemWrapper = /** @class */ (function () {
    function PortalResourcesApplicationServiceitemWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_resources_application_serviceitem_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalResourcesApplicationServiceitemWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/resources/application/serviceitem');
    };
    PortalResourcesApplicationServiceitemWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/resources/application/serviceitem');
            this.builder = new TypedEntityBuilder(PortalResourcesApplicationServiceitem, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalResourcesApplicationServiceitemWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resources_application_serviceitem_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalResourcesApplicationServiceitemWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resources_application_serviceitem_put(inputParameterName.ExtendedEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalResourcesApplicationServiceitemWrapper;
}());
var PortalResourcesApplicationServiceitemInteractiveWrapper = /** @class */ (function () {
    function PortalResourcesApplicationServiceitemInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_resources_application_serviceitem_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalResourcesApplicationServiceitemInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/resources/application/serviceitem/interactive');
    };
    PortalResourcesApplicationServiceitemInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/resources/application/serviceitem/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalResourcesApplicationServiceitem, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalResourcesApplicationServiceitemInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resources_application_serviceitem_interactive_put(inputParameterName.ExtendedInteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalResourcesApplicationServiceitemInteractiveWrapper.prototype.Get_byid = function (UID_AccProduct, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resources_application_serviceitem_interactive_byid_get(UID_AccProduct, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalResourcesApplicationServiceitemInteractiveWrapper;
}());
var PortalResourcesApplicationsMembershipWrapper = /** @class */ (function () {
    function PortalResourcesApplicationsMembershipWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            {
                return _this.client.portal_resources_applications_membership_post(entity.GetColumn('UID_Application').GetValue(), writeData);
            }
        };
        this.deleteMethod = function (entity) {
            return _this.client.portal_resources_applications_membership_delete(entity.GetColumn('UID_Application').GetValue(), entity.GetColumn('UID_Person').GetValue());
        };
    }
    PortalResourcesApplicationsMembershipWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalResourcesApplicationsMembershipWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/resources/applications/membership/{UID_Application}');
    };
    PortalResourcesApplicationsMembershipWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/resources/applications/membership/{UID_Application}');
            this.builder = new TypedEntityBuilder(PortalResourcesApplicationsMembership, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalResourcesApplicationsMembershipWrapper.prototype.Get = function (UID_Application, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resources_applications_membership_get(UID_Application, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalResourcesApplicationsMembershipWrapper.prototype.Post = function (UID_Application, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resources_applications_membership_post(UID_Application, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalResourcesApplicationsMembershipWrapper.prototype.Delete = function (UID_Application, UID_Person, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resources_applications_membership_delete(UID_Application, UID_Person, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalResourcesApplicationsMembershipWrapper;
}());
var PortalRespApplicationWrapper = /** @class */ (function () {
    function PortalRespApplicationWrapper(client, translationProvider) {
        this.client = client;
        this.translationProvider = translationProvider;
    }
    /** Returns the runtime schema for this method. */
    PortalRespApplicationWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/resp/application');
    };
    PortalRespApplicationWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/resp/application');
            this.builder = new TypedEntityBuilder(PortalRespApplication, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalRespApplicationWrapper.prototype.Get = function (parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resp_application_get(parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalRespApplicationWrapper;
}());
var PortalRespApplicationInteractiveWrapper = /** @class */ (function () {
    function PortalRespApplicationInteractiveWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            return _this.client.portal_resp_application_interactive_put(writeData);
        };
    }
    /** Returns the runtime schema for this method. */
    PortalRespApplicationInteractiveWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/resp/application/interactive');
    };
    PortalRespApplicationInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/resp/application/interactive');
            this.builder = new InteractiveTypedEntityBuilder(PortalRespApplication, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalRespApplicationInteractiveWrapper.prototype.Put = function (inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resp_application_interactive_put(inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalRespApplicationInteractiveWrapper.prototype.Get_byid = function (UID_Application, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_resp_application_interactive_byid_get(UID_Application, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalRespApplicationInteractiveWrapper;
}());
var PortalShopConfigEntitlementsApplicationWrapper = /** @class */ (function () {
    function PortalShopConfigEntitlementsApplicationWrapper(client, translationProvider) {
        var _this = this;
        this.client = client;
        this.translationProvider = translationProvider;
        this.commitMethod = function (entity, writeData) {
            {
                return _this.client.portal_shop_config_entitlements_Application_post(entity.GetColumn('UID_ITShopOrg').GetValue(), writeData);
            }
        };
        this.deleteMethod = function (entity) {
            return _this.client.portal_shop_config_entitlements_Application_delete(entity.GetColumn('UID_ITShopOrg').GetValue(), entity.GetColumn('UID_Application').GetValue());
        };
    }
    PortalShopConfigEntitlementsApplicationWrapper.prototype.createEntity = function (initialData) {
        this.buildBuilderIfNeeded();
        return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, EntityState.Created);
    };
    /** Returns the runtime schema for this method. */
    PortalShopConfigEntitlementsApplicationWrapper.prototype.GetSchema = function () {
        return this.client.getSchema('portal/shop/config/entitlements/{UID_ITShopOrg}/Application');
    };
    PortalShopConfigEntitlementsApplicationWrapper.prototype.buildBuilderIfNeeded = function () {
        if (!this.builder) {
            var fkProviderItems = this.client.getFkProviderItems('portal/shop/config/entitlements/{UID_ITShopOrg}/Application');
            this.builder = new TypedEntityBuilder(PortalShopConfigEntitlementsApplication, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
        }
    };
    PortalShopConfigEntitlementsApplicationWrapper.prototype.Get = function (UID_ITShopOrg, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_Application_get(UID_ITShopOrg, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalShopConfigEntitlementsApplicationWrapper.prototype.Post = function (UID_ITShopOrg, inputParameterName, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_Application_post(UID_ITShopOrg, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    PortalShopConfigEntitlementsApplicationWrapper.prototype.Delete = function (UID_ITShopOrg, UID_Application, parametersOptional, requestOpts) {
        if (parametersOptional === void 0) { parametersOptional = {}; }
        if (requestOpts === void 0) { requestOpts = {}; }
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.client.portal_shop_config_entitlements_Application_delete(UID_ITShopOrg, UID_Application, parametersOptional, requestOpts)];
                    case 1:
                        data = _a.sent();
                        this.buildBuilderIfNeeded();
                        return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                }
            });
        });
    };
    return PortalShopConfigEntitlementsApplicationWrapper;
}());
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
var ApiClientMethodFactory = /** @class */ (function () {
    function ApiClientMethodFactory() {
    }
    ApiClientMethodFactory.prototype.portal_resources_application_serviceitem_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/resources/application/serviceitem',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resources_application_serviceitem_put = function (inputParameterName) {
        return {
            path: '/portal/resources/application/serviceitem',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resources_application_serviceitem_bulk_put = function (inputParameterName) {
        return {
            path: '/portal/resources/application/serviceitem/bulk',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resources_application_serviceitem_datamodel_get = function (filter) {
        return {
            path: '/portal/resources/application/serviceitem/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resources_application_serviceitem_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/resources/application/serviceitem/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resources_application_serviceitem_interactive_byid_get = function (UID_AccProduct) {
        return {
            path: '/portal/resources/application/serviceitem/interactive/{UID_AccProduct}',
            parameters: [
                {
                    name: 'UID_AccProduct',
                    value: UID_AccProduct,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resources_applications_membership_get = function (UID_Application, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/resources/applications/membership/{UID_Application}',
            parameters: [
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resources_applications_membership_post = function (UID_Application, inputParameterName) {
        return {
            path: '/portal/resources/applications/membership/{UID_Application}',
            parameters: [
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resources_applications_membership_delete = function (UID_Application, UID_Person) {
        return {
            path: '/portal/resources/applications/membership/{UID_Application}/{UID_Person}',
            parameters: [
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_Person',
                    value: UID_Person,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resources_applications_membership_UID_Person_candidates_get = function (UID_Application, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/resources/applications/membership/{UID_Application}/UID_Person/candidates',
            parameters: [
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resources_applications_membership_UID_Person_candidates_filtertree_post = function (UID_Application, xorigin, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/resources/applications/membership/{UID_Application}/UID_Person/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'xorigin',
                    value: xorigin,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resp_application_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published) {
        return {
            path: '/portal/resp/application',
            parameters: [
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
                {
                    name: 'published',
                    value: published,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resp_application_datamodel_get = function (filter) {
        return {
            path: '/portal/resp/application/datamodel',
            parameters: [
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resp_application_interactive_put = function (inputParameterName) {
        return {
            path: '/portal/resp/application/interactive',
            parameters: [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_resp_application_interactive_byid_get = function (UID_Application) {
        return {
            path: '/portal/resp/application/interactive/{UID_Application}',
            parameters: [
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_Application_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/Application',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_Application_post = function (UID_ITShopOrg, inputParameterName) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/Application',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_Application_delete = function (UID_ITShopOrg, UID_Application) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/Application/{UID_Application}',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
            ],
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_Application_UID_Application_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'OrderBy',
                    value: OrderBy,
                    in: 'query'
                },
                {
                    name: 'StartIndex',
                    value: StartIndex,
                    in: 'query'
                },
                {
                    name: 'PageSize',
                    value: PageSize,
                    in: 'query'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'withProperties',
                    value: withProperties,
                    in: 'query'
                },
                {
                    name: 'search',
                    value: search,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get = function (UID_ITShopOrg, filter) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates/datamodel',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
            ],
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    ApiClientMethodFactory.prototype.portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName) {
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates/filtertree',
            parameters: [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'filter',
                    value: filter,
                    in: 'query'
                },
                {
                    name: 'parentkey',
                    value: parentkey,
                    in: 'query'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ],
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return ApiClientMethodFactory;
}());
/** @deprecated Use the V2Client class for a stable method interface. */
var Client = /** @class */ (function () {
    function Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    Client.prototype.portal_resources_application_serviceitem_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_application_serviceitem_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_resources_application_serviceitem_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_application_serviceitem_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_resources_application_serviceitem_bulk_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_application_serviceitem_bulk_put(inputParameterName), requestOptions);
    };
    /** Returns data model information about query options for the resources/application/serviceitem endpoint. */
    Client.prototype.portal_resources_application_serviceitem_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_application_serviceitem_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_resources_application_serviceitem_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_application_serviceitem_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_resources_application_serviceitem_interactive_byid_get = function (UID_AccProduct, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_application_serviceitem_interactive_byid_get(UID_AccProduct), requestOptions);
    };
    Client.prototype.portal_resources_applications_membership_get = function (UID_Application, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_applications_membership_get(UID_Application, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_resources_applications_membership_post = function (UID_Application, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_applications_membership_post(UID_Application, inputParameterName), requestOptions);
    };
    Client.prototype.portal_resources_applications_membership_delete = function (UID_Application, UID_Person, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_applications_membership_delete(UID_Application, UID_Person), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    Client.prototype.portal_resources_applications_membership_UID_Person_candidates_get = function (UID_Application, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_applications_membership_UID_Person_candidates_get(UID_Application, xorigin, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns filter tree information for the resources/applications/membership/{UID_Application}/UID_Person/candidates endpoint. */
    Client.prototype.portal_resources_applications_membership_UID_Person_candidates_filtertree_post = function (UID_Application, xorigin, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_applications_membership_UID_Person_candidates_filtertree_post(UID_Application, xorigin, filter, parentkey, inputParameterName), requestOptions);
    };
    Client.prototype.portal_resp_application_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, published, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_application_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, published), requestOptions);
    };
    /** Returns data model information about query options for the resp/application endpoint. */
    Client.prototype.portal_resp_application_datamodel_get = function (filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_application_datamodel_get(filter), requestOptions);
    };
    Client.prototype.portal_resp_application_interactive_put = function (inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_application_interactive_put(inputParameterName), requestOptions);
    };
    Client.prototype.portal_resp_application_interactive_byid_get = function (UID_Application, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_application_interactive_byid_get(UID_Application), requestOptions);
    };
    Client.prototype.portal_shop_config_entitlements_Application_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_Application_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    Client.prototype.portal_shop_config_entitlements_Application_post = function (UID_ITShopOrg, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_Application_post(UID_ITShopOrg, inputParameterName), requestOptions);
    };
    Client.prototype.portal_shop_config_entitlements_Application_delete = function (UID_ITShopOrg, UID_Application, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_Application_delete(UID_ITShopOrg, UID_Application), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_Application. */
    Client.prototype.portal_shop_config_entitlements_Application_UID_Application_candidates_get = function (UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_Application_UID_Application_candidates_get(UID_ITShopOrg, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get = function (UID_ITShopOrg, filter, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get(UID_ITShopOrg, filter), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates endpoint. */
    Client.prototype.portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post = function (UID_ITShopOrg, filter, parentkey, inputParameterName, requestOptions) {
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post(UID_ITShopOrg, filter, parentkey, inputParameterName), requestOptions);
    };
    return Client;
}());
var V2ApiClientMethodFactory = /** @class */ (function () {
    function V2ApiClientMethodFactory() {
    }
    V2ApiClientMethodFactory.prototype.portal_resources_application_serviceitem_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resources/application/serviceitem',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resources_application_serviceitem_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resources/application/serviceitem',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resources_application_serviceitem_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resources/application/serviceitem/bulk',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resources_application_serviceitem_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resources/application/serviceitem/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resources_application_serviceitem_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resources/application/serviceitem/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resources_application_serviceitem_interactive_byid_get = function (/** Primary key value UID_AccProduct */ UID_AccProduct, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resources/application/serviceitem/interactive/{UID_AccProduct}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_AccProduct',
                    value: UID_AccProduct,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resources_applications_membership_get = function (/** Unique identifier of the application */ UID_Application, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resources/applications/membership/{UID_Application}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resources_applications_membership_post = function (/** Unique identifier of the application */ UID_Application, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resources/applications/membership/{UID_Application}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resources_applications_membership_delete = function (/** Unique identifier of the application */ UID_Application, /** Identity */ UID_Person, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resources/applications/membership/{UID_Application}/{UID_Person}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_Person',
                    value: UID_Person,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resources_applications_membership_UID_Person_candidates_get = function (/** Unique identifier of the application */ UID_Application, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resources/applications/membership/{UID_Application}/UID_Person/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resources_applications_membership_UID_Person_candidates_filtertree_post = function (/** Unique identifier of the application */ UID_Application, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resources/applications/membership/{UID_Application}/UID_Person/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resp_application_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resp/application',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resp_application_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resp/application/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, []),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resp_application_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resp/application/interactive',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'PUT',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_resp_application_interactive_byid_get = function (/** Primary key value UID_Application */ UID_Application, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/resp/application/interactive/{UID_Application}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_Application_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/Application',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_Application_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/Application',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_Application_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** Software */ UID_Application, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/Application/{UID_Application}',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'UID_Application',
                    value: UID_Application,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'DELETE',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_Application_UID_Application_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates/datamodel',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
            ]),
            method: 'GET',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    V2ApiClientMethodFactory.prototype.portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        return {
            path: '/portal/shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates/filtertree',
            parameters: MethodDefinition.MakeQueryParameters(options, [
                {
                    name: 'UID_ITShopOrg',
                    value: UID_ITShopOrg,
                    required: true,
                    in: 'path'
                },
                {
                    name: 'inputParameterName',
                    value: inputParameterName,
                    required: true,
                    in: 'body'
                },
            ]),
            method: 'POST',
            headers: {
                'imx-timezone': TimeZoneInfo.get(),
            },
            credentials: 'include',
            observe: 'response',
            responseType: 'json'
        };
    };
    return V2ApiClientMethodFactory;
}());
var V2Client = /** @class */ (function () {
    function V2Client(apiClient, schemaProvider) {
        this.apiClient = apiClient;
        this.schemaProvider = schemaProvider;
        this.methodFactory = new V2ApiClientMethodFactory();
        if (!apiClient) {
            throw new Error("The value for the apiClient parameter is undefined.");
        }
    }
    Object.defineProperty(V2Client.prototype, "schemas", {
        get: function () {
            if (!this.schemaProvider) {
                throw new Error("The schema has not been loaded.");
            }
            return this.schemaProvider.schemas;
        },
        enumerable: false,
        configurable: true
    });
    V2Client.prototype.loadSchema = function (language) {
        return __awaiter(this, void 0, void 0, function () {
            var headers, dtos, schemas, key, dto, columns;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        headers = {};
                        if (language)
                            headers['Accept-Language'] = language;
                        return [4 /*yield*/, this.apiClient.processRequest({
                                path: '/imx/entityschema',
                                parameters: [],
                                method: 'GET',
                                headers: headers,
                                credentials: 'include',
                                observe: 'response',
                                responseType: 'json'
                            })];
                    case 1:
                        dtos = _a.sent();
                        schemas = {};
                        for (key in dtos) {
                            dto = dtos[key];
                            columns = dto.Properties;
                            columns[DisplayColumns.DISPLAY_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY;
                            columns[DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = DisplayColumns.DISPLAY_PROPERTY_LONG;
                            schemas[key] = {
                                TypeName: dto.TypeName,
                                DisplayPattern: new DisplayPattern(dto.DisplayPattern),
                                Display: dto.Display,
                                DisplaySingular: dto.DisplaySingular,
                                FkCandidateRoutes: dto.FkCandidateRoutes,
                                Columns: columns
                            };
                        }
                        this.schemaProvider = { schemas: schemas };
                        return [2 /*return*/];
                }
            });
        });
    };
    V2Client.prototype.getFkProviderItems = function (methodKey) {
        var _a;
        return new FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
    };
    /** Returns the runtime schema for the named method. */
    V2Client.prototype.getSchema = function (methodKey) {
        var result = this.schemas[methodKey];
        if (!result)
            throw new Error('Unknown method: ' + methodKey);
        return result;
    };
    V2Client.prototype.portal_resources_application_serviceitem_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_application_serviceitem_get(options), requestOptions);
    };
    V2Client.prototype.portal_resources_application_serviceitem_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_application_serviceitem_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_resources_application_serviceitem_bulk_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_application_serviceitem_bulk_put(inputParameterName, options), requestOptions);
    };
    /** Returns data model information about query options for the resources/application/serviceitem endpoint. */
    V2Client.prototype.portal_resources_application_serviceitem_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_application_serviceitem_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_resources_application_serviceitem_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_application_serviceitem_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_resources_application_serviceitem_interactive_byid_get = function (/** Primary key value UID_AccProduct */ UID_AccProduct, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_application_serviceitem_interactive_byid_get(UID_AccProduct, options), requestOptions);
    };
    V2Client.prototype.portal_resources_applications_membership_get = function (/** Unique identifier of the application */ UID_Application, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_applications_membership_get(UID_Application, options), requestOptions);
    };
    V2Client.prototype.portal_resources_applications_membership_post = function (/** Unique identifier of the application */ UID_Application, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_applications_membership_post(UID_Application, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_resources_applications_membership_delete = function (/** Unique identifier of the application */ UID_Application, /** Identity */ UID_Person, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_applications_membership_delete(UID_Application, UID_Person, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_Person. */
    V2Client.prototype.portal_resources_applications_membership_UID_Person_candidates_get = function (/** Unique identifier of the application */ UID_Application, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_applications_membership_UID_Person_candidates_get(UID_Application, options), requestOptions);
    };
    /** Returns filter tree information for the resources/applications/membership/{UID_Application}/UID_Person/candidates endpoint. */
    V2Client.prototype.portal_resources_applications_membership_UID_Person_candidates_filtertree_post = function (/** Unique identifier of the application */ UID_Application, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resources_applications_membership_UID_Person_candidates_filtertree_post(UID_Application, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_resp_application_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_application_get(options), requestOptions);
    };
    /** Returns data model information about query options for the resp/application endpoint. */
    V2Client.prototype.portal_resp_application_datamodel_get = function (options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_application_datamodel_get(options), requestOptions);
    };
    V2Client.prototype.portal_resp_application_interactive_put = function (inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_application_interactive_put(inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_resp_application_interactive_byid_get = function (/** Primary key value UID_Application */ UID_Application, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_resp_application_interactive_byid_get(UID_Application, options), requestOptions);
    };
    V2Client.prototype.portal_shop_config_entitlements_Application_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_Application_get(UID_ITShopOrg, options), requestOptions);
    };
    V2Client.prototype.portal_shop_config_entitlements_Application_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_Application_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
    };
    V2Client.prototype.portal_shop_config_entitlements_Application_delete = function (/** Unique identifier of the shelf */ UID_ITShopOrg, /** Software */ UID_Application, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_Application_delete(UID_ITShopOrg, UID_Application, options), requestOptions);
    };
    /** Returns a list of objects that can be assigned to the property UID_Application. */
    V2Client.prototype.portal_shop_config_entitlements_Application_UID_Application_candidates_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_Application_UID_Application_candidates_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get = function (/** Unique identifier of the shelf */ UID_ITShopOrg, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_Application_UID_Application_candidates_datamodel_get(UID_ITShopOrg, options), requestOptions);
    };
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/Application/UID_Application/candidates endpoint. */
    V2Client.prototype.portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post = function (/** Unique identifier of the shelf */ UID_ITShopOrg, inputParameterName, options, requestOptions) {
        if (options === void 0) { options = {}; }
        if (requestOptions === void 0) { requestOptions = {}; }
        return this.apiClient.processRequest(this.methodFactory.portal_shop_config_entitlements_Application_UID_Application_candidates_filtertree_post(UID_ITShopOrg, inputParameterName, options), requestOptions);
    };
    return V2Client;
}());

export { ApiClientMethodFactory, Client, PortalResourcesApplicationServiceitem, PortalResourcesApplicationServiceitemInteractive, PortalResourcesApplicationServiceitemInteractiveWrapper, PortalResourcesApplicationServiceitemWrapper, PortalResourcesApplicationsMembership, PortalResourcesApplicationsMembershipInteractive, PortalResourcesApplicationsMembershipWrapper, PortalRespApplication, PortalRespApplicationInteractive, PortalRespApplicationInteractiveWrapper, PortalRespApplicationWrapper, PortalShopConfigEntitlementsApplication, PortalShopConfigEntitlementsApplicationInteractive, PortalShopConfigEntitlementsApplicationWrapper, TypedClient, V2ApiClientMethodFactory, V2Client };
