import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntitySchema, EntityWriteData, EntityWriteDataColumn, EntityWriteDataSingle, ExtendedEntityWriteData, FilterData, FilterTreeData, FkProviderItem, InteractiveEntityData, InteractiveEntityWriteData, IReadValue, IWriteValue, MethodDescriptor, StaticSchema, TypedEntity, WriteExtTypedEntity } from 'imx-qbm-dbts';
export interface AccProductOwnershipInput {
    UidPerson?: string;
    CopyAllMembers: boolean;
}
export interface AssignConfig {
    AssignmentTableName?: string;
    GroupColumnName?: string;
}
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityWriteDataOfAccProductOwnershipInput extends EntityWriteData {
    ExtendedData?: AccProductOwnershipInput;
}
export interface ExtendedEntityWriteDataOfGroupExtendedData extends EntityWriteData {
    ExtendedData?: GroupExtendedData;
}
export interface ExtendedInteractiveEntityWriteDataOfAccProductOwnershipInput extends InteractiveEntityWriteData {
    ExtendedData?: AccProductOwnershipInput;
}
export interface ExtendedInteractiveEntityWriteDataOfGroupExtendedData extends InteractiveEntityWriteData {
    ExtendedData?: GroupExtendedData;
}
export interface GroupExtendedData {
    CreateServiceItem: boolean;
}
export interface TsbUserConfig {
    CanClaimGroup: boolean;
}
export interface UnsConfig {
    GroupTables?: string[];
    GroupInGroupTables?: string[];
    AccountTables?: string[];
    ContainerTables?: string[];
    ItemTables?: string[];
    ShopAssign?: {
        [key: string]: AssignConfig;
    };
}
export declare class TypedClient {
    readonly PortalCandidatesAccproductgroup: PortalCandidatesAccproductgroupWrapper;
    readonly PortalCandidatesAccproductparamcategory: PortalCandidatesAccproductparamcategoryWrapper;
    readonly PortalClaimgroupGroup: PortalClaimgroupGroupWrapper;
    readonly PortalClaimgroupSuggestedowner: PortalClaimgroupSuggestedownerWrapper;
    readonly PortalClaimgroupSuggestedowner2: PortalClaimgroupSuggestedowner2Wrapper;
    readonly PortalPersonAccounts: PortalPersonAccountsWrapper;
    readonly PortalPersonGroupmemberships: PortalPersonGroupmembershipsWrapper;
    readonly PortalRespUnsgroup: PortalRespUnsgroupWrapper;
    readonly PortalRespUnsgroupb: PortalRespUnsgroupbWrapper;
    readonly PortalRespUnsgroupb1: PortalRespUnsgroupb1Wrapper;
    readonly PortalRespUnsgroupb1Interactive: PortalRespUnsgroupb1InteractiveWrapper;
    readonly PortalRespUnsgroupb2: PortalRespUnsgroupb2Wrapper;
    readonly PortalRespUnsgroupb2Interactive: PortalRespUnsgroupb2InteractiveWrapper;
    readonly PortalRespUnsgroupb3: PortalRespUnsgroupb3Wrapper;
    readonly PortalRespUnsgroupb3Interactive: PortalRespUnsgroupb3InteractiveWrapper;
    readonly PortalRespUnsgroupbInteractive: PortalRespUnsgroupbInteractiveWrapper;
    readonly PortalShopConfigEntitlementsTsbaccountdef: PortalShopConfigEntitlementsTsbaccountdefWrapper;
    readonly PortalShopConfigEntitlementsUnsgroupb: PortalShopConfigEntitlementsUnsgroupbWrapper;
    readonly PortalShopConfigEntitlementsUnsgroupb1: PortalShopConfigEntitlementsUnsgroupb1Wrapper;
    readonly PortalShopConfigEntitlementsUnsgroupb2: PortalShopConfigEntitlementsUnsgroupb2Wrapper;
    readonly PortalShopConfigEntitlementsUnsgroupb3: PortalShopConfigEntitlementsUnsgroupb3Wrapper;
    readonly PortalTargetsystemUnsAccount: PortalTargetsystemUnsAccountWrapper;
    readonly PortalTargetsystemUnsaccountb: PortalTargetsystemUnsaccountbWrapper;
    readonly PortalTargetsystemUnsaccountbInteractive: PortalTargetsystemUnsaccountbInteractiveWrapper;
    readonly PortalTargetsystemUnsContainer: PortalTargetsystemUnsContainerWrapper;
    readonly PortalTargetsystemUnscontainerb: PortalTargetsystemUnscontainerbWrapper;
    readonly PortalTargetsystemUnscontainerbInteractive: PortalTargetsystemUnscontainerbInteractiveWrapper;
    readonly PortalTargetsystemUnsDirectmembers: PortalTargetsystemUnsDirectmembersWrapper;
    readonly PortalTargetsystemUnsGroup: PortalTargetsystemUnsGroupWrapper;
    readonly PortalTargetsystemUnsgroupb: PortalTargetsystemUnsgroupbWrapper;
    readonly PortalTargetsystemUnsgroupb1: PortalTargetsystemUnsgroupb1Wrapper;
    readonly PortalTargetsystemUnsgroupb1Interactive: PortalTargetsystemUnsgroupb1InteractiveWrapper;
    readonly PortalTargetsystemUnsgroupb2: PortalTargetsystemUnsgroupb2Wrapper;
    readonly PortalTargetsystemUnsgroupb2Interactive: PortalTargetsystemUnsgroupb2InteractiveWrapper;
    readonly PortalTargetsystemUnsgroupb3: PortalTargetsystemUnsgroupb3Wrapper;
    readonly PortalTargetsystemUnsgroupb3Interactive: PortalTargetsystemUnsgroupb3InteractiveWrapper;
    readonly PortalTargetsystemUnsgroupbInteractive: PortalTargetsystemUnsgroupbInteractiveWrapper;
    readonly PortalTargetsystemUnsGroupmembers: PortalTargetsystemUnsGroupmembersWrapper;
    readonly PortalTargetsystemUnsGroupServiceitem: PortalTargetsystemUnsGroupServiceitemWrapper;
    readonly PortalTargetsystemUnsGroupServiceitemInteractive: PortalTargetsystemUnsGroupServiceitemInteractiveWrapper;
    readonly PortalTargetsystemUnsitemb: PortalTargetsystemUnsitembWrapper;
    readonly PortalTargetsystemUnsitembInteractive: PortalTargetsystemUnsitembInteractiveWrapper;
    readonly PortalTargetsystemUnsNestedmembers: PortalTargetsystemUnsNestedmembersWrapper;
    readonly PortalTargetsystemUnsSystem: PortalTargetsystemUnsSystemWrapper;
    readonly PortalUnsgroupb1Memberships: PortalUnsgroupb1MembershipsWrapper;
    readonly PortalUnsgroupb2Memberships: PortalUnsgroupb2MembershipsWrapper;
    readonly PortalUnsgroupb3Memberships: PortalUnsgroupb3MembershipsWrapper;
    readonly PortalUnsgroupbMemberships: PortalUnsgroupbMembershipsWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalCandidatesAccproductgroup extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AccProductGroup: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AccProductGroup'>;
}
/** @deprecated Use the PortalCandidatesAccproductgroup type. */
export declare class PortalCandidatesAccproductgroupInteractive extends PortalCandidatesAccproductgroup {
}
export declare class PortalCandidatesAccproductparamcategory extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_AccProductParamCategory: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_AccProductParamCategory'>;
}
/** @deprecated Use the PortalCandidatesAccproductparamcategory type. */
export declare class PortalCandidatesAccproductparamcategoryInteractive extends PortalCandidatesAccproductparamcategory {
}
export declare class PortalClaimgroupGroup extends TypedEntity {
    readonly Description: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'Description' | 'XObjectKey'>;
}
/** @deprecated Use the PortalClaimgroupGroup type. */
export declare class PortalClaimgroupGroupInteractive extends PortalClaimgroupGroup {
}
export declare class PortalClaimgroupSuggestedowner extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress'>;
}
/** @deprecated Use the PortalClaimgroupSuggestedowner type. */
export declare class PortalClaimgroupSuggestedownerInteractive extends PortalClaimgroupSuggestedowner {
}
export declare class PortalClaimgroupSuggestedowner2 extends TypedEntity {
    readonly DefaultEmailAddress: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'DefaultEmailAddress'>;
}
/** @deprecated Use the PortalClaimgroupSuggestedowner2 type. */
export declare class PortalClaimgroupSuggestedowner2Interactive extends PortalClaimgroupSuggestedowner2 {
}
export declare class PortalPersonAccounts extends TypedEntity {
    readonly AccountName: IReadValue<string>;
    readonly CanonicalName: IReadValue<string>;
    readonly UID_DPRNameSpace: IReadValue<string>;
    readonly UID_UNSRoot: IReadValue<string>;
    readonly AccountDisabled: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'AccountName' | 'CanonicalName' | 'UID_DPRNameSpace' | 'UID_UNSRoot' | 'AccountDisabled' | 'XMarkedForDeletion'>;
}
/** @deprecated Use the PortalPersonAccounts type. */
export declare class PortalPersonAccountsInteractive extends PortalPersonAccounts {
}
export declare class PortalPersonGroupmemberships extends TypedEntity {
    readonly XOrigin: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroup: IReadValue<string>;
    readonly UID_UNSRoot: IReadValue<string>;
    readonly ObjectKeyGroup: IReadValue<string>;
    readonly IsFromDynamic: IReadValue<boolean>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XOrigin' | 'XObjectKey' | 'XMarkedForDeletion' | 'XDateInserted' | 'UID_UNSAccount' | 'UID_UNSGroup' | 'UID_UNSRoot' | 'ObjectKeyGroup' | 'IsFromDynamic' | 'OrderState' | 'ValidUntil'>;
}
/** @deprecated Use the PortalPersonGroupmemberships type. */
export declare class PortalPersonGroupmembershipsInteractive extends PortalPersonGroupmemberships {
}
export declare class PortalRespUnsgroup extends TypedEntity {
    readonly UID_AccProduct: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly DistinguishedName: IReadValue<string>;
    readonly GroupType: IReadValue<string>;
    readonly UID_UNSRoot: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'Description' | 'DistinguishedName' | 'GroupType' | 'UID_UNSRoot' | 'XObjectKey' | 'Requestable'>;
}
/** @deprecated Use the PortalRespUnsgroup type. */
export declare class PortalRespUnsgroupInteractive extends PortalRespUnsgroup {
}
export declare class PortalRespUnsgroupb extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalRespUnsgroupb type. */
export declare class PortalRespUnsgroupbInteractive extends PortalRespUnsgroupb {
}
export declare class PortalRespUnsgroupb1 extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalRespUnsgroupb1 type. */
export declare class PortalRespUnsgroupb1Interactive extends PortalRespUnsgroupb1 {
}
export declare class PortalRespUnsgroupb2 extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalRespUnsgroupb2 type. */
export declare class PortalRespUnsgroupb2Interactive extends PortalRespUnsgroupb2 {
}
export declare class PortalRespUnsgroupb3 extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalRespUnsgroupb3 type. */
export declare class PortalRespUnsgroupb3Interactive extends PortalRespUnsgroupb3 {
}
export declare class PortalShopConfigEntitlementsTsbaccountdef extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_TSBAccountDef: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_TSBAccountDef'>;
}
/** @deprecated Use the PortalShopConfigEntitlementsTsbaccountdef type. */
export declare class PortalShopConfigEntitlementsTsbaccountdefInteractive extends PortalShopConfigEntitlementsTsbaccountdef {
}
export declare class PortalShopConfigEntitlementsUnsgroupb extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_UNSGroupB: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_UNSGroupB'>;
}
/** @deprecated Use the PortalShopConfigEntitlementsUnsgroupb type. */
export declare class PortalShopConfigEntitlementsUnsgroupbInteractive extends PortalShopConfigEntitlementsUnsgroupb {
}
export declare class PortalShopConfigEntitlementsUnsgroupb1 extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_UNSGroupB1: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_UNSGroupB1'>;
}
/** @deprecated Use the PortalShopConfigEntitlementsUnsgroupb1 type. */
export declare class PortalShopConfigEntitlementsUnsgroupb1Interactive extends PortalShopConfigEntitlementsUnsgroupb1 {
}
export declare class PortalShopConfigEntitlementsUnsgroupb2 extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_UNSGroupB2: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_UNSGroupB2'>;
}
/** @deprecated Use the PortalShopConfigEntitlementsUnsgroupb2 type. */
export declare class PortalShopConfigEntitlementsUnsgroupb2Interactive extends PortalShopConfigEntitlementsUnsgroupb2 {
}
export declare class PortalShopConfigEntitlementsUnsgroupb3 extends TypedEntity {
    readonly UID_ITShopOrg: IReadValue<string>;
    readonly UID_UNSGroupB3: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_ITShopOrg' | 'UID_UNSGroupB3'>;
}
/** @deprecated Use the PortalShopConfigEntitlementsUnsgroupb3 type. */
export declare class PortalShopConfigEntitlementsUnsgroupb3Interactive extends PortalShopConfigEntitlementsUnsgroupb3 {
}
export declare class PortalTargetsystemUnsAccount extends TypedEntity {
    readonly AccountDisabled: IReadValue<boolean>;
    readonly AccountExpires: IReadValue<Date>;
    readonly AccountName: IReadValue<string>;
    readonly CanonicalName: IReadValue<string>;
    readonly cn: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly DistinguishedName: IReadValue<string>;
    readonly FirstName: IReadValue<string>;
    readonly IdentityType: IReadValue<string>;
    readonly IsGroupAccount: IReadValue<boolean>;
    readonly IsPrivilegedAccount: IReadValue<boolean>;
    readonly LastLogon: IReadValue<Date>;
    readonly LastName: IReadValue<string>;
    readonly MatchPatternForMembership: IReadValue<number>;
    readonly NeverConnectToPerson: IReadValue<number>;
    readonly ObjectGUID: IReadValue<string>;
    readonly PWDLastSet: IReadValue<Date>;
    readonly RiskIndexCalculated: IReadValue<number>;
    readonly UID_DPRNameSpace: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly UID_TSBAccountDef: IReadValue<string>;
    readonly UID_TSBBehavior: IReadValue<string>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSContainer: IReadValue<string>;
    readonly UID_UNSRoot: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'AccountDisabled' | 'AccountExpires' | 'AccountName' | 'CanonicalName' | 'cn' | 'Description' | 'DistinguishedName' | 'FirstName' | 'IdentityType' | 'IsGroupAccount' | 'IsPrivilegedAccount' | 'LastLogon' | 'LastName' | 'MatchPatternForMembership' | 'NeverConnectToPerson' | 'ObjectGUID' | 'PWDLastSet' | 'RiskIndexCalculated' | 'UID_DPRNameSpace' | 'UID_Person' | 'UID_TSBAccountDef' | 'UID_TSBBehavior' | 'UID_UNSAccount' | 'UID_UNSContainer' | 'UID_UNSRoot' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated'>;
}
/** @deprecated Use the PortalTargetsystemUnsAccount type. */
export declare class PortalTargetsystemUnsAccountInteractive extends PortalTargetsystemUnsAccount {
}
export declare class PortalTargetsystemUnsaccountb extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalTargetsystemUnsaccountb type. */
export declare class PortalTargetsystemUnsaccountbInteractive extends PortalTargetsystemUnsaccountb {
}
export declare class PortalTargetsystemUnsContainer extends TypedEntity {
    readonly CanonicalName: IReadValue<string>;
    readonly cn: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly DistinguishedName: IReadValue<string>;
    readonly DomainDisplayName: IReadValue<string>;
    readonly ObjectGUID: IReadValue<string>;
    readonly UID_DPRNameSpace: IReadValue<string>;
    readonly UID_ParentUNSContainer: IReadValue<string>;
    readonly UID_UNSContainer: IReadValue<string>;
    readonly UID_UNSRoot: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    readonly HasChildren: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'CanonicalName' | 'cn' | 'Description' | 'DistinguishedName' | 'DomainDisplayName' | 'ObjectGUID' | 'UID_DPRNameSpace' | 'UID_ParentUNSContainer' | 'UID_UNSContainer' | 'UID_UNSRoot' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated' | 'HasChildren'>;
}
/** @deprecated Use the PortalTargetsystemUnsContainer type. */
export declare class PortalTargetsystemUnsContainerInteractive extends PortalTargetsystemUnsContainer {
}
export declare class PortalTargetsystemUnscontainerb extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalTargetsystemUnscontainerb type. */
export declare class PortalTargetsystemUnscontainerbInteractive extends PortalTargetsystemUnscontainerb {
}
export declare class PortalTargetsystemUnsDirectmembers extends TypedEntity {
    readonly UID_UNSGroup: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_Person: IReadValue<string>;
    readonly IsFromDynamic: IReadValue<boolean>;
    readonly UID_PersonWantsOrg: IReadValue<string>;
    readonly OrderState: IReadValue<string>;
    readonly IsRequestCancellable: IReadValue<boolean>;
    readonly ValidUntil: IReadValue<Date>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_UNSGroup' | 'XOrigin' | 'XObjectKey' | 'XMarkedForDeletion' | 'XDateInserted' | 'UID_UNSAccount' | 'UID_Person' | 'IsFromDynamic' | 'UID_PersonWantsOrg' | 'OrderState' | 'IsRequestCancellable' | 'ValidUntil'>;
}
/** @deprecated Use the PortalTargetsystemUnsDirectmembers type. */
export declare class PortalTargetsystemUnsDirectmembersInteractive extends PortalTargetsystemUnsDirectmembers {
}
export declare class PortalTargetsystemUnsGroup extends TypedEntity {
    readonly CanonicalName: IReadValue<string>;
    readonly cn: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly DisplayName: IReadValue<string>;
    readonly DistinguishedName: IReadValue<string>;
    readonly GroupType: IReadValue<string>;
    readonly HasReadOnlyMemberships: IReadValue<boolean>;
    readonly IsForITShop: IReadValue<boolean>;
    readonly IsITShopOnly: IReadValue<boolean>;
    readonly MatchPatternForMembership: IReadValue<number>;
    readonly ObjectGUID: IReadValue<string>;
    readonly RiskIndex: IReadValue<number>;
    readonly UID_AccProduct: IReadValue<string>;
    readonly UID_DPRNameSpace: IReadValue<string>;
    readonly UID_UNSContainer: IReadValue<string>;
    readonly UID_UNSGroup: IReadValue<string>;
    readonly UID_UNSRoot: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'CanonicalName' | 'cn' | 'Description' | 'DisplayName' | 'DistinguishedName' | 'GroupType' | 'HasReadOnlyMemberships' | 'IsForITShop' | 'IsITShopOnly' | 'MatchPatternForMembership' | 'ObjectGUID' | 'RiskIndex' | 'UID_AccProduct' | 'UID_DPRNameSpace' | 'UID_UNSContainer' | 'UID_UNSGroup' | 'UID_UNSRoot' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated' | 'Requestable' | 'Owned'>;
}
/** @deprecated Use the PortalTargetsystemUnsGroup type. */
export declare class PortalTargetsystemUnsGroupInteractive extends PortalTargetsystemUnsGroup {
}
export declare class PortalTargetsystemUnsgroupb extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly HasReadOnlyMemberships: IReadValue<boolean>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'HasReadOnlyMemberships' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemUnsgroupb type. */
export declare class PortalTargetsystemUnsgroupbInteractive extends PortalTargetsystemUnsgroupb {
}
export declare class PortalTargetsystemUnsgroupb1 extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly HasReadOnlyMemberships: IReadValue<boolean>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'HasReadOnlyMemberships' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemUnsgroupb1 type. */
export declare class PortalTargetsystemUnsgroupb1Interactive extends PortalTargetsystemUnsgroupb1 {
}
export declare class PortalTargetsystemUnsgroupb2 extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly HasReadOnlyMemberships: IReadValue<boolean>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'HasReadOnlyMemberships' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemUnsgroupb2 type. */
export declare class PortalTargetsystemUnsgroupb2Interactive extends PortalTargetsystemUnsgroupb2 {
}
export declare class PortalTargetsystemUnsgroupb3 extends WriteExtTypedEntity<GroupExtendedData> {
    readonly UID_AccProduct: IReadValue<string>;
    readonly XObjectKey: IReadValue<string>;
    readonly HasReadOnlyMemberships: IReadValue<boolean>;
    readonly Requestable: IReadValue<boolean>;
    readonly Owned: IReadValue<boolean>;
    readonly XReadOnlyMemberships: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_AccProduct' | 'XObjectKey' | 'HasReadOnlyMemberships' | 'Requestable' | 'Owned' | 'XReadOnlyMemberships'>;
}
/** @deprecated Use the PortalTargetsystemUnsgroupb3 type. */
export declare class PortalTargetsystemUnsgroupb3Interactive extends PortalTargetsystemUnsgroupb3 {
}
export declare class PortalTargetsystemUnsGroupmembers extends TypedEntity {
    readonly XDateInserted: IReadValue<Date>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    readonly XMarkedForDeletion: IReadValue<number>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XDateInserted' | 'UID_UNSGroupChild' | 'XMarkedForDeletion'>;
}
/** @deprecated Use the PortalTargetsystemUnsGroupmembers type. */
export declare class PortalTargetsystemUnsGroupmembersInteractive extends PortalTargetsystemUnsGroupmembers {
}
export declare class PortalTargetsystemUnsGroupServiceitem extends WriteExtTypedEntity<AccProductOwnershipInput> {
    readonly Description: IWriteValue<string>;
    readonly Ident_AccProduct: IWriteValue<string>;
    readonly IsInActive: IWriteValue<boolean>;
    readonly UID_AccProductGroup: IWriteValue<string>;
    readonly UID_AccProductParamCategory: IWriteValue<string>;
    readonly UID_OrgAttestator: IWriteValue<string>;
    readonly UID_OrgRuler: IWriteValue<string>;
    readonly UID_PWODecisionMethod: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'Description' | 'Ident_AccProduct' | 'IsInActive' | 'UID_AccProductGroup' | 'UID_AccProductParamCategory' | 'UID_OrgAttestator' | 'UID_OrgRuler' | 'UID_PWODecisionMethod'>;
}
/** @deprecated Use the PortalTargetsystemUnsGroupServiceitem type. */
export declare class PortalTargetsystemUnsGroupServiceitemInteractive extends PortalTargetsystemUnsGroupServiceitem {
}
export declare class PortalTargetsystemUnsitemb extends TypedEntity {
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<never>;
}
/** @deprecated Use the PortalTargetsystemUnsitemb type. */
export declare class PortalTargetsystemUnsitembInteractive extends PortalTargetsystemUnsitemb {
}
export declare class PortalTargetsystemUnsNestedmembers extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'XMarkedForDeletion' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalTargetsystemUnsNestedmembers type. */
export declare class PortalTargetsystemUnsNestedmembersInteractive extends PortalTargetsystemUnsNestedmembers {
}
export declare class PortalTargetsystemUnsSystem extends TypedEntity {
    readonly CanonicalName: IReadValue<string>;
    readonly Description: IReadValue<string>;
    readonly DisplayName: IReadValue<string>;
    readonly DistinguishedName: IReadValue<string>;
    readonly Ident_UNSRoot: IReadValue<string>;
    readonly MatchPatternDisplay: IReadValue<string>;
    readonly NamespaceManagedBy: IReadValue<string>;
    readonly UID_AERoleOwner: IReadValue<string>;
    readonly UID_DPRNameSpace: IReadValue<string>;
    readonly UID_TSBAccountDef: IReadValue<string>;
    readonly UID_UNSRoot: IReadValue<string>;
    readonly XDateInserted: IReadValue<Date>;
    readonly XDateUpdated: IReadValue<Date>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XObjectKey: IReadValue<string>;
    readonly XTouched: IReadValue<string>;
    readonly XUserInserted: IReadValue<string>;
    readonly XUserUpdated: IReadValue<string>;
    readonly HasSync: IReadValue<boolean>;
    readonly HasData: IReadValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'CanonicalName' | 'Description' | 'DisplayName' | 'DistinguishedName' | 'Ident_UNSRoot' | 'MatchPatternDisplay' | 'NamespaceManagedBy' | 'UID_AERoleOwner' | 'UID_DPRNameSpace' | 'UID_TSBAccountDef' | 'UID_UNSRoot' | 'XDateInserted' | 'XDateUpdated' | 'XMarkedForDeletion' | 'XObjectKey' | 'XTouched' | 'XUserInserted' | 'XUserUpdated' | 'HasSync' | 'HasData'>;
}
/** @deprecated Use the PortalTargetsystemUnsSystem type. */
export declare class PortalTargetsystemUnsSystemInteractive extends PortalTargetsystemUnsSystem {
}
export declare class PortalUnsgroupb1Memberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalUnsgroupb1Memberships type. */
export declare class PortalUnsgroupb1MembershipsInteractive extends PortalUnsgroupb1Memberships {
}
export declare class PortalUnsgroupb2Memberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalUnsgroupb2Memberships type. */
export declare class PortalUnsgroupb2MembershipsInteractive extends PortalUnsgroupb2Memberships {
}
export declare class PortalUnsgroupb3Memberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalUnsgroupb3Memberships type. */
export declare class PortalUnsgroupb3MembershipsInteractive extends PortalUnsgroupb3Memberships {
}
export declare class PortalUnsgroupbMemberships extends TypedEntity {
    readonly UID_Person: IReadValue<string>;
    readonly ObjectKeyAssignment: IReadValue<string>;
    readonly XOrigin: IReadValue<number>;
    readonly IsPending: IReadValue<boolean>;
    readonly IsPrimary: IReadValue<boolean>;
    readonly XMarkedForDeletion: IReadValue<number>;
    readonly XDateInserted: IReadValue<Date>;
    readonly OrderState: IReadValue<string>;
    readonly ValidUntil: IReadValue<Date>;
    readonly UID_UNSAccount: IReadValue<string>;
    readonly UID_UNSGroupChild: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_Person' | 'ObjectKeyAssignment' | 'XOrigin' | 'IsPending' | 'IsPrimary' | 'XMarkedForDeletion' | 'XDateInserted' | 'OrderState' | 'ValidUntil' | 'UID_UNSAccount' | 'UID_UNSGroupChild'>;
}
/** @deprecated Use the PortalUnsgroupbMemberships type. */
export declare class PortalUnsgroupbMembershipsInteractive extends PortalUnsgroupbMemberships {
}
export declare class PortalCandidatesAccproductgroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_AccProductGroup_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAccproductgroup, unknown>>;
}
export declare class PortalCandidatesAccproductparamcategoryWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_AccProductParamCategory_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesAccproductparamcategory, unknown>>;
}
export declare class PortalClaimgroupGroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_claimgroup_group_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalClaimgroupGroup, unknown>>;
}
export declare class PortalClaimgroupSuggestedownerWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(tablename: string, uidunsgroup: string, parametersOptional?: portal_claimgroup_suggestedowner_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalClaimgroupSuggestedowner, unknown>>;
}
export declare class PortalClaimgroupSuggestedowner2Wrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(tablename: string, uidunsgroup: string, parametersOptional?: portal_claimgroup_suggestedowner2_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalClaimgroupSuggestedowner2, unknown>>;
}
export declare class PortalPersonAccountsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: portal_person_accounts_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonAccounts, unknown>>;
}
export declare class PortalPersonGroupmembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: portal_person_groupmemberships_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPersonGroupmemberships, unknown>>;
}
export declare class PortalRespUnsgroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_resp_unsgroup_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroup, unknown>>;
}
export declare class PortalRespUnsgroupbWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_resp_unsgroupb_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroupb, unknown>>;
}
export declare class PortalRespUnsgroupb1Wrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_resp_unsgroupb1_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroupb1, unknown>>;
}
export declare class PortalRespUnsgroupb1InteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalRespUnsgroupb1, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroupb1, unknown>>;
    Get_byid(UID_UNSGroupB1: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroupb1, unknown>>;
}
export declare class PortalRespUnsgroupb2Wrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_resp_unsgroupb2_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroupb2, unknown>>;
}
export declare class PortalRespUnsgroupb2InteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalRespUnsgroupb2, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroupb2, unknown>>;
    Get_byid(UID_UNSGroupB2: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroupb2, unknown>>;
}
export declare class PortalRespUnsgroupb3Wrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_resp_unsgroupb3_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroupb3, unknown>>;
}
export declare class PortalRespUnsgroupb3InteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalRespUnsgroupb3, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroupb3, unknown>>;
    Get_byid(UID_UNSGroupB3: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroupb3, unknown>>;
}
export declare class PortalRespUnsgroupbInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalRespUnsgroupb, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroupb, unknown>>;
    Get_byid(UID_UNSGroupB: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalRespUnsgroupb, unknown>>;
}
export declare class PortalShopConfigEntitlementsTsbaccountdefWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsTsbaccountdef;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: portal_shop_config_entitlements_TSBAccountDef_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsTsbaccountdef, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsTsbaccountdef, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsTsbaccountdef, unknown>>;
    Delete(UID_ITShopOrg: string, UID_TSBAccountDef: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsTsbaccountdef, unknown>>;
}
export declare class PortalShopConfigEntitlementsUnsgroupbWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsUnsgroupb;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: portal_shop_config_entitlements_UNSGroupB_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsUnsgroupb, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsUnsgroupb, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsUnsgroupb, unknown>>;
    Delete(UID_ITShopOrg: string, UID_UNSGroupB: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsUnsgroupb, unknown>>;
}
export declare class PortalShopConfigEntitlementsUnsgroupb1Wrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsUnsgroupb1;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: portal_shop_config_entitlements_UNSGroupB1_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsUnsgroupb1, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsUnsgroupb1, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsUnsgroupb1, unknown>>;
    Delete(UID_ITShopOrg: string, UID_UNSGroupB1: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsUnsgroupb1, unknown>>;
}
export declare class PortalShopConfigEntitlementsUnsgroupb2Wrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsUnsgroupb2;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: portal_shop_config_entitlements_UNSGroupB2_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsUnsgroupb2, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsUnsgroupb2, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsUnsgroupb2, unknown>>;
    Delete(UID_ITShopOrg: string, UID_UNSGroupB2: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsUnsgroupb2, unknown>>;
}
export declare class PortalShopConfigEntitlementsUnsgroupb3Wrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalShopConfigEntitlementsUnsgroupb3;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_ITShopOrg: string, parametersOptional?: portal_shop_config_entitlements_UNSGroupB3_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsUnsgroupb3, unknown>>;
    Post(UID_ITShopOrg: string, inputParameterName: PortalShopConfigEntitlementsUnsgroupb3, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsUnsgroupb3, unknown>>;
    Delete(UID_ITShopOrg: string, UID_UNSGroupB3: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalShopConfigEntitlementsUnsgroupb3, unknown>>;
}
export declare class PortalTargetsystemUnsAccountWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_uns_account_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsAccount, unknown>>;
}
export declare class PortalTargetsystemUnsaccountbWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_unsaccountb_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsaccountb, unknown>>;
    Put(inputParameterName: PortalTargetsystemUnsaccountb, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsaccountb, unknown>>;
}
export declare class PortalTargetsystemUnsaccountbInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemUnsaccountb, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsaccountb, unknown>>;
    Get_byid(UID_UNSAccountB: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsaccountb, unknown>>;
}
export declare class PortalTargetsystemUnsContainerWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_uns_container_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsContainer, unknown>>;
}
export declare class PortalTargetsystemUnscontainerbWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_unscontainerb_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnscontainerb, unknown>>;
    Put(inputParameterName: PortalTargetsystemUnscontainerb, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnscontainerb, unknown>>;
}
export declare class PortalTargetsystemUnscontainerbInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemUnscontainerb, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnscontainerb, unknown>>;
    Get_byid(UID_UNSContainerB: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnscontainerb, unknown>>;
}
export declare class PortalTargetsystemUnsDirectmembersWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_UNSGroup: string, parametersOptional?: portal_targetsystem_uns_directmembers_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsDirectmembers, unknown>>;
}
export declare class PortalTargetsystemUnsGroupWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_uns_group_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsGroup, unknown>>;
}
export declare class PortalTargetsystemUnsgroupbWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_unsgroupb_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb, unknown>>;
    Put(inputParameterName: PortalTargetsystemUnsgroupb, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb, unknown>>;
}
export declare class PortalTargetsystemUnsgroupb1Wrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_unsgroupb1_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb1, unknown>>;
    Put(inputParameterName: PortalTargetsystemUnsgroupb1, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb1, unknown>>;
}
export declare class PortalTargetsystemUnsgroupb1InteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemUnsgroupb1, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb1, unknown>>;
    Get_byid(UID_UNSGroupB1: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb1, unknown>>;
}
export declare class PortalTargetsystemUnsgroupb2Wrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_unsgroupb2_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb2, unknown>>;
    Put(inputParameterName: PortalTargetsystemUnsgroupb2, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb2, unknown>>;
}
export declare class PortalTargetsystemUnsgroupb2InteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemUnsgroupb2, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb2, unknown>>;
    Get_byid(UID_UNSGroupB2: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb2, unknown>>;
}
export declare class PortalTargetsystemUnsgroupb3Wrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_unsgroupb3_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb3, unknown>>;
    Put(inputParameterName: PortalTargetsystemUnsgroupb3, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb3, unknown>>;
}
export declare class PortalTargetsystemUnsgroupb3InteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemUnsgroupb3, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb3, unknown>>;
    Get_byid(UID_UNSGroupB3: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb3, unknown>>;
}
export declare class PortalTargetsystemUnsgroupbInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemUnsgroupb, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb, unknown>>;
    Get_byid(UID_UNSGroupB: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsgroupb, unknown>>;
}
export declare class PortalTargetsystemUnsGroupmembersWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uidgroup: string, parametersOptional?: portal_targetsystem_uns_groupmembers_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsGroupmembers, unknown>>;
}
export declare class PortalTargetsystemUnsGroupServiceitemWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_uns_group_serviceitem_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsGroupServiceitem, unknown>>;
    Put(inputParameterName: PortalTargetsystemUnsGroupServiceitem, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsGroupServiceitem, unknown>>;
}
export declare class PortalTargetsystemUnsGroupServiceitemInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemUnsGroupServiceitem, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsGroupServiceitem, unknown>>;
    Get_byid(UID_AccProduct: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsGroupServiceitem, unknown>>;
}
export declare class PortalTargetsystemUnsitembWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_unsitemb_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsitemb, unknown>>;
    Put(inputParameterName: PortalTargetsystemUnsitemb, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsitemb, unknown>>;
}
export declare class PortalTargetsystemUnsitembInteractiveWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Put(inputParameterName: PortalTargetsystemUnsitemb, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsitemb, unknown>>;
    Get_byid(UID_UNSItemB: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsitemb, unknown>>;
}
export declare class PortalTargetsystemUnsNestedmembersWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: portal_targetsystem_uns_nestedmembers_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsNestedmembers, unknown>>;
}
export declare class PortalTargetsystemUnsSystemWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_uns_system_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemUnsSystem, unknown>>;
}
export declare class PortalUnsgroupb1MembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalUnsgroupb1Memberships, unknown>>;
}
export declare class PortalUnsgroupb2MembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalUnsgroupb2Memberships, unknown>>;
}
export declare class PortalUnsgroupb3MembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalUnsgroupb3Memberships, unknown>>;
}
export declare class PortalUnsgroupbMembershipsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(uid: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalUnsgroupbMemberships, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_candidates_AccProductGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductGroup_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_candidates_AccProductParamCategory_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductParamCategory_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_claimgroup_post(uidperson: string, tablename: string, uidunsgroup: string): MethodDescriptor<void>;
    portal_claimgroup_group_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_claimgroup_suggestedowner_get(tablename: string, uidunsgroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_claimgroup_suggestedowner2_get(tablename: string, uidunsgroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_accounts_get(uid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_person_groupmemberships_get(uid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_unsgroup_get(system: string, container: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, risk: string, namespace: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_unsgroup_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_unsgroupb_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_unsgroupb_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_unsgroupb_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb_interactive_byid_get(UID_UNSGroupB: string): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb1_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_unsgroupb1_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_unsgroupb1_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb1_interactive_byid_get(UID_UNSGroupB1: string): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb2_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_unsgroupb2_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_unsgroupb2_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb2_interactive_byid_get(UID_UNSGroupB2: string): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb3_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_resp_unsgroupb3_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_resp_unsgroupb3_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb3_interactive_byid_get(UID_UNSGroupB3: string): MethodDescriptor<InteractiveEntityData>;
    portal_shop_config_entitlements_TSBAccountDef_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_TSBAccountDef_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_TSBAccountDef_delete(UID_ITShopOrg: string, UID_TSBAccountDef: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB_delete(UID_ITShopOrg: string, UID_UNSGroupB: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB1_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB1_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB1_delete(UID_ITShopOrg: string, UID_UNSGroupB1: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB2_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB2_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB2_delete(UID_ITShopOrg: string, UID_UNSGroupB2: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB3_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB3_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB3_delete(UID_ITShopOrg: string, UID_UNSGroupB3: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_account_get(container: string, system: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, inactive: string, deletedintarget: string, risk: string, namespace: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_account_report_get(tablename: string, historydays: number, uidaccount: string): MethodDescriptor<void>;
    portal_targetsystem_uns_account_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_uns_account_filtertree_get(container: string, system: string, filter: FilterData[], parentkey: string): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_account_ownedby_report_get(historydays: number, uidperson: string): MethodDescriptor<void>;
    portal_targetsystem_uns_account_ownedbymanaged_report_get(historydays: number, uidperson: string): MethodDescriptor<void>;
    portal_targetsystem_uns_container_get(system: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, namespace: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_container_accounts_report_get(historydays: number, uidcontainer: string): MethodDescriptor<void>;
    portal_targetsystem_uns_container_groups_report_get(historydays: number, uidcontainer: string): MethodDescriptor<void>;
    portal_targetsystem_uns_container_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_uns_directmembers_get(UID_UNSGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_get(uid_unsaccount: string, container: string, system: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, namespace: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_report_get(historydays: number, uidgroup: string): MethodDescriptor<void>;
    portal_targetsystem_uns_group_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_uns_group_filtertree_get(uid_unsaccount: string, container: string, system: string, filter: FilterData[], parentkey: string): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_uns_group_serviceitem_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_uns_group_serviceitem_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_uns_group_serviceitem_interactive_byid_get(UID_AccProduct: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_groupmembers_get(uidgroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_nestedmembers_get(uid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_ownedby_report_get(historydays: number, uidperson: string): MethodDescriptor<void>;
    portal_targetsystem_uns_person_managed_report_get(uidperson: string): MethodDescriptor<void>;
    portal_targetsystem_uns_person_report_get(IncludeSubIdentities: boolean, IncludeHistory: boolean, uidperson: string, historydays: number): MethodDescriptor<void>;
    portal_targetsystem_uns_root_accounts_report_get(historydays: number, uidroot: string): MethodDescriptor<void>;
    portal_targetsystem_uns_root_groups_report_get(historydays: number, uidroot: string): MethodDescriptor<void>;
    portal_targetsystem_uns_system_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, namespace: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_system_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_unsaccountb_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsaccountb_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsaccountb_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_unsaccountb_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_unsaccountb_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsaccountb_interactive_byid_get(UID_UNSAccountB: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unscontainerb_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unscontainerb_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unscontainerb_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_unscontainerb_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_unscontainerb_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unscontainerb_interactive_byid_get(UID_UNSContainerB: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_unsgroupb_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_unsgroupb_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb_interactive_byid_get(UID_UNSGroupB: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb1_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb1_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb1_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_unsgroupb1_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_unsgroupb1_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb1_interactive_byid_get(UID_UNSGroupB1: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb2_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb2_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb2_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_unsgroupb2_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_unsgroupb2_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb2_interactive_byid_get(UID_UNSGroupB2: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb3_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb3_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb3_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_unsgroupb3_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_unsgroupb3_interactive_put(inputParameterName: any): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb3_interactive_byid_get(UID_UNSGroupB3: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsitemb_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsitemb_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsitemb_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_unsitemb_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_targetsystem_unsitemb_interactive_put(inputParameterName: InteractiveEntityWriteData): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsitemb_interactive_byid_get(UID_UNSItemB: string): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_userconfig_get(): MethodDescriptor<TsbUserConfig>;
    portal_uns_config_get(): MethodDescriptor<UnsConfig>;
    portal_UNSGroupB_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_UNSGroupB_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_UNSGroupB1_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_UNSGroupB1_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_UNSGroupB2_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_UNSGroupB2_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
    portal_UNSGroupB3_memberships_get(uid: string): MethodDescriptor<EntityCollectionData>;
    portal_UNSGroupB3_memberships_delete(uid: string, uidaccount: string): MethodDescriptor<void>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns a list of candidate objects from the table AccProductGroup. */
    portal_candidates_AccProductGroup_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AccProductGroup endpoint. */
    portal_candidates_AccProductGroup_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AccProductParamCategory. */
    portal_candidates_AccProductParamCategory_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AccProductParamCategory endpoint. */
    portal_candidates_AccProductParamCategory_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Create an attestation case to assign ownership of the specified group to the current user. */
    portal_claimgroup_post(uidperson: string, tablename: string, uidunsgroup: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns system entitlements that have no current owner */
    portal_claimgroup_group_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns suggested owners (first suggestions) for the specified group */
    portal_claimgroup_suggestedowner_get(tablename: string, uidunsgroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns suggested owners (second suggestions) for the specified group */
    portal_claimgroup_suggestedowner2_get(tablename: string, uidunsgroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_person_accounts_get(uid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_person_groupmemberships_get(uid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resp_unsgroup_get(system: string, container: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, risk: string, namespace: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/unsgroup endpoint. */
    portal_resp_unsgroup_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_unsgroupb_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/unsgroupb endpoint. */
    portal_resp_unsgroupb_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_unsgroupb_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb_interactive_byid_get(UID_UNSGroupB: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb1_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/unsgroupb1 endpoint. */
    portal_resp_unsgroupb1_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_unsgroupb1_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb1_interactive_byid_get(UID_UNSGroupB1: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb2_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/unsgroupb2 endpoint. */
    portal_resp_unsgroupb2_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_unsgroupb2_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb2_interactive_byid_get(UID_UNSGroupB2: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb3_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/unsgroupb3 endpoint. */
    portal_resp_unsgroupb3_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_unsgroupb3_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb3_interactive_byid_get(UID_UNSGroupB3: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_shop_config_entitlements_TSBAccountDef_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_TSBAccountDef_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_TSBAccountDef_delete(UID_ITShopOrg: string, UID_TSBAccountDef: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_TSBAccountDef. */
    portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates endpoint. */
    portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates endpoint. */
    portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB_delete(UID_ITShopOrg: string, UID_UNSGroupB: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_UNSGroupB. */
    portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB1_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB1_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB1_delete(UID_ITShopOrg: string, UID_UNSGroupB1: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_UNSGroupB1. */
    portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB2_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB2_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB2_delete(UID_ITShopOrg: string, UID_UNSGroupB2: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_UNSGroupB2. */
    portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB3_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB3_post(UID_ITShopOrg: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB3_delete(UID_ITShopOrg: string, UID_UNSGroupB3: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_UNSGroupB3. */
    portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get(UID_ITShopOrg: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get(UID_ITShopOrg: string, filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post(UID_ITShopOrg: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_uns_account_get(container: string, system: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, inactive: string, deletedintarget: string, risk: string, namespace: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Renders a report for the specified account. */
    portal_targetsystem_uns_account_report_get(tablename: string, historydays: number, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/uns/account endpoint. */
    portal_targetsystem_uns_account_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/uns/account endpoint. */
    portal_targetsystem_uns_account_filtertree_get(container: string, system: string, filter: FilterData[], parentkey: string, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Renders a report for accounts belonging to the specified identity. */
    portal_targetsystem_uns_account_ownedby_report_get(historydays: number, uidperson: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Renders a report for accounts belonging to identities managed by the specified identity. */
    portal_targetsystem_uns_account_ownedbymanaged_report_get(historydays: number, uidperson: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_targetsystem_uns_container_get(system: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, namespace: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Renders a report for accounts in the specified container. */
    portal_targetsystem_uns_container_accounts_report_get(historydays: number, uidcontainer: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Renders a report for system entitlements in the specified container. */
    portal_targetsystem_uns_container_groups_report_get(historydays: number, uidcontainer: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/uns/container endpoint. */
    portal_targetsystem_uns_container_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_uns_directmembers_get(UID_UNSGroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_uns_group_get(uid_unsaccount: string, container: string, system: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, namespace: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Renders a report for the specified system entitlements. */
    portal_targetsystem_uns_group_report_get(historydays: number, uidgroup: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/uns/group endpoint. */
    portal_targetsystem_uns_group_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/uns/group endpoint. */
    portal_targetsystem_uns_group_filtertree_get(uid_unsaccount: string, container: string, system: string, filter: FilterData[], parentkey: string, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/uns/group/serviceitem endpoint. */
    portal_targetsystem_uns_group_serviceitem_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_uns_group_serviceitem_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_uns_group_serviceitem_interactive_byid_get(UID_AccProduct: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the targetsystem/uns/group/serviceitem/interactive/UID_OrgAttestator/candidates endpoint. */
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the targetsystem/uns/group/serviceitem/interactive/UID_OrgRuler/candidates endpoint. */
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the targetsystem/uns/group/serviceitem/interactive/UID_PWODecisionMethod/candidates endpoint. */
    portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the targetsystem/uns/group/serviceitem/UID_OrgAttestator/candidates endpoint. */
    portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the targetsystem/uns/group/serviceitem/UID_OrgRuler/candidates endpoint. */
    portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the targetsystem/uns/group/serviceitem/UID_PWODecisionMethod/candidates endpoint. */
    portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_uns_groupmembers_get(uidgroup: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_uns_nestedmembers_get(uid: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Renders a report for system entitlements owned by the specified identity. */
    portal_targetsystem_uns_ownedby_report_get(historydays: number, uidperson: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Creates a report containing information about identities managed by the specified identity. */
    portal_targetsystem_uns_person_managed_report_get(uidperson: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Creates a report containing information about personal and organizational data as well as the identity's user accounts, groups and roles. */
    portal_targetsystem_uns_person_report_get(IncludeSubIdentities: boolean, IncludeHistory: boolean, uidperson: string, historydays: number, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Renders a report for accounts in the specified target system. */
    portal_targetsystem_uns_root_accounts_report_get(historydays: number, uidroot: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Renders a report for system entitlements in the specified target system. */
    portal_targetsystem_uns_root_groups_report_get(historydays: number, uidroot: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_targetsystem_uns_system_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, namespace: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/uns/system endpoint. */
    portal_targetsystem_uns_system_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsaccountb_get(UID_PersonAssociated: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, orphaned: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsaccountb_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsaccountb_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unsaccountb endpoint. */
    portal_targetsystem_unsaccountb_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsaccountb_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsaccountb_interactive_byid_get(UID_UNSAccountB: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unscontainerb_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, ParentKey: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unscontainerb_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unscontainerb_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unscontainerb endpoint. */
    portal_targetsystem_unscontainerb_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unscontainerb_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unscontainerb_interactive_byid_get(UID_UNSContainerB: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unsgroupb endpoint. */
    portal_targetsystem_unsgroupb_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsgroupb_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb_interactive_byid_get(UID_UNSGroupB: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb1_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb1_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb1_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unsgroupb1 endpoint. */
    portal_targetsystem_unsgroupb1_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsgroupb1_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb1_interactive_byid_get(UID_UNSGroupB1: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb2_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb2_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb2_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unsgroupb2 endpoint. */
    portal_targetsystem_unsgroupb2_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsgroupb2_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb2_interactive_byid_get(UID_UNSGroupB2: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb3_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, published: string, withowner: string, deletedintarget: string, risk: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb3_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb3_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unsgroupb3 endpoint. */
    portal_targetsystem_unsgroupb3_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsgroupb3_interactive_put(inputParameterName: any, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb3_interactive_byid_get(UID_UNSGroupB3: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsitemb_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsitemb_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsitemb_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unsitemb endpoint. */
    portal_targetsystem_unsitemb_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsitemb_interactive_put(inputParameterName: InteractiveEntityWriteData, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsitemb_interactive_byid_get(UID_UNSItemB: string, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_userconfig_get(requestOptions?: ApiRequestOptions): Promise<TsbUserConfig>;
    /** Returns schema information about the Unified Namespace. */
    portal_uns_config_get(requestOptions?: ApiRequestOptions): Promise<UnsConfig>;
    portal_UNSGroupB_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_UNSGroupB_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_UNSGroupB1_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_UNSGroupB1_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_UNSGroupB2_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_UNSGroupB2_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_UNSGroupB3_memberships_get(uid: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_UNSGroupB3_memberships_delete(uid: string, uidaccount: string, requestOptions?: ApiRequestOptions): Promise<void>;
}
export interface portal_candidates_AccProductGroup_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_AccProductGroupParent) */ ParentKey?: string;
}
export interface portal_candidates_AccProductGroup_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_candidates_AccProductParamCategory_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_AccProductParamCategory_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_claimgroup_group_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_claimgroup_suggestedowner_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_claimgroup_suggestedowner2_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_person_accounts_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_person_groupmemberships_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_resp_unsgroup_get_args {
    /** Unique identifier to return only objects in the specified target system. */ system?: string;
    /** Unique container identifier to return only objects in the specified container. */ container?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filter by risk index */ risk?: string;
    /** Unique target system type identifier */ namespace?: string;
}
export interface portal_resp_unsgroup_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_resp_unsgroupb_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_resp_unsgroupb_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_resp_unsgroupb1_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_resp_unsgroupb1_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_resp_unsgroupb2_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_resp_unsgroupb2_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_resp_unsgroupb3_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_resp_unsgroupb3_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_TSBAccountDef_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_shop_config_entitlements_UNSGroupB_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_shop_config_entitlements_UNSGroupB1_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_shop_config_entitlements_UNSGroupB2_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_shop_config_entitlements_UNSGroupB3_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_uns_account_get_args {
    /** Unique container identifier to return only objects in the specified container. */ container?: string;
    /** Unique identifier to return only objects in the specified target system. */ system?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters orphaned accounts */ orphaned?: string;
    /** Filters inactive accounts */ inactive?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
    /** Unique target system type identifier */ namespace?: string;
}
export interface portal_targetsystem_uns_account_report_get_args {
    /** Default number of days to load history for when rendering reports */ historydays?: number;
}
export interface portal_targetsystem_uns_account_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_uns_account_filtertree_get_args {
    /** Unique container identifier to return only objects in the specified container. */ container?: string;
    /** Unique identifier to return only objects in the specified target system. */ system?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_uns_account_ownedby_report_get_args {
    /** Default number of days to load history for when rendering reports */ historydays?: number;
}
export interface portal_targetsystem_uns_account_ownedbymanaged_report_get_args {
    /** Default number of days to load history for when rendering reports */ historydays?: number;
}
export interface portal_targetsystem_uns_container_get_args {
    /** Unique identifier to return only objects in the specified target system. */ system?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentUNSContainer) */ ParentKey?: string;
    /** Unique target system type identifier */ namespace?: string;
}
export interface portal_targetsystem_uns_container_accounts_report_get_args {
    /** Default number of days to load history for when rendering reports */ historydays?: number;
}
export interface portal_targetsystem_uns_container_groups_report_get_args {
    /** Default number of days to load history for when rendering reports */ historydays?: number;
}
export interface portal_targetsystem_uns_container_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_uns_directmembers_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_uns_group_get_args {
    /** Filters groups that the specified account is a member of */ uid_unsaccount?: string;
    /** Unique container identifier to return only objects in the specified container. */ container?: string;
    /** Unique identifier to return only objects in the specified target system. */ system?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
    /** Unique target system type identifier */ namespace?: string;
}
export interface portal_targetsystem_uns_group_report_get_args {
    /** Default number of days to load history for when rendering reports */ historydays?: number;
}
export interface portal_targetsystem_uns_group_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_uns_group_filtertree_get_args {
    /** Filters groups that the specified account is a member of */ uid_unsaccount?: string;
    /** Unique container identifier to return only objects in the specified container. */ container?: string;
    /** Unique identifier to return only objects in the specified target system. */ system?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentAERole) */ ParentKey?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentAERole) */ ParentKey?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentAERole) */ ParentKey?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentAERole) */ ParentKey?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_targetsystem_uns_groupmembers_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_uns_nestedmembers_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_uns_ownedby_report_get_args {
    /** Default number of days to load history for when rendering reports */ historydays?: number;
}
export interface portal_targetsystem_uns_person_report_get_args {
    /** Include sub identities in the report */ IncludeSubIdentities?: boolean;
    /** Include historical data in the report */ IncludeHistory?: boolean;
    /** Default number of days to load history for when rendering reports */ historydays?: number;
}
export interface portal_targetsystem_uns_root_accounts_report_get_args {
    /** Default number of days to load history for when rendering reports */ historydays?: number;
}
export interface portal_targetsystem_uns_root_groups_report_get_args {
    /** Default number of days to load history for when rendering reports */ historydays?: number;
}
export interface portal_targetsystem_uns_system_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Unique target system type identifier */ namespace?: string;
}
export interface portal_targetsystem_uns_system_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_unsaccountb_get_args {
    /** Filters accounts for main and sub identities associated with the specified identity */ UID_PersonAssociated?: string;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters orphaned accounts */ orphaned?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_unsaccountb_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_unscontainerb_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Parent object (UID_ParentUNSContainerB) */ ParentKey?: string;
}
export interface portal_targetsystem_unscontainerb_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_unsgroupb_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_unsgroupb_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_unsgroupb1_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_unsgroupb1_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_unsgroupb2_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_unsgroupb2_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_unsgroupb3_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filters requestable system entitlements */ published?: string;
    /** Filters entitlements with owners */ withowner?: string;
    /** Filters objects deleted in the target system */ deletedintarget?: string;
    /** Filter by risk index */ risk?: string;
}
export interface portal_targetsystem_unsgroupb3_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_targetsystem_unsitemb_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_unsitemb_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export declare class V2ApiClientMethodFactory {
    portal_candidates_AccProductGroup_get(options?: portal_candidates_AccProductGroup_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductGroup_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_AccProductGroup_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_candidates_AccProductParamCategory_get(options?: portal_candidates_AccProductParamCategory_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_AccProductParamCategory_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_AccProductParamCategory_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_claimgroup_post(/** Identity claiming the ownership */ uidperson: string, /** Table name of the system entitlement */ tablename: string, /** Identifier of the system entitlement */ uidunsgroup: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_claimgroup_group_get(options?: portal_claimgroup_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_claimgroup_suggestedowner_get(/** Table name of the system entitlement */ tablename: string, /** Identifier of the system entitlement */ uidunsgroup: string, options?: portal_claimgroup_suggestedowner_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_claimgroup_suggestedowner2_get(/** Table name of the system entitlement */ tablename: string, /** Identifier of the system entitlement */ uidunsgroup: string, options?: portal_claimgroup_suggestedowner2_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_person_accounts_get(/** Unique identifier */ uid: string, options?: portal_person_accounts_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_person_groupmemberships_get(/** Unique identifier */ uid: string, options?: portal_person_groupmemberships_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_unsgroup_get(options?: portal_resp_unsgroup_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_unsgroup_datamodel_get(options?: portal_resp_unsgroup_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_resp_unsgroupb_get(options?: portal_resp_unsgroupb_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_unsgroupb_datamodel_get(options?: portal_resp_unsgroupb_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_resp_unsgroupb_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb_interactive_byid_get(/** Primary key value UID_UNSGroupB */ UID_UNSGroupB: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb1_get(options?: portal_resp_unsgroupb1_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_unsgroupb1_datamodel_get(options?: portal_resp_unsgroupb1_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_resp_unsgroupb1_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb1_interactive_byid_get(/** Primary key value UID_UNSGroupB1 */ UID_UNSGroupB1: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb2_get(options?: portal_resp_unsgroupb2_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_unsgroupb2_datamodel_get(options?: portal_resp_unsgroupb2_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_resp_unsgroupb2_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb2_interactive_byid_get(/** Primary key value UID_UNSGroupB2 */ UID_UNSGroupB2: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb3_get(options?: portal_resp_unsgroupb3_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_resp_unsgroupb3_datamodel_get(options?: portal_resp_unsgroupb3_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_resp_unsgroupb3_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_resp_unsgroupb3_interactive_byid_get(/** Primary key value UID_UNSGroupB3 */ UID_UNSGroupB3: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_shop_config_entitlements_TSBAccountDef_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_TSBAccountDef_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_TSBAccountDef_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_TSBAccountDef_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** Account definition */ UID_TSBAccountDef: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** Group */ UID_UNSGroupB: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB1_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB1_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB1_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB1_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** System entitlement 1 */ UID_UNSGroupB1: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB2_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB2_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB2_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB2_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** System entitlement 2 */ UID_UNSGroupB2: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB3_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB3_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB3_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB3_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** System entitlement 3 */ UID_UNSGroupB3: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_account_get(options?: portal_targetsystem_uns_account_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_account_report_get(/** Type of account */ tablename: string, /** Unique account identifier */ uidaccount: string, options?: portal_targetsystem_uns_account_report_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_uns_account_datamodel_get(options?: portal_targetsystem_uns_account_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_uns_account_filtertree_get(options?: portal_targetsystem_uns_account_filtertree_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_account_ownedby_report_get(/** Unique identity identifier */ uidperson: string, options?: portal_targetsystem_uns_account_ownedby_report_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_uns_account_ownedbymanaged_report_get(/** Unique identity identifier */ uidperson: string, options?: portal_targetsystem_uns_account_ownedbymanaged_report_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_uns_container_get(options?: portal_targetsystem_uns_container_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_container_accounts_report_get(/** Unique container identifier */ uidcontainer: string, options?: portal_targetsystem_uns_container_accounts_report_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_uns_container_groups_report_get(/** Unique container identifier */ uidcontainer: string, options?: portal_targetsystem_uns_container_groups_report_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_uns_container_datamodel_get(options?: portal_targetsystem_uns_container_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_uns_directmembers_get(/** Unique system entitlement identifier */ UID_UNSGroup: string, options?: portal_targetsystem_uns_directmembers_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_get(options?: portal_targetsystem_uns_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_report_get(/** Unique group identifier */ uidgroup: string, options?: portal_targetsystem_uns_group_report_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_uns_group_datamodel_get(options?: portal_targetsystem_uns_group_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_uns_group_filtertree_get(options?: portal_targetsystem_uns_group_filtertree_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_get(options?: portal_targetsystem_uns_group_serviceitem_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_uns_group_serviceitem_datamodel_get(options?: portal_targetsystem_uns_group_serviceitem_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_uns_group_serviceitem_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_uns_group_serviceitem_interactive_byid_get(/** Primary key value UID_AccProduct */ UID_AccProduct: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get(options?: portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get(options?: portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get(options?: portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get(options?: portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get(options?: portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get(options?: portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_targetsystem_uns_groupmembers_get(/** Unique group identifier */ uidgroup: string, options?: portal_targetsystem_uns_groupmembers_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_nestedmembers_get(/** Unique identifier */ uid: string, options?: portal_targetsystem_uns_nestedmembers_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_ownedby_report_get(/** Unique Identity identifier */ uidperson: string, options?: portal_targetsystem_uns_ownedby_report_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_uns_person_managed_report_get(/** Unique identity identifier */ uidperson: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_uns_person_report_get(/** Unique identity identifier */ uidperson: string, options?: portal_targetsystem_uns_person_report_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_uns_root_accounts_report_get(/** Unique root identifier */ uidroot: string, options?: portal_targetsystem_uns_root_accounts_report_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_uns_root_groups_report_get(/** Unique root identifier */ uidroot: string, options?: portal_targetsystem_uns_root_groups_report_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_uns_system_get(options?: portal_targetsystem_uns_system_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_uns_system_datamodel_get(options?: portal_targetsystem_uns_system_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_unsaccountb_get(options?: portal_targetsystem_unsaccountb_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsaccountb_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsaccountb_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_unsaccountb_datamodel_get(options?: portal_targetsystem_unsaccountb_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_unsaccountb_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsaccountb_interactive_byid_get(/** Primary key value UID_UNSAccountB */ UID_UNSAccountB: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unscontainerb_get(options?: portal_targetsystem_unscontainerb_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unscontainerb_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unscontainerb_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_unscontainerb_datamodel_get(options?: portal_targetsystem_unscontainerb_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_unscontainerb_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unscontainerb_interactive_byid_get(/** Primary key value UID_UNSContainerB */ UID_UNSContainerB: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb_get(options?: portal_targetsystem_unsgroupb_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_unsgroupb_datamodel_get(options?: portal_targetsystem_unsgroupb_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_unsgroupb_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb_interactive_byid_get(/** Primary key value UID_UNSGroupB */ UID_UNSGroupB: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb1_get(options?: portal_targetsystem_unsgroupb1_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb1_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb1_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_unsgroupb1_datamodel_get(options?: portal_targetsystem_unsgroupb1_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_unsgroupb1_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb1_interactive_byid_get(/** Primary key value UID_UNSGroupB1 */ UID_UNSGroupB1: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb2_get(options?: portal_targetsystem_unsgroupb2_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb2_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb2_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_unsgroupb2_datamodel_get(options?: portal_targetsystem_unsgroupb2_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_unsgroupb2_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb2_interactive_byid_get(/** Primary key value UID_UNSGroupB2 */ UID_UNSGroupB2: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb3_get(options?: portal_targetsystem_unsgroupb3_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb3_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsgroupb3_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_unsgroupb3_datamodel_get(options?: portal_targetsystem_unsgroupb3_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_unsgroupb3_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsgroupb3_interactive_byid_get(/** Primary key value UID_UNSGroupB3 */ UID_UNSGroupB3: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsitemb_get(options?: portal_targetsystem_unsitemb_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsitemb_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_unsitemb_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_unsitemb_datamodel_get(options?: portal_targetsystem_unsitemb_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_targetsystem_unsitemb_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_unsitemb_interactive_byid_get(/** Primary key value UID_UNSItemB */ UID_UNSItemB: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<InteractiveEntityData>;
    portal_targetsystem_userconfig_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<TsbUserConfig>;
    portal_uns_config_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<UnsConfig>;
    portal_UNSGroupB_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_UNSGroupB_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_UNSGroupB1_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_UNSGroupB1_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_UNSGroupB2_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_UNSGroupB2_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_UNSGroupB3_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_UNSGroupB3_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns a list of candidate objects from the table AccProductGroup. */
    portal_candidates_AccProductGroup_get(options?: portal_candidates_AccProductGroup_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AccProductGroup endpoint. */
    portal_candidates_AccProductGroup_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_AccProductGroup_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of candidate objects from the table AccProductParamCategory. */
    portal_candidates_AccProductParamCategory_get(options?: portal_candidates_AccProductParamCategory_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/AccProductParamCategory endpoint. */
    portal_candidates_AccProductParamCategory_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_AccProductParamCategory_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Create an attestation case to assign ownership of the specified group to the current user. */
    portal_claimgroup_post(/** Identity claiming the ownership */ uidperson: string, /** Table name of the system entitlement */ tablename: string, /** Identifier of the system entitlement */ uidunsgroup: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns system entitlements that have no current owner */
    portal_claimgroup_group_get(options?: portal_claimgroup_group_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns suggested owners (first suggestions) for the specified group */
    portal_claimgroup_suggestedowner_get(/** Table name of the system entitlement */ tablename: string, /** Identifier of the system entitlement */ uidunsgroup: string, options?: portal_claimgroup_suggestedowner_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns suggested owners (second suggestions) for the specified group */
    portal_claimgroup_suggestedowner2_get(/** Table name of the system entitlement */ tablename: string, /** Identifier of the system entitlement */ uidunsgroup: string, options?: portal_claimgroup_suggestedowner2_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_person_accounts_get(/** Unique identifier */ uid: string, options?: portal_person_accounts_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_person_groupmemberships_get(/** Unique identifier */ uid: string, options?: portal_person_groupmemberships_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_resp_unsgroup_get(options?: portal_resp_unsgroup_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/unsgroup endpoint. */
    portal_resp_unsgroup_datamodel_get(options?: portal_resp_unsgroup_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_unsgroupb_get(options?: portal_resp_unsgroupb_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/unsgroupb endpoint. */
    portal_resp_unsgroupb_datamodel_get(options?: portal_resp_unsgroupb_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_unsgroupb_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb_interactive_byid_get(/** Primary key value UID_UNSGroupB */ UID_UNSGroupB: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb1_get(options?: portal_resp_unsgroupb1_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/unsgroupb1 endpoint. */
    portal_resp_unsgroupb1_datamodel_get(options?: portal_resp_unsgroupb1_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_unsgroupb1_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb1_interactive_byid_get(/** Primary key value UID_UNSGroupB1 */ UID_UNSGroupB1: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb2_get(options?: portal_resp_unsgroupb2_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/unsgroupb2 endpoint. */
    portal_resp_unsgroupb2_datamodel_get(options?: portal_resp_unsgroupb2_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_unsgroupb2_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb2_interactive_byid_get(/** Primary key value UID_UNSGroupB2 */ UID_UNSGroupB2: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb3_get(options?: portal_resp_unsgroupb3_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the resp/unsgroupb3 endpoint. */
    portal_resp_unsgroupb3_datamodel_get(options?: portal_resp_unsgroupb3_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_resp_unsgroupb3_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_resp_unsgroupb3_interactive_byid_get(/** Primary key value UID_UNSGroupB3 */ UID_UNSGroupB3: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_shop_config_entitlements_TSBAccountDef_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_TSBAccountDef_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_TSBAccountDef_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_TSBAccountDef_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** Account definition */ UID_TSBAccountDef: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_TSBAccountDef. */
    portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates endpoint. */
    portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/TSBAccountDef/UID_TSBAccountDef/candidates endpoint. */
    portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_TSBAccountDef_UID_TSBAccountDef_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** Group */ UID_UNSGroupB: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_UNSGroupB. */
    portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB/UID_UNSGroupB/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_UNSGroupB_UID_UNSGroupB_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB1_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB1_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB1_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB1_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** System entitlement 1 */ UID_UNSGroupB1: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_UNSGroupB1. */
    portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB1/UID_UNSGroupB1/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_UNSGroupB1_UID_UNSGroupB1_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB2_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB2_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB2_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB2_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** System entitlement 2 */ UID_UNSGroupB2: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_UNSGroupB2. */
    portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB2/UID_UNSGroupB2/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_UNSGroupB2_UID_UNSGroupB2_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_shop_config_entitlements_UNSGroupB3_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB3_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB3_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_shop_config_entitlements_UNSGroupB3_delete(/** Unique identifier of the shelf */ UID_ITShopOrg: string, /** System entitlement 3 */ UID_UNSGroupB3: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_UNSGroupB3. */
    portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get(/** Unique identifier of the shelf */ UID_ITShopOrg: string, options?: portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the shop/config/entitlements/{UID_ITShopOrg}/UNSGroupB3/UID_UNSGroupB3/candidates endpoint. */
    portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post(/** Unique identifier of the shelf */ UID_ITShopOrg: string, inputParameterName: EntityWriteDataSingle, options?: portal_shop_config_entitlements_UNSGroupB3_UID_UNSGroupB3_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_uns_account_get(options?: portal_targetsystem_uns_account_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Renders a report for the specified account. */
    portal_targetsystem_uns_account_report_get(/** Type of account */ tablename: string, /** Unique account identifier */ uidaccount: string, options?: portal_targetsystem_uns_account_report_get_args, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/uns/account endpoint. */
    portal_targetsystem_uns_account_datamodel_get(options?: portal_targetsystem_uns_account_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/uns/account endpoint. */
    portal_targetsystem_uns_account_filtertree_get(options?: portal_targetsystem_uns_account_filtertree_get_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Renders a report for accounts belonging to the specified identity. */
    portal_targetsystem_uns_account_ownedby_report_get(/** Unique identity identifier */ uidperson: string, options?: portal_targetsystem_uns_account_ownedby_report_get_args, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Renders a report for accounts belonging to identities managed by the specified identity. */
    portal_targetsystem_uns_account_ownedbymanaged_report_get(/** Unique identity identifier */ uidperson: string, options?: portal_targetsystem_uns_account_ownedbymanaged_report_get_args, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_targetsystem_uns_container_get(options?: portal_targetsystem_uns_container_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Renders a report for accounts in the specified container. */
    portal_targetsystem_uns_container_accounts_report_get(/** Unique container identifier */ uidcontainer: string, options?: portal_targetsystem_uns_container_accounts_report_get_args, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Renders a report for system entitlements in the specified container. */
    portal_targetsystem_uns_container_groups_report_get(/** Unique container identifier */ uidcontainer: string, options?: portal_targetsystem_uns_container_groups_report_get_args, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/uns/container endpoint. */
    portal_targetsystem_uns_container_datamodel_get(options?: portal_targetsystem_uns_container_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_uns_directmembers_get(/** Unique system entitlement identifier */ UID_UNSGroup: string, options?: portal_targetsystem_uns_directmembers_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_uns_group_get(options?: portal_targetsystem_uns_group_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Renders a report for the specified system entitlements. */
    portal_targetsystem_uns_group_report_get(/** Unique group identifier */ uidgroup: string, options?: portal_targetsystem_uns_group_report_get_args, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/uns/group endpoint. */
    portal_targetsystem_uns_group_datamodel_get(options?: portal_targetsystem_uns_group_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns filter tree information for the targetsystem/uns/group endpoint. */
    portal_targetsystem_uns_group_filtertree_get(options?: portal_targetsystem_uns_group_filtertree_get_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_uns_group_serviceitem_get(options?: portal_targetsystem_uns_group_serviceitem_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_put(inputParameterName: ExtendedEntityWriteData<AccProductOwnershipInput>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_uns_group_serviceitem_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/uns/group/serviceitem endpoint. */
    portal_targetsystem_uns_group_serviceitem_datamodel_get(options?: portal_targetsystem_uns_group_serviceitem_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_uns_group_serviceitem_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_uns_group_serviceitem_interactive_byid_get(/** Primary key value UID_AccProduct */ UID_AccProduct: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get(options?: portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the targetsystem/uns/group/serviceitem/interactive/UID_OrgAttestator/candidates endpoint. */
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgAttestator_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get(options?: portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the targetsystem/uns/group/serviceitem/interactive/UID_OrgRuler/candidates endpoint. */
    portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_targetsystem_uns_group_serviceitem_interactive_UID_OrgRuler_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get(options?: portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the targetsystem/uns/group/serviceitem/interactive/UID_PWODecisionMethod/candidates endpoint. */
    portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: InteractiveEntityWriteData, options?: portal_targetsystem_uns_group_serviceitem_interactive_UID_PWODecisionMethod_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgAttestator. */
    portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get(options?: portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the targetsystem/uns/group/serviceitem/UID_OrgAttestator/candidates endpoint. */
    portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_uns_group_serviceitem_UID_OrgAttestator_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_OrgRuler. */
    portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get(options?: portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the targetsystem/uns/group/serviceitem/UID_OrgRuler/candidates endpoint. */
    portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_uns_group_serviceitem_UID_OrgRuler_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    /** Returns a list of objects that can be assigned to the property UID_PWODecisionMethod. */
    portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get(options?: portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the targetsystem/uns/group/serviceitem/UID_PWODecisionMethod/candidates endpoint. */
    portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_targetsystem_uns_group_serviceitem_UID_PWODecisionMethod_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_targetsystem_uns_groupmembers_get(/** Unique group identifier */ uidgroup: string, options?: portal_targetsystem_uns_groupmembers_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_uns_nestedmembers_get(/** Unique identifier */ uid: string, options?: portal_targetsystem_uns_nestedmembers_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Renders a report for system entitlements owned by the specified identity. */
    portal_targetsystem_uns_ownedby_report_get(/** Unique Identity identifier */ uidperson: string, options?: portal_targetsystem_uns_ownedby_report_get_args, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Creates a report containing information about identities managed by the specified identity. */
    portal_targetsystem_uns_person_managed_report_get(/** Unique identity identifier */ uidperson: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Creates a report containing information about personal and organizational data as well as the identity's user accounts, groups and roles. */
    portal_targetsystem_uns_person_report_get(/** Unique identity identifier */ uidperson: string, options?: portal_targetsystem_uns_person_report_get_args, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Renders a report for accounts in the specified target system. */
    portal_targetsystem_uns_root_accounts_report_get(/** Unique root identifier */ uidroot: string, options?: portal_targetsystem_uns_root_accounts_report_get_args, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Renders a report for system entitlements in the specified target system. */
    portal_targetsystem_uns_root_groups_report_get(/** Unique root identifier */ uidroot: string, options?: portal_targetsystem_uns_root_groups_report_get_args, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_targetsystem_uns_system_get(options?: portal_targetsystem_uns_system_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns data model information about query options for the targetsystem/uns/system endpoint. */
    portal_targetsystem_uns_system_datamodel_get(options?: portal_targetsystem_uns_system_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsaccountb_get(options?: portal_targetsystem_unsaccountb_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsaccountb_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsaccountb_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unsaccountb endpoint. */
    portal_targetsystem_unsaccountb_datamodel_get(options?: portal_targetsystem_unsaccountb_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsaccountb_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsaccountb_interactive_byid_get(/** Primary key value UID_UNSAccountB */ UID_UNSAccountB: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unscontainerb_get(options?: portal_targetsystem_unscontainerb_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unscontainerb_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unscontainerb_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unscontainerb endpoint. */
    portal_targetsystem_unscontainerb_datamodel_get(options?: portal_targetsystem_unscontainerb_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unscontainerb_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unscontainerb_interactive_byid_get(/** Primary key value UID_UNSContainerB */ UID_UNSContainerB: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb_get(options?: portal_targetsystem_unsgroupb_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unsgroupb endpoint. */
    portal_targetsystem_unsgroupb_datamodel_get(options?: portal_targetsystem_unsgroupb_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsgroupb_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb_interactive_byid_get(/** Primary key value UID_UNSGroupB */ UID_UNSGroupB: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb1_get(options?: portal_targetsystem_unsgroupb1_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb1_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb1_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unsgroupb1 endpoint. */
    portal_targetsystem_unsgroupb1_datamodel_get(options?: portal_targetsystem_unsgroupb1_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsgroupb1_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb1_interactive_byid_get(/** Primary key value UID_UNSGroupB1 */ UID_UNSGroupB1: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb2_get(options?: portal_targetsystem_unsgroupb2_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb2_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb2_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unsgroupb2 endpoint. */
    portal_targetsystem_unsgroupb2_datamodel_get(options?: portal_targetsystem_unsgroupb2_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsgroupb2_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb2_interactive_byid_get(/** Primary key value UID_UNSGroupB2 */ UID_UNSGroupB2: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb3_get(options?: portal_targetsystem_unsgroupb3_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb3_put(inputParameterName: ExtendedEntityWriteData<GroupExtendedData>, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsgroupb3_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unsgroupb3 endpoint. */
    portal_targetsystem_unsgroupb3_datamodel_get(options?: portal_targetsystem_unsgroupb3_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsgroupb3_interactive_put(inputParameterName: any, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsgroupb3_interactive_byid_get(/** Primary key value UID_UNSGroupB3 */ UID_UNSGroupB3: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsitemb_get(options?: portal_targetsystem_unsitemb_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsitemb_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_unsitemb_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/unsitemb endpoint. */
    portal_targetsystem_unsitemb_datamodel_get(options?: portal_targetsystem_unsitemb_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_targetsystem_unsitemb_interactive_put(inputParameterName: InteractiveEntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_unsitemb_interactive_byid_get(/** Primary key value UID_UNSItemB */ UID_UNSItemB: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<InteractiveEntityData>;
    portal_targetsystem_userconfig_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<TsbUserConfig>;
    /** Returns schema information about the Unified Namespace. */
    portal_uns_config_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<UnsConfig>;
    portal_UNSGroupB_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_UNSGroupB_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_UNSGroupB1_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_UNSGroupB1_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_UNSGroupB2_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_UNSGroupB2_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_UNSGroupB3_memberships_get(/** Unique identifier */ uid: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Deletes an account membership. */
    portal_UNSGroupB3_memberships_delete(/** Unique identifier */ uid: string, /** UID of the account to be removed */ uidaccount: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
}
